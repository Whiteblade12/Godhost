/** PM2 process manager config — auto-recovery for the API (Step 3 of the AWS checklist). */
module.exports = {
  apps: [
    {
      name: 'godhosting-api',
      script: 'src/server.js',
      instances: 1,
      autorestart: true, // PM2 reboots on unhandled errors within milliseconds
      max_memory_restart: '450M',
      watch: false,
      env_production: {
        NODE_ENV: 'production',
      },
    },
  ],
};
