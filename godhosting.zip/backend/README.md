# GodHosting Backend

Node.js + Express + PostgreSQL API powering [godhosting.online](https://godhosting.online).

## Features
- Firebase (Google) authentication + JWT sessions
- Bot CRUD, live process management (Python child processes)
- Plan-based limits (Free / Silver / Gold / Platinum / Diamond)
- 5-second ad gating with server-side verification
- Ad-blocker detection reporting & action blocking
- UPI payments (QR + deep link + UTR verification)
- Referral system (₹1 / month / active referral)
- Socket.IO live bot logs
- Rate limiting, Helmet, CORS, input validation

## Quick start
```bash
npm install
cp .env.example .env      # fill in DATABASE_URL, JWT_SECRET, Firebase keys
npm run init-db           # creates schema + indexes
npm run seed              # optional demo data
npm run dev               # development (nodemon) on :5000
npm start                 # production
```

> **Note:** the bot runner needs `python3` and `pip3` on the host (the Docker image installs them).

## API documentation
See the root [README.md](../README.md#api-documentation) for the full endpoint reference.

## Contact
- Domain: godhosting.online
- Email: godhostings@gmail.com
- Telegram: [t.me/TheGoat_father](https://t.me/TheGoat_father)
