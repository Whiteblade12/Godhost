/**
 * Real-time Telegram telemetry — the Admin Command Center.
 * Dispatches Markdown security alerts asynchronously to your private
 * Telegram chat via the Bot API. Never throws — alerting must never
 * break the request path.
 *
 * Env: TELEGRAM_ADMIN_BOT_TOKEN, TELEGRAM_ADMIN_CHAT_ID
 */
const logger = require('./logger');

const FETCH_TIMEOUT = 4000;

async function postJSON(url, body, timeoutMs = FETCH_TIMEOUT) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    return res;
  } finally {
    clearTimeout(timer);
  }
}

/** Best-effort ISP + location lookup for an IP (ip-api.com, free tier). */
async function lookupIpInfo(ip) {
  if (!ip || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1|::ffff:127\.)/.test(ip)) {
    return '';
  }
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2600);
    const res = await fetch(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,isp,city,regionName,country`, {
      signal: controller.signal,
    });
    clearTimeout(timer);
    const d = await res.json();
    if (d.status === 'success') {
      return `\n📍 ${d.city}, ${d.regionName}, ${d.country}\n🌐 ISP: ${d.isp || 'unknown'}`;
    }
  } catch {
    /* geo lookup is best-effort */
  }
  return '';
}

/** Send a Markdown security alert to the admin's Telegram. Fire-and-forget safe. */
async function sendSecurityAlert(payloadText) {
  const BOT_TOKEN = process.env.TELEGRAM_ADMIN_BOT_TOKEN;
  const CHAT_ID = process.env.TELEGRAM_ADMIN_CHAT_ID;
  if (!BOT_TOKEN || !CHAT_ID) {
    logger.debug('Telegram alert skipped (TELEGRAM_ADMIN_BOT_TOKEN/CHAT_ID not set)');
    return;
  }
  try {
    await postJSON(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      chat_id: CHAT_ID,
      text: `🛡 *GodHosting Security*\n\n${payloadText}`,
      parse_mode: 'Markdown',
      disable_web_page_preview: true,
    });
  } catch (err) {
    logger.warn('Telegram alert dispatch failure: ' + err.message);
  }
}

module.exports = { sendSecurityAlert, lookupIpInfo };
