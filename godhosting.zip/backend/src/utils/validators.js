/** express-validator chains + validation result handler. */
const { body, validationResult } = require('express-validator');

const validateCreateBot = [
  body('name').trim().isLength({ min: 2, max: 60 }).withMessage('Bot name must be 2-60 characters'),
  body('botToken')
    .trim()
    .matches(/^\d{6,12}:[A-Za-z0-9_-]{30,50}$/)
    .withMessage('Invalid Telegram bot token (expected format: 123456:ABC-DEF...)'),
];

const validateUpdateBot = [
  body('name').optional().trim().isLength({ min: 2, max: 60 }),
  body('botToken')
    .optional()
    .trim()
    .matches(/^\d{6,12}:[A-Za-z0-9_-]{30,50}$/)
    .withMessage('Invalid Telegram bot token'),
  body('envVars').optional().isObject(),
];

const validateSaveCode = [
  body('code').isString().isLength({ max: 200000 }).withMessage('Code too large (max 200KB)'),
  body('filename').optional().isIn(['main.py', 'requirements.txt']),
];

const validatePayment = [
  body('planType').isIn(['silver', 'gold', 'platinum', 'diamond']).withMessage('Invalid plan'),
];

const validateVerifyPayment = [
  body('paymentId').trim().notEmpty(),
  body('utr')
    .trim()
    .matches(/^[A-Za-z0-9]{8,16}$/)
    .withMessage('UPI transaction ID (UTR) must be 8-16 letters/numbers'),
];

const validateAdWatch = [
  body('action')
    .isIn(['website_open', 'deploy', 'start', 'restart', 'scroll_logs', 'file_manager'])
    .withMessage('Invalid ad action'),
  body('botId').optional().isInt({ min: 1 }),
];

const validateProfile = [
  body('displayName').optional().trim().isLength({ min: 2, max: 60 }),
];

function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      details: errors.array().map((e) => ({ field: e.path || e.param, message: e.msg })),
    });
  }
  return next();
}

module.exports = {
  validateCreateBot,
  validateUpdateBot,
  validateSaveCode,
  validatePayment,
  validateVerifyPayment,
  validateAdWatch,
  validateProfile,
  handleValidation,
};
