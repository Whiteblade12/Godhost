/** Shared helper functions. */
const crypto = require('crypto');

/** Wrap async route handlers so rejections hit the error middleware. */
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return String(fwd).split(',')[0].trim();
  return req.socket ? req.socket.remoteAddress : undefined;
}

function randomCode(prefix = 'GH', len = 6) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  const bytes = crypto.randomBytes(len);
  for (let i = 0; i < len; i += 1) out += alphabet[bytes[i] % alphabet.length];
  return `${prefix}-${out}`;
}

function paymentId() {
  return `GH${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function isEmail(value) {
  return typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function sanitizeName(value, max = 60) {
  return String(value || '').replace(/[<>]/g, '').trim().slice(0, max);
}

function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function hoursBetween(a, b) {
  return Math.abs(new Date(b).getTime() - new Date(a).getTime()) / 36e5;
}

module.exports = {
  asyncHandler,
  clientIp,
  randomCode,
  paymentId,
  isEmail,
  sanitizeName,
  addDays,
  hoursBetween,
};
