/** Plan definitions + runtime overrides persisted in `plan_config`. */
const { PLANS, PLAN_ORDER } = require('../config/constants');
const { query } = require('../config/database');
const { addDays } = require('../utils/helpers');
const logger = require('../utils/logger');
const User = require('../models/User');

const store = JSON.parse(JSON.stringify(PLANS));

/** Load price overrides from DB (called once at boot). */
async function initialize() {
  try {
    const res = await query('SELECT plan_id, price FROM plan_config');
    for (const row of res.rows) {
      if (store[row.plan_id]) {
        store[row.plan_id].price = row.price;
        logger.info(`Plan override loaded: ${row.plan_id} -> ₹${row.price}`);
      }
    }
  } catch (err) {
    logger.warn('Could not load plan_config (run init-db?): ' + err.message);
  }
}

function getPlan(planType) {
  return store[planType] || store.free;
}

function allPlans() {
  return PLAN_ORDER.map((id) => store[id]);
}

function isPremium(user) {
  const plan = getPlan(user.plan_type);
  return !plan.ads;
}

/** Paid plan still valid? Free is always valid. */
function planActive(user) {
  if (user.plan_type === 'free') return true;
  if (!user.plan_expiry) return false;
  return new Date(user.plan_expiry).getTime() > Date.now();
}

/** Downgrade expired paid users to free (called by scheduler). */
async function downgradeExpired() {
  const res = await query(
    `UPDATE users SET plan_type = 'free', storage_limit = $2, max_bots = $3
      WHERE plan_type <> 'free' AND plan_expiry IS NOT NULL AND plan_expiry < CURRENT_DATE
      RETURNING id`,
    [store.free.storageLimit, store.free.maxBots]
  );
  if (res.rowCount > 0) logger.info(`Downgraded ${res.rowCount} expired plan(s) to free`);
  return res.rowCount;
}

/** Upgrade a user after a confirmed payment (+30 days, stacks on active sub). */
async function applyPurchase(user, planType) {
  const base = planActive(user) && user.plan_expiry ? new Date(user.plan_expiry) : new Date();
  if (base.getTime() < Date.now()) base.setTime(Date.now());
  const expiry = addDays(base, 30);
  return User.applyPlan(user.id, planType, expiry);
}

async function updatePrice(planType, price) {
  if (!store[planType]) throw Object.assign(new Error('Unknown plan'), { status: 400 });
  store[planType].price = price;
  await query(
    `INSERT INTO plan_config (plan_id, price, updated_at) VALUES ($1, $2, CURRENT_TIMESTAMP)
     ON CONFLICT (plan_id) DO UPDATE SET price = $2, updated_at = CURRENT_TIMESTAMP`,
    [planType, price]
  );
  return store[planType];
}

module.exports = {
  initialize,
  getPlan,
  allPlans,
  isPremium,
  planActive,
  downgradeExpired,
  applyPurchase,
  updatePrice,
};
