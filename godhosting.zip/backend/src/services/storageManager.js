/** File storage management per user/bot (plan-limited). */
const fs = require('fs');
const path = require('path');
const { getPlan } = require('./planLimits');
const User = require('../models/User');
const logger = require('../utils/logger');

const ROOT = path.resolve(process.env.STORAGE_PATH || './bots');
if (!fs.existsSync(ROOT)) fs.mkdirSync(ROOT, { recursive: true });

function botDir(userId, botId) {
  const dir = path.join(ROOT, `u${userId}`, `bot${botId}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function userDir(userId) {
  return path.join(ROOT, `u${userId}`);
}

function dirSize(dir) {
  if (!fs.existsSync(dir)) return 0;
  let total = 0;
  const stack = [dir];
  while (stack.length) {
    const current = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      try {
        if (entry.isDirectory()) stack.push(full);
        else total += fs.statSync(full).size;
      } catch {
        /* ignore races */
      }
    }
  }
  return total;
}

async function syncUserUsage(userId) {
  const used = dirSize(userDir(userId));
  await User.updateStorageUsed(userId, used);
  return used;
}

/** Throws 413 if adding `bytes` would exceed the plan storage limit. */
async function assertCapacity(user, bytes = 0) {
  const used = await syncUserUsage(user.id);
  const plan = getPlan(user.plan_type);
  if (used + bytes > plan.storageLimit) {
    const err = new Error(
      `Storage limit reached (${plan.storageLabel}). Delete files or upgrade your plan.`
    );
    err.status = 413;
    throw err;
  }
  return used;
}

function writeBotFile(user, botId, filename, buffer) {
  const dir = botDir(user.id, botId);
  const target = path.join(dir, path.basename(filename));
  fs.writeFileSync(target, buffer);
  return syncUserUsage(user.id);
}

function readBotFile(user, botId, filename) {
  const target = path.join(botDir(user.id, botId), path.basename(filename));
  if (!fs.existsSync(target)) return null;
  return fs.readFileSync(target);
}

function listBotFiles(user, botId) {
  const dir = botDir(user.id, botId);
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isFile())
    .map((e) => ({ name: e.name, size: fs.statSync(path.join(dir, e.name)).size }));
}

function deleteBotFile(user, botId, filename) {
  const target = path.join(botDir(user.id, botId), path.basename(filename));
  if (fs.existsSync(target)) fs.unlinkSync(target);
  return syncUserUsage(user.id);
}

function removeBotDir(userId, botId) {
  const dir = botDir(userId, botId);
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch (err) {
    logger.warn('Failed to remove bot dir', { dir, error: err.message });
  }
  return syncUserUsage(userId);
}

module.exports = {
  ROOT,
  botDir,
  userDir,
  dirSize,
  syncUserUsage,
  assertCapacity,
  writeBotFile,
  readBotFile,
  listBotFiles,
  deleteBotFile,
  removeBotDir,
};
