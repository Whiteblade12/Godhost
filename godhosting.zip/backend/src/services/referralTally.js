/**
 * 7-Day Referral Validator.
 * Runs hourly. For every pending referral:
 *  - referred user active TODAY  -> streak +1
 *      - streak reaches 7 -> status 'completed', referrer wallet +₹3.00,
 *        wallet_transactions 'referral_bonus'
 *  - referred user silent > 48h -> status 'failed'
 */
const { query, withTransaction } = require('../config/database');
const { REFERRAL_BONUS, REFERRAL_STREAK_DAYS } = require('../config/constants');
const logger = require('../utils/logger');

async function auditReferralMilestones() {
  try {
    const pendingReferrals = await query(
      `SELECT r.id, r.referrer_id, r.referred_id, COALESCE(r.continuous_days_logged, 0) AS continuous_days_logged,
              u.last_active
         FROM referrals r JOIN users u ON r.referred_id = u.id
        WHERE r.status = 'pending'`
    );

    let completed = 0;
    let failed = 0;

    for (const ref of pendingReferrals.rows) {
      const today = new Date().toISOString().split('T')[0];
      const lastActiveDate = ref.last_active
        ? new Date(ref.last_active).toISOString().split('T')[0]
        : null;

      await withTransaction(async (client) => {
        if (lastActiveDate === today) {
          const updatedDays = Number(ref.continuous_days_logged) + 1;
          if (updatedDays >= REFERRAL_STREAK_DAYS) {
            await client.query(
              `UPDATE referrals SET status = 'completed', continuous_days_logged = $2, earnings = earnings + $3 WHERE id = $1`,
              [ref.id, REFERRAL_STREAK_DAYS, REFERRAL_BONUS]
            );
            await client.query(
              'UPDATE users SET wallet_balance = wallet_balance + $2 WHERE id = $1',
              [ref.referrer_id, REFERRAL_BONUS]
            );
            await client.query(
              `INSERT INTO wallet_transactions (user_id, amount, transaction_type) VALUES ($1, $2, 'referral_bonus')`,
              [ref.referrer_id, REFERRAL_BONUS]
            );
            completed += 1;
          } else {
            await client.query(
              'UPDATE referrals SET continuous_days_logged = $2 WHERE id = $1',
              [updatedDays, ref.id]
            );
          }
        } else {
          const lastActiveTime = ref.last_active ? new Date(ref.last_active).getTime() : 0;
          if (Date.now() - lastActiveTime > 24 * 60 * 60 * 1000 * 2) {
            await client.query("UPDATE referrals SET status = 'failed' WHERE id = $1", [ref.id]);
            failed += 1;
          }
        }
      });
    }

    if (completed || failed) {
      logger.info(`Referral audit: ${completed} completed (+₹${REFERRAL_BONUS} each), ${failed} failed`);
    }
  } catch (err) {
    logger.error('Referral validation iteration failed: ' + err.message);
  }
}

module.exports = { auditReferralMilestones };
