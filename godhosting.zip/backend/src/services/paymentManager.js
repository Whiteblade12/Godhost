/** UPI payment flow: order creation, QR codes, UTR verification, plan upgrade. */
const QRCode = require('qrcode');
const Payment = require('../models/Payment');
const ActivityLog = require('../models/ActivityLog');
const { getPlan, applyPurchase } = require('./planLimits');
const { UPI } = require('../config/constants');
const { paymentId: genPaymentId } = require('../utils/helpers');
const logger = require('../utils/logger');

function upiLink(amount, note) {
  const params = new URLSearchParams({
    pa: UPI.id,
    pn: UPI.name,
    am: String(amount),
    cu: 'INR',
    tn: note,
  });
  return `upi://pay?${params.toString()}`;
}

async function createPayment(user, planType) {
  const plan = getPlan(planType);
  if (!plan || plan.price <= 0) {
    const err = new Error('This plan cannot be purchased');
    err.status = 400;
    throw err;
  }
  const pid = genPaymentId();
  const payment = await Payment.create({
    userId: user.id,
    planType,
    amount: plan.price,
    paymentId: pid,
  });
  const note = `GodHosting ${plan.name} plan (${pid})`;
  return {
    payment: {
      id: payment.id,
      paymentId: payment.payment_id,
      planType: payment.plan_type,
      amount: payment.amount,
      status: payment.payment_status,
    },
    upiId: UPI.id,
    upiName: UPI.name,
    upiLink: upiLink(plan.price, note),
    note,
  };
}

async function qrDataUrl(paymentId) {
  const payment = await Payment.findByPaymentId(paymentId);
  if (!payment) return null;
  const plan = getPlan(payment.plan_type);
  const link = upiLink(payment.amount, `GodHosting ${plan.name} plan (${payment.payment_id})`);
  return QRCode.toDataURL(link, { margin: 1, width: 320, color: { dark: '#1a1a2e', light: '#ffffff' } });
}

async function qrBuffer(paymentId) {
  const payment = await Payment.findByPaymentId(paymentId);
  if (!payment) return null;
  const plan = getPlan(payment.plan_type);
  const link = upiLink(payment.amount, `GodHosting ${plan.name} plan (${payment.payment_id})`);
  return QRCode.toBuffer(link, { margin: 1, width: 420, color: { dark: '#1a1a2e', light: '#ffffff' } });
}

/** Verify UTR submitted by the user and upgrade their plan (+30 days). */
async function verifyPayment(user, paymentIdStr, utr) {
  const payment = await Payment.findByPaymentId(paymentIdStr);
  if (!payment || payment.user_id !== user.id) {
    const err = new Error('Payment not found');
    err.status = 404;
    throw err;
  }
  if (payment.payment_status === 'confirmed') {
    return { payment, alreadyConfirmed: true };
  }
  if (!/^[A-Za-z0-9]{8,16}$/.test(utr)) {
    const err = new Error('Invalid UPI transaction ID (UTR). It is 8-16 letters/numbers.');
    err.status = 400;
    throw err;
  }

  const upgraded = await applyPurchase(user, payment.plan_type);
  const confirmed = await Payment.confirm(payment.id, utr, upgraded.plan_expiry);
  await ActivityLog.log(user.id, 'payment_confirmed', {
    details: {
      paymentId: payment.payment_id,
      utr,
      plan: payment.plan_type,
      amount: payment.amount,
    },
  });
  logger.info(`Payment confirmed ${payment.payment_id} via UTR ${utr} for user ${user.id}`);
  return { payment: confirmed, user: upgraded };
}

async function history(user) {
  return Payment.findByUser(user.id);
}

async function statusOf(paymentIdStr) {
  return Payment.findByPaymentId(paymentIdStr);
}

module.exports = { createPayment, qrDataUrl, qrBuffer, verifyPayment, history, statusOf, upiLink };
