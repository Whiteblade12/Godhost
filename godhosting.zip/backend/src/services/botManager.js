/**
 * Bot process manager.
 * - Each bot runs as an isolated Python child process in its own directory.
 * - requirements.txt is installed to a local `deps/` folder (added to PYTHONPATH).
 * - stdout/stderr is captured into an in-memory ring buffer + logs/<botId>.log
 *   and streamed live over Socket.IO.
 * - Free-plan bots auto-stop after 24h (scheduler runs every 60s).
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const Bot = require('../models/Bot');
const ActivityLog = require('../models/ActivityLog');
const storageManager = require('./storageManager');
const socket = require('./socket');
const logger = require('../utils/logger');

const LOG_DIR = path.resolve(process.env.LOG_PATH || './logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

/** botId -> { proc, startedAt, logs: [] } */
const processes = new Map();
const MAX_LOG_LINES = 1000;

function logFileFor(botId) {
  return path.join(LOG_DIR, `bot${botId}.log`);
}

function pushLog(botId, stream, line) {
  const entry = { t: new Date().toISOString(), stream, line };
  const state = processes.get(botId);
  if (state) {
    state.logs.push(entry);
    if (state.logs.length > MAX_LOG_LINES) state.logs.splice(0, state.logs.length - MAX_LOG_LINES);
  }
  try {
    fs.appendFileSync(logFileFor(botId), `[${entry.t}] [${stream}] ${line}\n`);
  } catch {
    /* non-fatal */
  }
  socket.emitLog(botId, entry);
}

function botEnv(bot) {
  const dir = storageManager.botDir(bot.user_id, bot.id);
  const depsDir = path.join(dir, 'deps');
  const envVars = (typeof bot.env_vars === 'object' && bot.env_vars) || {};
  const existing = process.env.PYTHONPATH ? `${path.delimiter}${process.env.PYTHONPATH}` : '';
  return {
    ...process.env,
    BOT_TOKEN: bot.bot_token,
    TOKEN: bot.bot_token,
    PYTHONPATH: depsDir + existing,
    PYTHONUNBUFFERED: '1',
    ...envVars,
  };
}

/** Install requirements.txt into deps/ (best effort; failures are logged to the bot log). */
async function installRequirements(bot) {
  const dir = storageManager.botDir(bot.user_id, bot.id);
  const reqFile = path.join(dir, 'requirements.txt');
  if (!fs.existsSync(reqFile)) return true;
  const content = fs.readFileSync(reqFile, 'utf8').trim();
  if (!content) return true;

  pushLog(bot.id, 'system', 'Installing requirements.txt ...');
  const depsDir = path.join(dir, 'deps');
  if (!fs.existsSync(depsDir)) fs.mkdirSync(depsDir, { recursive: true });

  return new Promise((resolve) => {
    const pip = spawn('pip3', ['install', '--no-cache-dir', '--quiet', '--target', depsDir, '-r', reqFile]);
    let stderr = '';
    pip.stderr.on('data', (d) => {
      stderr += d.toString();
    });
    pip.on('error', (err) => {
      pushLog(bot.id, 'stderr', `pip3 not available (${err.message}) - starting without installing dependencies`);
      resolve(false);
    });
    pip.on('close', (code) => {
      if (code === 0) {
        pushLog(bot.id, 'system', 'Dependencies installed successfully.');
        resolve(true);
      } else {
        pushLog(bot.id, 'stderr', `pip install exited with code ${code}. ${stderr.slice(-500)}`);
        resolve(false);
      }
    });
  });
}

/** Ensure main.py exists on disk (DB code is the source of truth). */
function syncCodeToDisk(bot) {
  const dir = storageManager.botDir(bot.user_id, bot.id);
  const mainPy = path.join(dir, 'main.py');
  const diskExists = fs.existsSync(mainPy);
  if (!diskExists || typeof bot.code === 'string') {
    fs.writeFileSync(mainPy, bot.code || DEFAULT_MAIN_PY);
  }
  return dir;
}

const DEFAULT_MAIN_PY = `# GodHosting - main.py
# Your bot token is available as the BOT_TOKEN environment variable.
import os
import time

TOKEN = os.environ.get("BOT_TOKEN", "")

def main():
    print("Bot starting... token loaded:", bool(TOKEN))
    while True:
        print("Bot running...")
        time.sleep(60)

if __name__ == "__main__":
    main()
`;

async function startBot(bot, { userId } = {}) {
  if (processes.has(bot.id)) {
    return { alreadyRunning: true };
  }

  const dir = syncCodeToDisk(bot);
  const mainPy = path.join(dir, 'main.py');
  if (!fs.existsSync(mainPy)) {
    const err = new Error('main.py not found. Save your code before starting the bot.');
    err.status = 400;
    throw err;
  }

  await installRequirements(bot);

  pushLog(bot.id, 'system', `Starting bot "${bot.name}" (id ${bot.id})...`);
  const proc = spawn('python3', [mainPy], {
    cwd: dir,
    env: botEnv(bot),
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  processes.set(bot.id, { proc, startedAt: Date.now(), logs: [] });

  proc.stdout.on('data', (data) => {
    data
      .toString()
      .split('\n')
      .filter((l) => l.trim().length)
      .forEach((line) => pushLog(bot.id, 'stdout', line));
  });

  proc.stderr.on('data', (data) => {
    data
      .toString()
      .split('\n')
      .filter((l) => l.trim().length)
      .forEach((line) => pushLog(bot.id, 'stderr', line));
    Bot.incrementErrors(bot.id).catch(() => {});
  });

  proc.on('error', (err) => {
    pushLog(bot.id, 'stderr', `Failed to start python3: ${err.message}`);
  });

  proc.on('close', async (code, signal) => {
    pushLog(bot.id, 'system', `Process exited (code=${code}, signal=${signal || 'none'}).`);
    processes.delete(bot.id);
    await Bot.setStatus(bot.id, 'stopped', null).catch(() => {});
    socket.emitStatus(bot.id, 'stopped');
  });

  await Bot.setStatus(bot.id, 'running', proc.pid);
  socket.emitStatus(bot.id, 'running');
  if (userId) {
    await ActivityLog.log(userId, 'bot_start', { botId: bot.id }).catch(() => {});
  }
  return { started: true, pid: proc.pid };
}

async function stopBot(bot, { userId, silent = false } = {}) {
  const state = processes.get(bot.id);
  if (state) {
    pushLog(bot.id, 'system', 'Stopping bot...');
    const { proc } = state;
    proc.kill('SIGTERM');
    setTimeout(() => {
      if (processes.has(bot.id)) {
        try {
          proc.kill('SIGKILL');
        } catch {
          /* already dead */
        }
      }
    }, 5000);
    processes.delete(bot.id);
  }
  await Bot.setStatus(bot.id, 'stopped', null);
  socket.emitStatus(bot.id, 'stopped');
  if (!silent) socket.emitLog(bot.id, { t: new Date().toISOString(), stream: 'system', line: 'Bot stopped.' });
  if (userId) await ActivityLog.log(userId, 'bot_stop', { botId: bot.id }).catch(() => {});
  return { stopped: true };
}

async function restartBot(bot, opts = {}) {
  await stopBot(bot, { silent: true });
  await new Promise((r) => setTimeout(r, 800));
  await Bot.incrementRestart(bot.id);
  const fresh = await Bot.findById(bot.id);
  return startBot(fresh, opts);
}

function getStatus(botId) {
  const state = processes.get(botId);
  if (!state) return { running: false };
  return {
    running: true,
    pid: state.proc.pid,
    uptimeSeconds: Math.floor((Date.now() - state.startedAt) / 1000),
  };
}

function getLogs(botId, tail = 200) {
  const state = processes.get(botId);
  if (state && state.logs.length) {
    return state.logs.slice(-tail);
  }
  const file = logFileFor(botId);
  if (!fs.existsSync(file)) return [];
  const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).slice(-tail);
  return lines.map((l) => {
    const m = l.match(/^\[([^\]]+)\] \[([^\]]+)\] (.*)$/);
    if (m) return { t: m[1], stream: m[2], line: m[3] };
    return { t: new Date().toISOString(), stream: 'stdout', line: l };
  });
}

function isRunning(botId) {
  return processes.has(botId);
}

/**
 * Scheduler: stop free-plan bots running > 24h, every 60 seconds.
 * Also recovers `running` DB rows that lost their process after a restart.
 */
function startScheduler() {
  const tick = async () => {
    try {
      const expired = await Bot.runningFreeExpired();
      for (const bot of expired) {
        pushLog(bot.id, 'system', 'Auto-stop: free-plan bots stop after 24 hours. Restart or upgrade to keep running 24/7.');
        await stopBot(bot, { silent: true });
        await ActivityLog.log(bot.user_id, 'bot_autostop', { botId: bot.id }).catch(() => {});
      }

      // Recover orphaned "running" rows (server restarted while bots were up)
      const running = await Bot.running();
      for (const bot of running) {
        if (!processes.has(bot.id)) {
          await Bot.setStatus(bot.id, 'stopped', null);
        }
      }
    } catch (err) {
      logger.warn('Scheduler tick failed: ' + err.message);
    }
  };

  const interval = setInterval(tick, 60 * 1000);
  interval.unref();
  logger.info('Bot auto-stop scheduler started (60s interval, 24h free-plan limit)');
  return interval;
}

function stopAll() {
  for (const [botId, state] of processes.entries()) {
    try {
      state.proc.kill('SIGTERM');
    } catch {
      /* ignore */
    }
    processes.delete(botId);
  }
}

module.exports = {
  startBot,
  stopBot,
  restartBot,
  getStatus,
  getLogs,
  isRunning,
  startScheduler,
  stopAll,
  DEFAULT_MAIN_PY,
};
