/** Socket.IO server: authenticated rooms for live bot logs & status. */
const { Server } = require('socket.io');
const { verifyToken } = require('../middleware/auth');
const User = require('../models/User');
const Bot = require('../models/Bot');
const logger = require('../utils/logger');

let io = null;

function init(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: (process.env.CORS_ORIGIN || '*').split(','),
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  io.use(async (socket, next) => {
    try {
      const token = (socket.handshake.auth && socket.handshake.auth.token) || null;
      const payload = token ? verifyToken(token) : null;
      if (!payload) return next(new Error('unauthorized'));
      const user = await User.findById(payload.uid);
      if (!user) return next(new Error('unauthorized'));
      socket.data.user = user;
      return next();
    } catch (err) {
      return next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.data.user;

    socket.on('join', async (botId) => {
      try {
        const bot = await Bot.findByIdAndUser(Number(botId), user.id);
        if (!bot) return;
        socket.join(`bot:${bot.id}`);
        socket.emit('joined', { botId: bot.id, status: bot.status });
      } catch (err) {
        logger.warn('socket join failed', { error: err.message });
      }
    });

    socket.on('leave', (botId) => {
      socket.leave(`bot:${Number(botId)}`);
    });

    socket.on('disconnect', () => {});
  });

  logger.info('Socket.IO initialized');
  return io;
}

function emitLog(botId, entry) {
  if (io) io.to(`bot:${botId}`).emit('log', { botId, ...entry });
}

function emitStatus(botId, status) {
  if (io) io.to(`bot:${botId}`).emit('status', { botId, status });
}

function getIo() {
  return io;
}

module.exports = { init, emitLog, emitStatus, getIo };
