/** Ad gating logic: watch sessions, verification, ad-blocker reports. */
const AdWatch = require('../models/AdWatch');
const User = require('../models/User');
const { AD_DURATION_SECONDS } = require('../config/constants');
const { adsNeededFor } = require('../middleware/adBlocker');
const { getPlan } = require('./planLimits');
const { clientIp } = require('../utils/helpers');

function statusForAction(user, action) {
  const plan = getPlan(user.plan_type);
  const need = adsNeededFor(plan, action);
  return {
    action,
    plan: plan.id,
    required: need.required,
    count: need.count,
    duration: need.duration,
  };
}

async function startWatch(req, action, botId) {
  const plan = getPlan(req.user.plan_type);
  const need = adsNeededFor(plan, action);
  const watch = await AdWatch.create({
    userId: req.user.id,
    botId: botId || null,
    action,
    duration: need.duration || AD_DURATION_SECONDS,
    ip: clientIp(req),
    userAgent: req.headers['user-agent'] || null,
  });
  return { adWatchId: watch.id, duration: watch.ad_duration, action };
}

/**
 * Complete a watch. Server verifies the user actually waited:
 * elapsed time must be >= duration - 1s tolerance.
 */
async function completeWatch(user, adWatchId) {
  const watch = await AdWatch.findById(adWatchId);
  if (!watch || watch.user_id !== user.id) {
    const err = new Error('Ad watch not found');
    err.status = 404;
    throw err;
  }
  if (watch.completed) {
    return { verified: watch.verified, alreadyCompleted: true };
  }
  const elapsed = (Date.now() - new Date(watch.watch_start).getTime()) / 1000;
  const verified = elapsed >= watch.ad_duration - 1;
  await AdWatch.complete(watch.id, user.id, verified);
  return { verified, elapsedSeconds: Math.round(elapsed) };
}

/**
 * Client reports ad-blocker detection state.
 * For ad-supported plans a positive detection blocks all actions.
 */
async function reportAdBlocker(user, detected, methods = []) {
  const plan = getPlan(user.plan_type);
  if (!plan.ads) {
    // Premium users may use ad blockers; we simply don't record a block.
    return { blocked: false, premium: true };
  }
  await User.setAdblocker(user.id, !!detected, methods);
  return { blocked: !!detected, premium: false };
}

module.exports = { statusForAction, startWatch, completeWatch, reportAdBlocker };
