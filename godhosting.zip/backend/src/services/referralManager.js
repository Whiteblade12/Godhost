/**
 * Referral program (7-day streak edition):
 * codes, tracking, streak stats, wallet payouts.
 * Credits are applied by referralTally.js (hourly audit):
 * referred user logs in 7 consecutive days -> referrer wallet +₹3.00.
 */
const Referral = require('../models/Referral');
const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');
const { sendSecurityAlert } = require('../utils/telegramAlert');
const { REFERRAL_BONUS, REFERRAL_STREAK_DAYS, CONTACT } = require('../config/constants');

function referralLink(code) {
  return `https://${CONTACT.domain}/?ref=${code}`;
}

async function stats(user) {
  const [s, wallet] = await Promise.all([Referral.statsFor(user.id), User.wallet(user.id)]);
  return {
    code: user.referral_code,
    link: referralLink(user.referral_code),
    bonusPerCompletion: REFERRAL_BONUS,
    streakDaysRequired: REFERRAL_STREAK_DAYS,
    totalReferrals: s.total,
    pending: s.pending,
    completed: s.completed,
    failed: s.failed,
    walletBalance: wallet.balance,
  };
}

async function earnings(user) {
  return Referral.list(user.id);
}

/** Payout request: wallet balance is paid via UPI manually by the owner. */
async function payoutRequest(user, upiId) {
  const wallet = await User.wallet(user.id);
  if (wallet.balance <= 0) {
    return { ok: false, note: 'Nothing to withdraw yet. Complete referrals or watch rewarded ads to earn.' };
  }
  await ActivityLog.log(user.id, 'payout_request', {
    details: { amount: wallet.balance, upiId: upiId || null },
  });
  // Ping the owner on Telegram so payouts are never missed
  sendSecurityAlert(
    `💸 *Payout Request*\n\n` +
    `👤 User: #${user.id} — ${user.email}\n` +
    `💰 Amount: ₹${wallet.balance.toFixed(2)}\n` +
    `🏦 UPI: \`${upiId || 'not provided'}\``
  ).catch(() => {});
  return {
    ok: true,
    note: `Withdrawal of ₹${wallet.balance.toFixed(2)} requested. Payouts are sent via UPI within 48h — track updates on Telegram ${CONTACT.telegramHandle}.`,
  };
}

module.exports = { stats, earnings, payoutRequest, referralLink };
