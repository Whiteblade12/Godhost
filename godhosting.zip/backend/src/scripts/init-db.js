/** Create the database schema. Usage: npm run init-db */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { pool } = require('../config/database');

async function main() {
  const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  console.log('Creating GodHosting schema...');
  await pool.query(schema);
  console.log('Schema created successfully.');
  process.exit(0);
}

main().catch((err) => {
  console.error('init-db failed:', err.message);
  process.exit(1);
});
