/**
 * Generate a scrypt hash for your admin password.
 * Usage:
 *   npm run admin:hash                (interactive, hidden typing)
 *   npm run admin:hash -- myPassword  (one-shot)
 * Paste the output into backend/.env as ADMIN_PASSWORD_HASH.
 */
const readline = require('readline');
const { hashPassword } = require('../middleware/adminAuth');

async function main() {
  let password = process.argv[2];
  if (!password) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    // Mute echoing so the password is not visible in the terminal
    const origWrite = process.stdout.write.bind(process.stdout);
    process.stdout.write = (chunk, ...args) => {
      if (typeof chunk === 'string' && chunk.includes('\n')) return origWrite(chunk, ...args);
      return true;
    };
    password = await new Promise((resolve) => rl.question('Enter admin password: ', (ans) => {
      process.stdout.write = origWrite;
      rl.close();
      resolve(ans);
    }));
    process.stdout.write('\n');
  }
  if (!password || password.length < 8) {
    console.error('Password must be at least 8 characters.');
    process.exit(1);
  }
  console.log('\nAdd this line to backend/.env:\n');
  console.log(`ADMIN_PASSWORD_HASH=${hashPassword(password)}`);
  console.log('\nThe raw password is NOT stored — only this hash is kept on the API server.');
}

main();
