/** Seed demo data (local development only). Usage: npm run seed */
require('dotenv').config();
const { pool, withTransaction } = require('../config/database');

async function main() {
  await withTransaction(async (client) => {
    const userRes = await client.query(
      `INSERT INTO users (firebase_uid, email, display_name, plan_type, referral_code, last_active)
       VALUES ('demo-godhosting', 'demo@godhosting.online', 'Demo User', 'free', 'GH-DEMO1', CURRENT_TIMESTAMP)
       ON CONFLICT (firebase_uid) DO UPDATE SET display_name = EXCLUDED.display_name
       RETURNING id`
    );
    const userId = userRes.rows[0].id;

    await client.query(
      `INSERT INTO bots (user_id, name, bot_token, code)
       VALUES ($1, 'My First Bot', '123456789:AAHdemoTOKENdemoTOKENdemoTOKENdemo0', $2)
       ON CONFLICT DO NOTHING`,
      [
        userId,
        'import os\nimport time\n\nprint("Hello from GodHosting demo bot!")\nwhile True:\n    print("tick")\n    time.sleep(30)\n',
      ]
    );

    await client.query(
      `INSERT INTO plan_config (plan_id, price) VALUES
         ('free', 0), ('silver', 30), ('gold', 100), ('platinum', 120), ('diamond', 150)
       ON CONFLICT (plan_id) DO UPDATE SET price = EXCLUDED.price`
    );
  });
  console.log('Seed complete. Demo login (DEMO_MODE=true): demo@godhosting.online');
  process.exit(0);
}

main().catch((err) => {
  console.error('seed failed:', err.message);
  process.exit(1);
});
