-- ============================================================
-- GodHosting - PostgreSQL schema
-- Run with: npm run init-db
-- ============================================================

-- === USERS TABLE ===
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  firebase_uid TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  display_name TEXT,
  plan_type TEXT DEFAULT 'free',
  plan_expiry DATE,
  storage_used BIGINT DEFAULT 0,
  storage_limit BIGINT DEFAULT 262144000,
  max_bots INTEGER DEFAULT 1,
  referral_code TEXT UNIQUE,
  referred_by INTEGER REFERENCES users(id),
  ads_enabled BOOLEAN DEFAULT TRUE,
  adblocker_detected BOOLEAN DEFAULT FALSE,
  adblocker_detected_at TIMESTAMP,
  adblocker_warnings INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_active TIMESTAMP
);

-- === BOTS TABLE ===
CREATE TABLE IF NOT EXISTS bots (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  bot_token TEXT NOT NULL,
  status TEXT DEFAULT 'stopped',
  pid INTEGER,
  env_vars JSONB DEFAULT '{}',
  code TEXT,
  storage_path TEXT,
  last_started TIMESTAMP,
  last_restart TIMESTAMP,
  restart_count INTEGER DEFAULT 0,
  uptime_seconds INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expiry_time TIMESTAMP,
  total_requests INTEGER DEFAULT 0,
  error_count INTEGER DEFAULT 0
);

-- === AD WATCHES ===
CREATE TABLE IF NOT EXISTS ad_watches (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  bot_id INTEGER REFERENCES bots(id) ON DELETE CASCADE,
  ad_type TEXT,
  ad_duration INTEGER DEFAULT 5,
  watch_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  watch_end TIMESTAMP,
  completed BOOLEAN DEFAULT FALSE,
  verified BOOLEAN DEFAULT FALSE,
  adblocker_detected BOOLEAN DEFAULT FALSE,
  ip_address TEXT,
  user_agent TEXT
);

-- === PAYMENTS ===
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  plan_type TEXT,
  amount INTEGER,
  payment_id TEXT UNIQUE,
  payment_status TEXT DEFAULT 'pending',
  upi_transaction_id TEXT,
  payment_method TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expiry_date DATE,
  confirmed_at TIMESTAMP
);

-- === REFERRALS ===
CREATE TABLE IF NOT EXISTS referrals (
  id SERIAL PRIMARY KEY,
  referrer_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  referred_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'active',
  earnings DECIMAL(10,2) DEFAULT 0,
  last_payout TIMESTAMP,
  next_credit_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- === ACTIVITY LOGS ===
CREATE TABLE IF NOT EXISTS activity_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  action_type TEXT,
  bot_id INTEGER REFERENCES bots(id) ON DELETE CASCADE,
  ip_address TEXT,
  user_agent TEXT,
  details JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- === PLAN CONFIG (runtime price overrides via admin API) ===
CREATE TABLE IF NOT EXISTS plan_config (
  plan_id TEXT PRIMARY KEY,
  price INTEGER NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- === INDEXES ===
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);
CREATE INDEX IF NOT EXISTS idx_bots_user_id ON bots(user_id);
CREATE INDEX IF NOT EXISTS idx_bots_status ON bots(status);
CREATE INDEX IF NOT EXISTS idx_bots_last_started ON bots(last_started);
CREATE INDEX IF NOT EXISTS idx_ad_watches_user_id ON ad_watches(user_id);
CREATE INDEX IF NOT EXISTS idx_ad_watches_completed ON ad_watches(completed);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(payment_status);
CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status);
CREATE INDEX IF NOT EXISTS idx_activity_user_id ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(created_at);

-- ============================================================
-- UPGRADE: wallet, watch-to-win rewards, 7-day referral streaks
-- (idempotent — safe to re-run on existing databases)
-- ============================================================
ALTER TABLE users ADD COLUMN IF NOT EXISTS wallet_balance DECIMAL(10,2) DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS pending_ad_clicks INTEGER DEFAULT 0;
ALTER TABLE ad_watches ADD COLUMN IF NOT EXISTS reference_id TEXT UNIQUE;
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS continuous_days_logged INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  transaction_type TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_user ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_type ON wallet_transactions(transaction_type);
