/** Authentication middleware: verifies backend-issued JWTs and loads the user. */
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { asyncHandler } = require('../utils/helpers');
const logger = require('../utils/logger');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const JWT_EXPIRY = process.env.JWT_EXPIRY || '7d';

function signToken(user) {
  return jwt.sign({ uid: user.id, email: user.email }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

function extractToken(req) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) return header.slice(7);
  if (req.cookies && req.cookies.gh_token) return req.cookies.gh_token;
  return null;
}

/** Require a valid session. Attaches fresh user from DB to req.user. */
const authenticate = asyncHandler(async (req, res, next) => {
  const token = extractToken(req);
  if (!token) return res.status(401).json({ error: 'Authentication required' });

  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Invalid or expired session' });

  const user = await User.findById(payload.uid);
  if (!user) return res.status(401).json({ error: 'Account not found' });

  req.user = user;
  return next();
});

/** Same as authenticate but does not fail for guests. */
const optionalAuth = asyncHandler(async (req, res, next) => {
  const token = extractToken(req);
  if (token) {
    const payload = verifyToken(token);
    if (payload) req.user = await User.findById(payload.uid);
  }
  return next();
});

function requireAdmin(req, res, next) {
  const admins = (process.env.ADMIN_EMAILS || '')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (!req.user || !admins.includes(String(req.user.email).toLowerCase())) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  return next();
}

module.exports = { signToken, verifyToken, extractToken, authenticate, optionalAuth, requireAdmin };
