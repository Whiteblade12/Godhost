/** 404 + centralized error handling. */
const logger = require('../utils/logger');

function notFound(req, res, next) {
  res.status(404).json({ error: `Not found: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;
  const isDev = process.env.NODE_ENV !== 'production';
  logger.error(`Unhandled error: ${err.message}`, {
    stack: err.stack,
    url: req.originalUrl,
    method: req.method,
  });
  res.status(status).json({
    error: err.publicMessage || 'Internal server error',
    ...(isDev ? { detail: err.message } : {}),
  });
}

module.exports = { notFound, errorHandler };
