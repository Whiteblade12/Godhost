/**
 * DDoS guard: any IP sending more than 200 requests in 10 minutes
 * is hard-blocked for 3 HOURS. Enforced in-process (works behind
 * Cloudflare too — pair it with the Cloudflare WAF rule in /cloudflare).
 */
const logger = require('../utils/logger');
const { clientIp } = require('../utils/helpers');
const { sendSecurityAlert, lookupIpInfo } = require('../utils/telegramAlert');

const WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const MAX_REQUESTS = 200;
const BAN_MS = 3 * 60 * 60 * 1000; // 3 hours

/** ip -> { windowStart, count, blockedUntil } */
const ips = new Map();

// Periodic cleanup of stale records so memory stays bounded
const cleaner = setInterval(() => {
  const now = Date.now();
  for (const [ip, rec] of ips.entries()) {
    if (rec.blockedUntil < now && now - rec.windowStart > WINDOW_MS) ips.delete(ip);
  }
}, 30 * 60 * 1000);
cleaner.unref();

function ddosGuard(req, res, next) {
  const ip = clientIp(req) || 'unknown';
  const now = Date.now();
  let rec = ips.get(ip);

  if (rec && rec.blockedUntil > now) {
    const retryAfter = Math.ceil((rec.blockedUntil - now) / 1000);
    res.set('Retry-After', String(retryAfter));
    return res.status(403).json({
      error: `Too many requests. Your IP is blocked for 3 hours (retry in ${Math.ceil(retryAfter / 60)} min).`,
      blocked: true,
    });
  }

  if (!rec || now - rec.windowStart > WINDOW_MS) {
    rec = { windowStart: now, count: 0, blockedUntil: 0 };
    ips.set(ip, rec);
  }

  rec.count += 1;
  if (rec.count > MAX_REQUESTS) {
    rec.blockedUntil = now + BAN_MS;
    rec.count = 0;
    logger.warn(`DDoS guard: IP ${ip} BLOCKED for 3 hours (> ${MAX_REQUESTS} req / 10 min)`);
    // TRIGGER B: Telegram ping with full ISP + location logs
    lookupIpInfo(ip)
      .then((geo) =>
        sendSecurityAlert(
          `🌊 *DDoS Mitigation Engaged*

` +
          `🌐 IP: \`${ip}\` blacklisted for *3 hours*
` +
          `📊 Rule: >${MAX_REQUESTS} requests / 10 min
` +
          `⛔ Traffic dropped at middleware layer${geo}`
        )
      )
      .catch(() => {});
    res.set('Retry-After', String(BAN_MS / 1000));
    return res.status(403).json({
      error: 'Rate limit exceeded (>200 requests / 10 min). Your IP is blocked for 3 hours.',
      blocked: true,
    });
  }

  return next();
}

function getSecurityStats() {
  const now = Date.now();
  const blocked = [];
  let tracked = 0;
  for (const [ip, rec] of ips.entries()) {
    tracked += 1;
    if (rec.blockedUntil > now) {
      blocked.push({ ip, blockedUntil: new Date(rec.blockedUntil).toISOString(), minutesLeft: Math.ceil((rec.blockedUntil - now) / 60000) });
    }
  }
  return {
    rule: `>${MAX_REQUESTS} requests / 10 min → 3 hour IP ban`,
    trackedIps: tracked,
    blockedCount: blocked.length,
    blockedIps: blocked.slice(0, 100),
  };
}

module.exports = { ddosGuard, getSecurityStats };
