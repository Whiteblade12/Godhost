/**
 * Admin authentication for /admin/auth/.
 * - Access requires: email in ADMIN_EMAILS  +  correct password.
 * - The password is stored ONLY on the API side (backend .env) as a
 *   scrypt hash — the frontend never contains or sees it.
 *   Generate the hash with:  npm run admin:hash
 * - Successful login issues a short-lived admin JWT in an HttpOnly cookie.
 */
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const logger = require('../utils/logger');
const { asyncHandler, clientIp } = require('../utils/helpers');
const { verifyToken } = require('./auth');
const User = require('../models/User');
const { sendSecurityAlert } = require('../utils/telegramAlert');

const COOKIE_NAME = 'gh_admin_token';
const TOKEN_TTL = '12h';

function adminSecret() {
  return process.env.ADMIN_JWT_SECRET || `${process.env.JWT_SECRET || 'dev'}::admin`;
}

function adminEmails() {
  return (process.env.ADMIN_EMAILS || '')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

/** scrypt hash format: scrypt:<saltHex>:<hashHex> */
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 64);
  return `scrypt:${salt.toString('hex')}:${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  if (!stored || !password) return false;
  try {
    if (stored.startsWith('scrypt:')) {
      const [, saltHex, hashHex] = stored.split(':');
      const expected = Buffer.from(hashHex, 'hex');
      const actual = crypto.scryptSync(String(password), Buffer.from(saltHex, 'hex'), expected.length);
      return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
    }
    // Dev-only plaintext fallback (ADMIN_PASSWORD). NEVER use in production.
    const a = Buffer.from(String(stored));
    const b = Buffer.from(String(password));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

function configuredSecret() {
  return process.env.ADMIN_PASSWORD_HASH || process.env.ADMIN_PASSWORD || null;
}

function signAdminToken(email) {
  return jwt.sign({ email, role: 'admin' }, adminSecret(), { expiresIn: TOKEN_TTL });
}

/**
 * Brute-force protection: max 5 login attempts per IP in a rolling 1-hour
 * window. The 6th attempt is hard-blocked at the middleware layer for
 * 60 minutes — brute-forcing the key becomes mathematically impossible.
 */
const loginRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({
      error: 'admin_lockout',
      message: 'Maximum authentication attempt limits breached. Portal locked for 60 minutes.',
    });
  },
});

/** Middleware: require a valid admin session (cookie or Bearer). */
const adminAuth = asyncHandler(async (req, res, next) => {
  const token =
    (req.cookies && req.cookies[COOKIE_NAME]) ||
    (req.headers.authorization || '').replace(/^Bearer\s+/i, '') ||
    null;

  if (!token) return res.status(401).json({ error: 'Admin login required' });

  // TRIGGER C: a logged-in STANDARD user probing admin endpoints ->
  // drop the connection and alert Telegram with their identity.
  const payload0 = verifyToken(token);
  if (payload0 && payload0.role !== 'admin' && payload0.uid) {
    const probeUser = await User.findById(payload0.uid).catch(() => null);
    if (probeUser) {
      sendSecurityAlert(
        `🚨 *Unauthorized Admin Access Attempt*

` +
        `👤 User: #${probeUser.id} — ${probeUser.email}
` +
        `🔎 Path: \`${req.originalUrl}\`
` +
        `🌐 IP: ${clientIp(req) || 'unknown'}`
      ).catch(() => {});
      logger.warn(`Trigger C: user #${probeUser.id} probed ${req.originalUrl}`);
      return res.status(403).json({ error: 'admin_only', message: 'This area is restricted.' });
    }
  }

  let payload = null;
  try {
    payload = jwt.verify(token, adminSecret());
  } catch {
    res.clearCookie(COOKIE_NAME);
    return res.status(401).json({ error: 'Admin session expired. Log in again.' });
  }

  if (payload.role !== 'admin' || !adminEmails().includes(String(payload.email).toLowerCase())) {
    return res.status(403).json({ error: 'This account is not an admin.' });
  }

  req.admin = { email: payload.email };
  return next();
});

module.exports = {
  COOKIE_NAME,
  adminAuth,
  loginRateLimiter,
  adminEmails,
  hashPassword,
  verifyPassword,
  configuredSecret,
  signAdminToken,
};
