/**
 * Anti-hacking shield:
 * - Blocks common attack signatures in URLs/queries (SQLi, XSS, path
 *   traversal, JNDI/Log4Shell, /etc/passwd probes).
 * - Blocks well-known scanner paths (.env, .git, wp-admin, phpmyadmin...).
 * - Sends HSTS + nosniff headers in production.
 * NOTE: only inspects the URL/query string — never the JSON body — so
 * users can still save Python code containing these strings.
 */
const logger = require('../utils/logger');

const ATTACK_PATTERNS = [
  /(\.\.\/|\.\.\\)/i, // path traversal
  /(<script\b|javascript:|onerror\s*=|onload\s*=)/i, // XSS probes
  /(union\s+(all\s+)?select|insert\s+into|drop\s+table|;\s*delete\s+from|truncate\s+table)/i, // SQLi
  /(\$\{jndi:|\/etc\/passwd|\/proc\/self|cmd\.exe|powershell\s+-)/i, // RFI/LFI/Log4Shell
  /(<%|%>|\/bin\/sh\b|base64_decode\s*\()/i,
];

const BLOCKED_PATHS = [
  '/.env', '/.git', '/wp-admin', '/wp-login', '/phpmyadmin', '/administrator',
  '/.aws', '/.ssh', '/actuator', '/xmlrpc.php', '/wp-json', '/solr/', '/console',
];

function shield(req, res, next) {
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  const url = req.originalUrl || '';
  const path = req.path || '';

  if (BLOCKED_PATHS.some((p) => path.toLowerCase().startsWith(p))) {
    logger.warn(`Shield: blocked probe ${path} from ${req.ip}`);
    return res.status(404).json({ error: 'Not found' });
  }

  // Only inspect the part before any body content (URL + query)
  const target = url.split('?')[0] + (url.includes('?') ? '?' + url.split('?').slice(1).join('?') : '');
  if (ATTACK_PATTERNS.some((p) => p.test(decodeURIComponent(target)))) {
    logger.warn(`Shield: attack signature blocked: ${url.slice(0, 120)} from ${req.ip}`);
    return res.status(403).json({ error: 'Request blocked by security filter' });
  }

  return next();
}

module.exports = shield;
