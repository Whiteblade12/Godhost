/**
 * Server-side ad rules enforcement.
 * - requireAdClean: blocks actions for ad-supported plans when the client has
 *   reported an active ad blocker (or never reported a clean check).
 * - requireAdsVerified: ensures enough verified ad watches exist for an action.
 */
const { PLANS, AD_ACTIONS, AD_DURATION_SECONDS } = require('../config/constants');
const AdWatch = require('../models/AdWatch');
const { hoursBetween, asyncHandler } = require('../utils/helpers');

function planOf(user) {
  return PLANS[user.plan_type] || PLANS.free;
}

/** For ad-supported plans, the client must have reported a clean check recently. */
const requireAdClean = asyncHandler(async (req, res, next) => {
  const plan = planOf(req.user);
  if (!plan.ads) return next(); // Platinum/Diamond: always allowed

  const { adblocker_detected: detected, adblocker_detected_at: detectedAt } = req.user;

  if (detected === true) {
    return res.status(403).json({
      error: 'adblocker_detected',
      message:
        'Ad blocker detected. GodHosting is free because of ads. Disable your ad blocker, ' +
        'or upgrade to Platinum/Diamond for an ad-free experience.',
    });
  }

  // No clean check ever recorded, or the last check is stale (> 5 minutes).
  const stale = !detectedAt || hoursBetween(detectedAt, new Date()) > 5 / 60;
  if (stale) {
    return res.status(403).json({
      error: 'ad_check_required',
      message: 'Ad-blocker verification needed. Refresh the page to continue.',
    });
  }

  return next();
});

/** Verify that `count` verified ad watches exist for this action (plan-aware). */
function adsNeededFor(plan, action) {
  const rule = AD_ACTIONS[action];
  if (!rule) return { required: false, count: 0, duration: AD_DURATION_SECONDS };
  if (!plan.ads || !rule.plans.includes(plan.id)) {
    return { required: false, count: 0, duration: AD_DURATION_SECONDS };
  }
  const count = rule.planBased ? plan.restartAds || 1 : rule.count || 1;
  if (count <= 0) return { required: false, count: 0, duration: AD_DURATION_SECONDS };
  return { required: true, count, duration: AD_DURATION_SECONDS };
}

function requireAdsVerified(action) {
  return asyncHandler(async (req, res, next) => {
    const plan = planOf(req.user);
    const need = adsNeededFor(plan, action);
    if (!need.required) return next();

    const provided = Array.isArray(req.body.adWatchIds) ? req.body.adWatchIds : [];
    const recent = await AdWatch.recentVerified(req.user.id, action, 10);
    const recentIds = new Set(recent.map((w) => w.id));
    const valid = provided.filter((id) => recentIds.has(Number(id)));

    if (valid.length < need.count) {
      return res.status(402).json({
        error: 'ads_required',
        adsRequired: { action, count: need.count, duration: need.duration },
        message: `Watch ${need.count} ad${need.count > 1 ? 's' : ''} (${need.count * need.duration}s) to continue.`,
      });
    }
    req.adWatchIds = valid;
    return next();
  });
}

module.exports = { requireAdClean, requireAdsVerified, adsNeededFor };
