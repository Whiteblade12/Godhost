/** HTTP request logging middleware. */
const logger = require('../utils/logger');
const { clientIp } = require('../utils/helpers');

function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const level = res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info';
    logger[level](`${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms`, {
      ip: clientIp(req),
    });
  });
  next();
}

module.exports = requestLogger;
