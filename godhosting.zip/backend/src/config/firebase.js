/** Firebase Admin SDK initialisation (optional - enables Google login verification). */
const logger = require('../utils/logger');

let admin = null;
let initialized = false;

function getFirebaseAdmin() {
  if (initialized) return admin;
  initialized = true;
  try {
    const firebaseAdmin = require('firebase-admin');
    const projectId = process.env.FIREBASE_PROJECT_ID;
    const privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;

    if (projectId && privateKey && clientEmail && privateKey.includes('PRIVATE KEY')) {
      admin = firebaseAdmin.initializeApp({
        credential: firebaseAdmin.credential.cert({
          projectId,
          privateKey,
          clientEmail,
        }),
      });
      logger.info('Firebase Admin SDK initialized');
    } else {
      logger.warn(
        'Firebase Admin SDK not configured - Google login verification disabled.' +
          (process.env.DEMO_MODE === 'true' ? ' DEMO_MODE logins enabled.' : '')
      );
      admin = null;
    }
  } catch (err) {
    logger.error('Failed to initialize Firebase Admin SDK', { error: err.message });
    admin = null;
  }
  return admin;
}

async function verifyIdToken(idToken) {
  const app = getFirebaseAdmin();
  if (!app) return null;
  const auth = app.auth();
  return auth.verifyIdToken(idToken);
}

module.exports = { getFirebaseAdmin, verifyIdToken };
