/**
 * GodHosting - global constants & plan definitions.
 * Prices can be overridden at runtime via the admin API
 * (persisted in the `plan_config` table and merged on boot).
 */

const CONTACT = {
  domain: 'godhosting.online',
  email: 'godhostings@gmail.com',
  telegram: 'https://t.me/TheGoat_father',
  telegramHandle: '@TheGoat_father',
};

const PLANS = {
  free: {
    id: 'free',
    name: 'Free',
    price: 0,
    storageLimit: 314572800, // 300 MB
    storageLabel: '300 MB',
    maxBots: 1,
    autoStopHours: 24,
    ads: true,
    adblockerAllowed: false,
    support247: false,
    websiteOpenAd: true,
    restartAds: 3,
    actionAds: 1,
    color: '#8892b0',
    tagline: 'Get started free, forever',
    features: [
      '1 Telegram bot',
      '300 MB storage',
      'main.py + requirements.txt',
      '5-second ads on actions',
      'Bot auto-stops after 24h',
      '3 ads (15s) to restart',
      'Earn ₹3 per 7-day referral streak',
      'Watch ads & earn ₹0.25 per 5 ads',
    ],
  },
  silver: {
    id: 'silver',
    name: 'Silver',
    price: 30,
    storageLimit: 524288000, // 500 MB
    storageLabel: '500 MB',
    maxBots: 5,
    autoStopHours: 0,
    ads: true,
    adblockerAllowed: false,
    support247: false,
    websiteOpenAd: false,
    restartAds: 1,
    actionAds: 1,
    color: '#cbd5e1',
    tagline: 'More bots, no auto-stop',
    features: [
      'Up to 5 Telegram bots',
      '500 MB storage',
      'No 24h auto-stop',
      '5-second ads on actions',
      '1 ad (5s) to restart',
      'Earn ₹3 per 7-day referral streak',
      'Watch ads & earn ₹0.25 per 5 ads',
    ],
  },
  gold: {
    id: 'gold',
    name: 'Gold',
    price: 50,
    storageLimit: 786432000, // 750 MB
    storageLabel: '750 MB',
    maxBots: 10,
    autoStopHours: 0,
    ads: true,
    adblockerAllowed: false,
    support247: true,
    websiteOpenAd: false,
    restartAds: 1,
    actionAds: 1,
    color: '#f7971e',
    tagline: 'Best value for creators',
    features: [
      'Up to 10 Telegram bots',
      '750 MB storage',
      'No 24h auto-stop',
      '5-second ads on actions',
      '1 ad (5s) to restart',
      '24/7 priority support',
      'Earn ₹3 per 7-day referral streak',
      'Watch ads & earn ₹0.25 per 5 ads',
    ],
  },
  diamond: {
    id: 'diamond',
    name: 'Diamond',
    price: 100,
    storageLimit: 1073741824, // 1 GB
    storageLabel: '1 GB',
    maxBots: 999,
    autoStopHours: 0,
    ads: false,
    adblockerAllowed: true,
    support247: true,
    websiteOpenAd: false,
    restartAds: 0,
    actionAds: 0,
    color: '#a855f7',
    tagline: 'Unlimited power, zero ads',
    features: [
      'Unlimited Telegram bots',
      '1 GB storage',
      'ZERO ads — ever',
      'Ad blocker allowed',
      'No 24h auto-stop',
      '24/7 priority support',
      'Earn ₹3 per 7-day referral streak',
    ],
  },
};

const PLAN_ORDER = ['free', 'silver', 'gold', 'diamond'];

const AD_DURATION_SECONDS = parseInt(process.env.AD_DURATION || '5', 10);

/** Ads required per action (count may be plan-dependent for restart). */
const AD_ACTIONS = {
  website_open: { plans: ['free'], count: 1 },
  deploy: { plans: ['free', 'silver', 'gold'], count: 1 },
  start: { plans: ['free', 'silver', 'gold'], count: 1 },
  restart: { plans: ['free', 'silver', 'gold'], planBased: true },
  scroll_logs: { plans: ['free', 'silver', 'gold'], count: 1 },
  file_manager: { plans: ['free', 'silver', 'gold'], count: 1 },
};

const UPI = {
  id: process.env.UPI_ID || 'godhostings@upi',
  name: process.env.UPI_NAME || 'GodHosting',
};

/** Referral program: referred user logs in 7 consecutive days -> referrer earns this. */
const REFERRAL_BONUS = parseFloat(process.env.REFERRAL_BONUS || '3.00');
/** Consecutive active days required to complete a referral. */
const REFERRAL_STREAK_DAYS = parseInt(process.env.REFERRAL_STREAK_DAYS || '7', 10);

/** Watch-to-Win rewarded ads: watch N x 15s ads -> earn ₹ payout into wallet. */
const REWARD_ADS_NEEDED = parseInt(process.env.REWARD_ADS_NEEDED || '5', 10);
const REWARD_AD_DURATION = parseInt(process.env.REWARD_AD_DURATION || '15', 10);
const REWARD_AD_PAYOUT = parseFloat(process.env.REWARD_AD_PAYOUT || '0.25');

const ALLOWED_FILES = ['main.py', 'requirements.txt'];

module.exports = {
  CONTACT,
  PLANS,
  PLAN_ORDER,
  AD_DURATION_SECONDS,
  AD_ACTIONS,
  UPI,
  REFERRAL_BONUS,
  REFERRAL_STREAK_DAYS,
  REWARD_ADS_NEEDED,
  REWARD_AD_DURATION,
  REWARD_AD_PAYOUT,
  ALLOWED_FILES,
};
