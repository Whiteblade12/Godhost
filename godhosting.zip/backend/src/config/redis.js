/** Optional Redis client (used for caching/rate-limit counters when REDIS_URL is set). */
const logger = require('../utils/logger');

let client = null;

function getRedis() {
  if (client !== undefined && client !== null) return client;
  const url = process.env.REDIS_URL;
  if (!url) {
    client = null;
    return null;
  }
  try {
    // Lazy require so the dependency stays optional
    const { createClient } = require('redis');
    client = createClient({ url });
    client.on('error', (err) => logger.warn('Redis error', { error: err.message }));
    client.connect().catch((err) => logger.warn('Redis connect failed', { error: err.message }));
    logger.info('Redis client connecting');
  } catch (err) {
    logger.warn('Redis unavailable - continuing without cache', { error: err.message });
    client = null;
  }
  return client;
}

module.exports = { getRedis };
