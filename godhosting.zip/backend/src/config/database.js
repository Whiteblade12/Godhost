/** PostgreSQL connection pool. */
const { Pool } = require('pg');
const logger = require('../utils/logger');

const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    'postgresql://postgres:postgres@localhost:5432/godhosting',
  max: parseInt(process.env.DATABASE_MAX_CONNECTIONS || '20', 10),
  idleTimeoutMillis: parseInt(process.env.DATABASE_IDLE_TIMEOUT || '30000', 10),
  ssl:
    process.env.NODE_ENV === 'production' && !/localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL || '')
      ? { rejectUnauthorized: false }
      : false,
});

pool.on('error', (err) => {
  logger.error('Unexpected PostgreSQL pool error', { error: err.message });
});

async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  if (process.env.LOG_LEVEL === 'debug') {
    logger.debug('executed query', {
      text: text.split('\n')[0].slice(0, 80),
      duration: Date.now() - start,
      rows: res.rowCount,
    });
  }
  return res;
}

async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, withTransaction };
