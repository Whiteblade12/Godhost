/** Admin routes: stats, users, plans, payments, security. Protected by adminAuth (email + password session). */
const express = require('express');
const { adminAuth } = require('../middleware/adminAuth');
const { getSecurityStats } = require('../middleware/ddosGuard');
const { asyncHandler } = require('../utils/helpers');
const User = require('../models/User');
const Bot = require('../models/Bot');
const Payment = require('../models/Payment');
const AdWatch = require('../models/AdWatch');
const { updatePrice, allPlans, getPlan } = require('../services/planLimits');
const { PLANS } = require('../config/constants');
const { addDays } = require('../utils/helpers');
const ActivityLog = require('../models/ActivityLog');

const router = express.Router();
router.use(adminAuth);

/** GET /api/admin/users */
router.get(
  '/users',
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit || '50', 10), 200);
    const offset = parseInt(req.query.offset || '0', 10);
    const [users, total] = await Promise.all([User.list(limit, offset), User.count()]);
    res.json({ users, total, limit, offset });
  })
);

/** GET /api/admin/stats */
router.get(
  '/stats',
  asyncHandler(async (req, res) => {
    const [users, bots, running, revenue, adsWatched] = await Promise.all([
      User.count(),
      Bot.totalCount(),
      Bot.runningCount(),
      Payment.totalRevenue(),
      AdWatch.totalCompleted(),
    ]);
    res.json({
      users,
      bots,
      runningBots: running,
      revenueINR: revenue,
      adsWatched,
      plans: allPlans(),
    });
  })
);

/** POST /api/admin/plans - update a plan price */
router.post(
  '/plans',
  asyncHandler(async (req, res) => {
    const { planType, price } = req.body || {};
    const plan = await updatePrice(String(planType), parseInt(price, 10));
    res.json({ plan });
  })
);

/** GET /api/admin/ad-revenue */
router.get(
  '/ad-revenue',
  asyncHandler(async (req, res) => {
    const adsWatched = await AdWatch.totalCompleted();
    // Estimated revenue: assume ~₹0.10 per completed ad view (configurable model)
    const estimatedINR = Math.round(adsWatched * 0.1 * 100) / 100;
    res.json({ adsWatched, estimatedINR, note: 'Estimate at ₹0.10 per completed view' });
  })
);

/** GET /api/admin/payments - review all payments */
router.get(
  '/payments',
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit || '100', 10), 500);
    const payments = await Payment.allWithUsers(limit);
    res.json({ payments });
  })
);

/** POST /api/admin/payments/:id/reject - reject/refund a payment */
router.post(
  '/payments/:id/reject',
  asyncHandler(async (req, res) => {
    const payment = await Payment.rejectById(Number(req.params.id));
    if (!payment) return res.status(404).json({ error: 'Payment not found' });
    await ActivityLog.log(req.user.id, 'admin_payment_reject', {
      details: { paymentId: payment.payment_id },
    });
    res.json({ payment });
  })
);

/** POST /api/admin/users/:id/plan - manually set a user's plan (support) */
router.post(
  '/users/:id/plan',
  asyncHandler(async (req, res) => {
    const { planType, days } = req.body || {};
    if (!PLANS[String(planType)]) return res.status(400).json({ error: 'Invalid planType' });
    const d = Math.min(Math.max(parseInt(days || '30', 10) || 30, 1), 3650);
    const target = await User.findById(Number(req.params.id));
    if (!target) return res.status(404).json({ error: 'User not found' });
    const expiry = planType === 'free' ? null : addDays(new Date(), d);
    const user = await User.applyPlan(target.id, String(planType), expiry);
    await ActivityLog.log(req.user.id, 'admin_plan_override', {
      details: { targetUser: target.id, planType, days: d },
    });
    res.json({ user: { id: user.id, email: user.email, planType: user.plan_type, planExpiry: user.plan_expiry } });
  })
);

/** POST /api/admin/users/:id/settle-wallet - mark wallet paid out (zeroes it) */
router.post(
  '/users/:id/settle-wallet',
  asyncHandler(async (req, res) => {
    const { query: q } = require('../config/database');
    const target = await User.findById(Number(req.params.id));
    if (!target) return res.status(404).json({ error: 'User not found' });
    const w = await User.wallet(target.id);
    if (w.balance <= 0) return res.status(400).json({ error: 'Wallet is empty' });
    await q('UPDATE users SET wallet_balance = 0 WHERE id = $1', [target.id]);
    await q(
      `INSERT INTO wallet_transactions (user_id, amount, transaction_type) VALUES ($1, $2, 'payout_sent')`,
      [target.id, -w.balance]
    );
    await ActivityLog.log(req.user && req.user.id ? req.user.id : target.id, 'admin_wallet_settle', {
      details: { targetUser: target.id, amount: w.balance },
    });
    res.json({ ok: true, settled: w.balance });
  })
);

/** GET /api/admin/security - DDoS guard status & banned IPs */
router.get('/security', (req, res) => {
  res.json(getSecurityStats());
});

module.exports = router;
