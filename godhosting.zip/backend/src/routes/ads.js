/** Ad routes: requirement checks, watch sessions, ad-blocker reports. */
const express = require('express');
const { authenticate } = require('../middleware/auth');
const { validateAdWatch, handleValidation } = require('../utils/validators');
const { asyncHandler } = require('../utils/helpers');
const adManager = require('../services/adManager');
const { getPlan } = require('../services/planLimits');

const router = express.Router();

/**
 * GET /api/ads/test
 * Lightweight endpoint used by the client's fetch-based ad-blocker test.
 * Must be reachable (204) when no blocker is active.
 */
router.all('/test', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.status(204).end();
});

/** GET /api/ads/check - are ads required for this user at all? */
router.get('/check', authenticate, (req, res) => {
  const plan = getPlan(req.user.plan_type);
  res.json({
    required: plan.ads,
    plan: plan.id,
    adblockerDetected: req.user.adblocker_detected,
    adblockerAllowed: plan.adblockerAllowed,
  });
});

/** GET /api/ads/status?action=start&botId=1 - ads needed for a specific action */
router.get('/status', authenticate, (req, res) => {
  const action = String(req.query.action || 'start');
  res.json(adManager.statusForAction(req.user, action));
});

/** POST /api/ads/watch - begin an ad watch session */
router.post(
  '/watch',
  authenticate,
  validateAdWatch,
  handleValidation,
  asyncHandler(async (req, res) => {
    const result = await adManager.startWatch(req, req.body.action, req.body.botId || null);
    res.json(result);
  })
);

/** POST /api/ads/complete - mark an ad watch finished (server verifies timing) */
router.post(
  '/complete',
  authenticate,
  asyncHandler(async (req, res) => {
    const { adWatchId } = req.body || {};
    if (!adWatchId) return res.status(400).json({ error: 'adWatchId required' });
    const result = await adManager.completeWatch(req.user, Number(adWatchId));
    if (!result.verified && !result.alreadyCompleted) {
      return res.status(400).json({
        error: 'Ad not watched long enough',
        elapsedSeconds: result.elapsedSeconds,
      });
    }
    return res.json(result);
  })
);

/** POST /api/ads/adblocker - client reports detection result */
router.post(
  '/adblocker',
  authenticate,
  asyncHandler(async (req, res) => {
    const { detected, methods } = req.body || {};
    const result = await adManager.reportAdBlocker(req.user, !!detected, Array.isArray(methods) ? methods : []);
    res.json(result);
  })
);

module.exports = router;
