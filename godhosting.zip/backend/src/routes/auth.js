/** Authentication routes: Google (Firebase) login, session info, logout. */
const express = require('express');
const { verifyIdToken } = require('../config/firebase');
const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');
const { signToken, authenticate } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimit');
const { asyncHandler, clientIp, isEmail, sanitizeName } = require('../utils/helpers');
const { getPlan } = require('../services/planLimits');
const logger = require('../utils/logger');

const router = express.Router();

function publicUser(user) {
  return {
    id: user.id,
    email: user.email,
    displayName: user.display_name,
    planType: user.plan_type,
    planExpiry: user.plan_expiry,
    storageUsed: Number(user.storage_used || 0),
    storageLimit: Number(user.storage_limit || 0),
    maxBots: user.max_bots,
    referralCode: user.referral_code,
    adsEnabled: user.ads_enabled,
    adblockerDetected: user.adblocker_detected,
    createdAt: user.created_at,
    plan: getPlan(user.plan_type),
  };
}

/**
 * POST /api/auth/google
 * Body: { idToken }  (Firebase Google sign-in ID token)
 * In DEMO_MODE without Firebase: { demoEmail, demoName?, referralCode? }
 */
router.post(
  '/google',
  authLimiter,
  asyncHandler(async (req, res) => {
    const { idToken, demoEmail, demoName, referralCode } = req.body || {};
    let firebaseUid = null;
    let email = null;
    let name = null;

    if (idToken) {
      const decoded = await verifyIdToken(idToken);
      if (!decoded) return res.status(401).json({ error: 'Invalid Google ID token' });
      firebaseUid = decoded.uid;
      email = decoded.email;
      name = decoded.name || null;
    } else if (process.env.DEMO_MODE === 'true' && demoEmail && isEmail(demoEmail)) {
      firebaseUid = `demo-${demoEmail.toLowerCase()}`;
      email = demoEmail.toLowerCase();
      name = demoName || email.split('@')[0];
      logger.warn('DEMO_MODE login used', { email });
    } else {
      return res.status(400).json({ error: 'Google ID token required' });
    }

    const { user, created } = await User.createFromGoogle({
      firebaseUid,
      email,
      displayName: sanitizeName(name || email.split('@')[0]),
      referralCode: referralCode || null,
    });

    await User.touch(user.id);
    await ActivityLog.log(user.id, created ? 'signup' : 'login', {
      ip: clientIp(req),
      userAgent: req.headers['user-agent'] || null,
      details: { created, viaReferral: Boolean(referralCode) },
    });

    const token = signToken(user);
    return res.json({ token, user: publicUser(user), created });
  })
);

/** GET /api/auth/me */
router.get(
  '/me',
  authenticate,
  asyncHandler(async (req, res) => {
    await User.touch(req.user.id);
    res.json({ user: publicUser(req.user) });
  })
);

/** POST /api/auth/logout */
router.post('/logout', authenticate, (req, res) => {
  // Stateless JWTs: client discards the token.
  res.json({ ok: true });
});

/** POST /api/auth/refresh */
router.post(
  '/refresh',
  authenticate,
  asyncHandler(async (req, res) => {
    const fresh = await User.findById(req.user.id);
    res.json({ token: signToken(fresh), user: publicUser(fresh) });
  })
);

module.exports = router;
module.exports.publicUser = publicUser;
