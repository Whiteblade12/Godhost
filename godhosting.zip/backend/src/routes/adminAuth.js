/** Admin login routes mounted at /api/admin/auth (godhosting.online/admin/auth/). */
const express = require('express');
const {
  COOKIE_NAME,
  adminAuth,
  loginRateLimiter,
  adminEmails,
  verifyPassword,
  configuredSecret,
  signAdminToken,
} = require('../middleware/adminAuth');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler, clientIp } = require('../utils/helpers');
const logger = require('../utils/logger');
const { sendSecurityAlert } = require('../utils/telegramAlert');

const router = express.Router();

/** POST /api/admin/auth/login { email, password } */
router.post(
  '/login',
  loginRateLimiter,
  asyncHandler(async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    const stored = configuredSecret();
    const emailOk = adminEmails().includes(email);
    const passOk = verifyPassword(password, stored);

    // Same response shape for all failures (prevents account enumeration)
    if (!emailOk || !passOk) {
      const ip = clientIp(req);
      const remaining = req.rateLimit ? Math.max(0, req.rateLimit.remaining) : '?';
      logger.warn(`Failed admin login attempt for "${email}" from ${ip}`);
      // TRIGGER A: instant Telegram ping with email, IP and attempts left
      sendSecurityAlert(
        `🔐 *Failed Admin Login*

` +
        `📧 Email: \`${email || '(empty)'}\`
` +
        `🌐 IP: ${ip || 'unknown'}
` +
        `⏳ Attempts left before 60-min lockout: *${remaining}*`
      ).catch(() => {});
      return res.status(401).json({ error: 'Invalid admin email or password.' });
    }

    const token = signAdminToken(email);
    res.cookie(COOKIE_NAME, token, {
      httpOnly: true, // JS can never read it
      sameSite: 'strict',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 12 * 60 * 60 * 1000,
    });

    logger.info(`Admin login OK: ${email} from ${clientIp(req)}`);
    return res.json({ ok: true, admin: { email }, token });
  })
);

/** GET /api/admin/auth/me */
router.get('/me', adminAuth, (req, res) => {
  res.json({ admin: req.admin });
});

/** POST /api/admin/auth/logout */
router.post('/logout', (req, res) => {
  res.clearCookie(COOKIE_NAME);
  res.json({ ok: true });
});

module.exports = router;
