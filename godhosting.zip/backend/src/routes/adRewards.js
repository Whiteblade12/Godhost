/**
 * Watch-to-Win rewarded ads engine.
 * Users watch 5 x 15-second video ads -> platform credits ₹0.25 to their wallet.
 * Credits only increment on SERVER-VERIFIED completion or on the ad network's
 * server-to-server webhook callback (never on unverified client clicks).
 */
const express = require('express');
const { authenticate } = require('../middleware/auth');
const { query, withTransaction } = require('../config/database');
const AdWatch = require('../models/AdWatch');
const { REWARD_ADS_NEEDED, REWARD_AD_DURATION, REWARD_AD_PAYOUT } = require('../config/constants');
const { asyncHandler, clientIp } = require('../utils/helpers');
const logger = require('../utils/logger');

const router = express.Router();

/** Credit a verified rewarded view; every 5th verified view pays ₹0.25. */
async function creditVerifiedView(client, userId) {
  await client.query('UPDATE users SET pending_ad_clicks = pending_ad_clicks + 1 WHERE id = $1', [userId]);
  const st = await client.query('SELECT pending_ad_clicks FROM users WHERE id = $1', [userId]);
  const clicks = st.rows[0].pending_ad_clicks;
  if (clicks >= REWARD_ADS_NEEDED) {
    await client.query(
      `UPDATE users SET pending_ad_clicks = pending_ad_clicks - $2, wallet_balance = wallet_balance + $3 WHERE id = $1`,
      [userId, REWARD_ADS_NEEDED, REWARD_AD_PAYOUT]
    );
    await client.query(
      `INSERT INTO wallet_transactions (user_id, amount, transaction_type) VALUES ($1, $2, 'watch_reward')`,
      [userId, REWARD_AD_PAYOUT]
    );
    return { credited: true, paidOut: REWARD_AD_PAYOUT };
  }
  return { credited: false, progress: `${clicks}/${REWARD_ADS_NEEDED}` };
}

/** POST /api/ads/reward/watch - begin a 15s rewarded video session */
router.post(
  '/reward/watch',
  authenticate,
  asyncHandler(async (req, res) => {
    const watch = await AdWatch.create({
      userId: req.user.id,
      botId: null,
      action: 'rewarded_video',
      duration: REWARD_AD_DURATION,
      ip: clientIp(req),
      userAgent: req.headers['user-agent'] || null,
    });
    res.json({ adWatchId: watch.id, duration: REWARD_AD_DURATION, adsNeeded: REWARD_ADS_NEEDED });
  })
);

/** POST /api/ads/reward/complete - server verifies the full 15s were watched */
router.post(
  '/reward/complete',
  authenticate,
  asyncHandler(async (req, res) => {
    const { adWatchId } = req.body || {};
    const watch = await AdWatch.findById(Number(adWatchId));
    if (!watch || watch.user_id !== req.user.id) {
      return res.status(404).json({ error: 'Ad watch not found' });
    }
    if (watch.completed) return res.status(400).json({ error: 'Ad already completed' });

    const elapsed = (Date.now() - new Date(watch.watch_start).getTime()) / 1000;
    if (elapsed < watch.ad_duration - 1) {
      return res.status(400).json({ error: 'Ad not watched long enough', elapsedSeconds: Math.round(elapsed) });
    }

    const result = await withTransaction(async (client) => {
      await client.query(
        'UPDATE ad_watches SET watch_end = CURRENT_TIMESTAMP, completed = TRUE, verified = TRUE WHERE id = $1',
        [watch.id]
      );
      const credit = await creditVerifiedView(client, req.user.id);
      const w = await client.query('SELECT wallet_balance::float AS balance, pending_ad_clicks::int AS pending FROM users WHERE id = $1', [req.user.id]);
      return { ...credit, walletBalance: w.rows[0].balance, pendingAdClicks: w.rows[0].pending };
    });

    res.json({ ok: true, ...result, payoutPerCycle: REWARD_AD_PAYOUT, adsNeeded: REWARD_ADS_NEEDED });
  })
);

/**
 * POST /api/ads/webhook - Server-to-Server ad network callback.
 * Body: { userId, adNetworkTxId, rewardVerified }
 * The secure counter increments ONLY when the ad network confirms the view.
 * Duplicate transactions are ignored (idempotent on reference_id).
 */
router.post(
  '/webhook',
  asyncHandler(async (req, res) => {
    // Optional shared-secret check for production ad networks
    const secret = process.env.AD_WEBHOOK_SECRET;
    if (secret && req.headers['x-webhook-secret'] !== secret) {
      return res.status(401).send('Invalid webhook secret.');
    }

    const { userId, adNetworkTxId, rewardVerified } = req.body || {};
    if (!rewardVerified) return res.status(400).send('Verification mismatch flag.');
    if (!userId || !adNetworkTxId) return res.status(400).send('Missing userId or adNetworkTxId.');

    try {
      const result = await withTransaction(async (client) => {
        const dup = await client.query('SELECT id FROM ad_watches WHERE reference_id = $1', [adNetworkTxId]);
        if (dup.rowCount > 0) return { duplicate: true };

        await client.query(
          `INSERT INTO ad_watches (reference_id, user_id, ad_type, ad_duration, completed, verified, watch_start, watch_end)
           VALUES ($1, $2, 'rewarded_video_s2s', $3, TRUE, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
          [adNetworkTxId, userId, REWARD_AD_DURATION]
        );
        const credit = await creditVerifiedView(client, Number(userId));
        return { duplicate: false, ...credit };
      });

      if (result.duplicate) return res.status(200).send('Transaction duplicate logged.');
      logger.info(`S2S ad webhook credited user ${userId} (tx ${adNetworkTxId})`);
      return res.status(200).send('OK');
    } catch (err) {
      logger.error('Ad webhook processing failed: ' + err.message);
      return res.status(500).send('Internal transaction exception processing ad event.');
    }
  })
);

module.exports = router;
