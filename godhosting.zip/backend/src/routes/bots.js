/** Bot routes: CRUD, code, files, lifecycle (start/stop/restart), logs. */
const express = require('express');
const multer = require('multer');
const path = require('path');

const Bot = require('../models/Bot');
const ActivityLog = require('../models/ActivityLog');
const { authenticate } = require('../middleware/auth');
const { requireAdClean, requireAdsVerified } = require('../middleware/adBlocker');
const { actionLimiter } = require('../middleware/rateLimit');
const {
  validateCreateBot,
  validateUpdateBot,
  validateSaveCode,
  handleValidation,
} = require('../utils/validators');
const { asyncHandler } = require('../utils/helpers');
const { getPlan, planActive } = require('../services/planLimits');
const botManager = require('../services/botManager');
const storageManager = require('../services/storageManager');
const { ALLOWED_FILES } = require('../config/constants');

const router = express.Router();
router.use(authenticate);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE || '10485760', 10) },
  fileFilter: (req, file, cb) => {
    const name = path.basename(file.originalname);
    if (!ALLOWED_FILES.includes(name)) {
      return cb(new Error(`Only ${ALLOWED_FILES.join(' and ')} files are supported on GodHosting.`));
    }
    cb(null, true);
  },
});

async function loadBot(req, res, next) {
  const bot = await Bot.findByIdAndUser(Number(req.params.id), req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot not found' });
  req.bot = bot;
  return next();
}

/** GET /api/bots */
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const bots = await Bot.findByUser(req.user.id);
    const plan = getPlan(req.user.plan_type);
    res.json({
      bots: bots.map((b) => {
        const runtime = botManager.getStatus(b.id);
        return {
          id: b.id,
          name: b.name,
          status: runtime.running ? 'running' : 'stopped',
          uptimeSeconds: runtime.uptimeSeconds || 0,
          restartCount: b.restart_count,
          errorCount: b.error_count,
          lastStarted: b.last_started,
          createdAt: b.created_at,
        };
      }),
      limits: {
        maxBots: req.user.max_bots,
        plan: plan.id,
        autoStopHours: plan.autoStopHours,
        canCreate: bots.length < req.user.max_bots,
      },
    });
  })
);

/** POST /api/bots */
router.post(
  '/',
  validateCreateBot,
  handleValidation,
  asyncHandler(async (req, res) => {
    const plan = getPlan(req.user.plan_type);
    if (!planActive(req.user)) {
      return res.status(402).json({ error: 'Your plan has expired. Renew to create bots.' });
    }
    const count = await Bot.countByUser(req.user.id);
    if (count >= req.user.max_bots) {
      return res.status(403).json({
        error: `Bot limit reached (${req.user.max_bots}) on the ${plan.name} plan. Upgrade to add more bots.`,
      });
    }
    const { name, botToken } = req.body;
    const bot = await Bot.create({
      userId: req.user.id,
      name: name.trim(),
      botToken: botToken.trim(),
      code: botManager.DEFAULT_MAIN_PY,
      storagePath: storageManager.botDir(req.user.id, 0), // fixed after insert
    });
    // Write default main.py into the bot's own directory
    storageManager.writeBotFile(req.user, bot.id, 'main.py', Buffer.from(botManager.DEFAULT_MAIN_PY));
    await Bot.update(bot.id, { envVars: {} });
    await storageManager.syncUserUsage(req.user.id);
    await ActivityLog.log(req.user.id, 'bot_create', { botId: bot.id, details: { name } });
    res.status(201).json({ bot: { id: bot.id, name: bot.name, status: 'stopped', createdAt: bot.created_at } });
  })
);

/** GET /api/bots/:id */
router.get(
  '/:id',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const bot = req.bot;
    const runtime = botManager.getStatus(bot.id);
    const plan = getPlan(req.user.plan_type);
    const diskCode = storageManager.readBotFile(req.user, bot.id, 'main.py');
    res.json({
      bot: {
        id: bot.id,
        name: bot.name,
        botToken: `${String(bot.bot_token).slice(0, 10)}...`,
        hasToken: Boolean(bot.bot_token),
        status: runtime.running ? 'running' : 'stopped',
        running: runtime.running,
        uptimeSeconds: runtime.uptimeSeconds || 0,
        code: diskCode ? diskCode.toString('utf8') : bot.code || '',
        envVars: bot.env_vars || {},
        restartCount: bot.restart_count,
        errorCount: bot.error_count,
        lastStarted: bot.last_started,
        createdAt: bot.created_at,
        autoStopHours: plan.autoStopHours,
      },
      files: storageManager.listBotFiles(req.user, bot.id),
    });
  })
);

/** PUT /api/bots/:id - update name/token/env */
router.put(
  '/:id',
  validateUpdateBot,
  handleValidation,
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const bot = await Bot.update(req.bot.id, {
      name: req.body.name,
      botToken: req.body.botToken,
      envVars: req.body.envVars,
    });
    await ActivityLog.log(req.user.id, 'bot_update', { botId: bot.id });
    res.json({ bot: { id: bot.id, name: bot.name, status: bot.status } });
  })
);

/** PUT /api/bots/:id/config - alias for config updates */
router.put(
  '/:id/config',
  validateUpdateBot,
  handleValidation,
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const bot = await Bot.update(req.bot.id, {
      name: req.body.name,
      botToken: req.body.botToken,
      envVars: req.body.envVars,
    });
    res.json({ bot: { id: bot.id, name: bot.name } });
  })
);

/** POST /api/bots/:id/code - save main.py or requirements.txt content */
router.post(
  '/:id/code',
  validateSaveCode,
  handleValidation,
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const filename = req.body.filename === 'requirements.txt' ? 'requirements.txt' : 'main.py';
    await storageManager.assertCapacity(req.user, Buffer.byteLength(req.body.code || '', 'utf8'));
    storageManager.writeBotFile(req.user, req.bot.id, filename, Buffer.from(req.body.code || '', 'utf8'));
    if (filename === 'main.py') await Bot.updateCode(req.bot.id, req.body.code || '');
    await ActivityLog.log(req.user.id, 'code_save', { botId: req.bot.id, details: { filename } });
    res.json({ ok: true, filename });
  })
);

/** POST /api/bots/:id/start (requires verified ads for free/silver/gold) */
router.post(
  '/:id/start',
  actionLimiter,
  requireAdClean,
  requireAdsVerified('start'),
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    if (botManager.isRunning(req.bot.id)) {
      return res.json({ bot: { id: req.bot.id, status: 'running' }, alreadyRunning: true });
    }
    const result = await botManager.startBot(req.bot, { userId: req.user.id });
    res.json({ bot: { id: req.bot.id, status: 'running', pid: result.pid } });
  })
);

/** POST /api/bots/:id/stop */
router.post(
  '/:id/stop',
  actionLimiter,
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    await botManager.stopBot(req.bot, { userId: req.user.id });
    res.json({ bot: { id: req.bot.id, status: 'stopped' } });
  })
);

/** POST /api/bots/:id/restart (free: 3 ads, silver/gold: 1 ad) */
router.post(
  '/:id/restart',
  actionLimiter,
  requireAdClean,
  requireAdsVerified('restart'),
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    await botManager.restartBot(req.bot, { userId: req.user.id });
    await ActivityLog.log(req.user.id, 'bot_restart', { botId: req.bot.id });
    res.json({ bot: { id: req.bot.id, status: 'running' } });
  })
);

/** DELETE /api/bots/:id */
router.delete(
  '/:id',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    await botManager.stopBot(req.bot, { silent: true });
    await Bot.remove(req.bot.id);
    await storageManager.removeBotDir(req.user.id, req.bot.id);
    await ActivityLog.log(req.user.id, 'bot_delete', { botId: req.bot.id });
    res.json({ ok: true });
  })
);

/** GET /api/bots/:id/logs?tail=200 */
router.get(
  '/:id/logs',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const tail = Math.min(parseInt(req.query.tail || '200', 10), 1000);
    res.json({ logs: botManager.getLogs(req.bot.id, tail) });
  })
);

/** POST /api/bots/:id/upload - multipart upload of main.py or requirements.txt */
router.post(
  '/:id/upload',
  asyncHandler(loadBot),
  (req, res, next) => {
    upload.single('file')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      return next();
    });
  },
  asyncHandler(async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const filename = path.basename(req.file.originalname);
    await storageManager.assertCapacity(req.user, req.file.size);
    storageManager.writeBotFile(req.user, req.bot.id, filename, req.file.buffer);
    if (filename === 'main.py') await Bot.updateCode(req.bot.id, req.file.buffer.toString('utf8'));
    await ActivityLog.log(req.user.id, 'file_upload', { botId: req.bot.id, details: { filename } });
    res.json({ ok: true, filename, size: req.file.size });
  })
);

/** GET /api/bots/:id/files */
router.get(
  '/:id/files',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    res.json({ files: storageManager.listBotFiles(req.user, req.bot.id) });
  })
);

/** GET /api/bots/:id/files/:name - download a bot file */
router.get(
  '/:id/files/:name',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const name = path.basename(req.params.name);
    const buffer = storageManager.readBotFile(req.user, req.bot.id, name);
    if (!buffer) return res.status(404).json({ error: 'File not found' });
    res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    return res.send(buffer);
  })
);

/** DELETE /api/bots/:id/files */
router.delete(
  '/:id/files',
  asyncHandler(loadBot),
  asyncHandler(async (req, res) => {
    const filename = path.basename(String(req.body.filename || ''));
    if (!ALLOWED_FILES.includes(filename)) {
      return res.status(400).json({ error: `Only ${ALLOWED_FILES.join(' and ')} are managed here.` });
    }
    storageManager.deleteBotFile(req.user, req.bot.id, filename);
    await ActivityLog.log(req.user.id, 'file_delete', { botId: req.bot.id, details: { filename } });
    res.json({ ok: true });
  })
);

module.exports = router;
