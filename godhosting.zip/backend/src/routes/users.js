/** User profile routes. */
const express = require('express');
const User = require('../models/User');
const Bot = require('../models/Bot');
const AdWatch = require('../models/AdWatch');
const ActivityLog = require('../models/ActivityLog');
const Referral = require('../models/Referral');
const { authenticate } = require('../middleware/auth');
const { validateProfile, handleValidation } = require('../utils/validators');
const { asyncHandler, sanitizeName } = require('../utils/helpers');
const { getPlan, planActive } = require('../services/planLimits');
const storageManager = require('../services/storageManager');
const { REWARD_ADS_NEEDED } = require('../config/constants');
const { publicUser } = require('./auth');

const router = express.Router();
router.use(authenticate);

/** GET /api/users/profile */
router.get(
  '/profile',
  asyncHandler(async (req, res) => {
    const [botCount, adsToday, activity, refStats, used] = await Promise.all([
      Bot.countByUser(req.user.id),
      AdWatch.countToday(req.user.id),
      ActivityLog.recent(req.user.id, 15),
      Referral.statsFor(req.user.id),
      storageManager.syncUserUsage(req.user.id),
    ]);
    res.json({
      user: publicUser({ ...req.user, storage_used: used }),
      stats: {
        botCount,
        maxBots: req.user.max_bots,
        storageUsed: used,
        storageLimit: Number(req.user.storage_limit),
        adsWatchedToday: adsToday,
        referrals: refStats,
        activity,
      },
    });
  })
);

/** PUT /api/users/profile */
router.put(
  '/profile',
  validateProfile,
  handleValidation,
  asyncHandler(async (req, res) => {
    const user = await User.update(req.user.id, {
      displayName: sanitizeName(req.body.displayName),
    });
    res.json({ user: publicUser(user) });
  })
);

/** GET /api/users/stats */
router.get(
  '/stats',
  asyncHandler(async (req, res) => {
    const [botCount, adsToday, refStats, used] = await Promise.all([
      Bot.countByUser(req.user.id),
      AdWatch.countToday(req.user.id),
      Referral.statsFor(req.user.id),
      storageManager.syncUserUsage(req.user.id),
    ]);
    res.json({
      storageUsed: used,
      storageLimit: Number(req.user.storage_limit),
      botCount,
      maxBots: req.user.max_bots,
      adsWatchedToday: adsToday,
      referrals: refStats,
    });
  })
);

/** GET /api/users/wallet - balance, watch-to-win progress, transactions */
router.get(
  '/wallet',
  asyncHandler(async (req, res) => {
    const [wallet, transactions] = await Promise.all([
      User.wallet(req.user.id),
      User.walletTransactions(req.user.id, 20),
    ]);
    res.json({
      balance: wallet.balance,
      pendingAdClicks: wallet.pending,
      adsToNextReward: REWARD_ADS_NEEDED - (wallet.pending % REWARD_ADS_NEEDED),
      payoutPerCycle: 0.25,
      transactions,
    });
  })
);

/** GET /api/users/plan */
router.get('/plan', (req, res) => {
  res.json({
    plan: getPlan(req.user.plan_type),
    active: planActive(req.user),
    expiry: req.user.plan_expiry,
  });
});

module.exports = router;
