/** Referral routes (7-day streak edition): stats, earnings, payout requests. */
const express = require('express');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../utils/helpers');
const referralManager = require('../services/referralManager');

const router = express.Router();
router.use(authenticate);

/** GET /api/referrals/stats */
router.get(
  '/stats',
  asyncHandler(async (req, res) => {
    res.json(await referralManager.stats(req.user));
  })
);

/** POST /api/referrals/code */
router.post('/code', (req, res) => {
  res.json({
    code: req.user.referral_code,
    link: referralManager.referralLink(req.user.referral_code),
  });
});

/** GET /api/referrals/earnings - per-referral streak progress */
router.get(
  '/earnings',
  asyncHandler(async (req, res) => {
    const [stats, list] = await Promise.all([
      referralManager.stats(req.user),
      referralManager.earnings(req.user),
    ]);
    res.json({ stats, referrals: list });
  })
);

/** POST /api/referrals/payout - request UPI withdrawal of wallet balance */
router.post(
  '/payout',
  asyncHandler(async (req, res) => {
    const result = await referralManager.payoutRequest(req.user, String(req.body.upiId || '').trim());
    res.json(result);
  })
);

/** Legacy alias: /claim behaves like /payout */
router.post(
  '/claim',
  asyncHandler(async (req, res) => {
    const result = await referralManager.payoutRequest(req.user, String(req.body.upiId || '').trim());
    res.json(result);
  })
);

module.exports = router;
