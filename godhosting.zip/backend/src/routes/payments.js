/** Payment routes: UPI orders, QR, verification, history. */
const express = require('express');
const { authenticate } = require('../middleware/auth');
const { validatePayment, validateVerifyPayment, handleValidation } = require('../utils/validators');
const { asyncHandler } = require('../utils/helpers');
const { authLimiter } = require('../middleware/rateLimit');
const paymentManager = require('../services/paymentManager');
const { allPlans } = require('../services/planLimits');
const { publicUser } = require('./auth');

const router = express.Router();

/** GET /api/plans - public plan list */
router.get('/plans', (req, res) => {
  res.json({ plans: allPlans() });
});

/** POST /api/payments/create */
router.post(
  '/create',
  authenticate,
  authLimiter,
  validatePayment,
  handleValidation,
  asyncHandler(async (req, res) => {
    const result = await paymentManager.createPayment(req.user, req.body.planType);
    result.qrUrl = `/api/payments/qr/${result.payment.paymentId}`;
    res.json(result);
  })
);

/** GET /api/payments/qr/:paymentId - PNG QR code for the UPI link */
router.get(
  '/qr/:paymentId',
  authenticate,
  asyncHandler(async (req, res) => {
    const buffer = await paymentManager.qrBuffer(String(req.params.paymentId));
    if (!buffer) return res.status(404).json({ error: 'Payment not found' });
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-store');
    return res.send(buffer);
  })
);

/** POST /api/payments/verify - submit UTR after paying */
router.post(
  '/verify',
  authenticate,
  authLimiter,
  validateVerifyPayment,
  handleValidation,
  asyncHandler(async (req, res) => {
    const result = await paymentManager.verifyPayment(
      req.user,
      String(req.body.paymentId),
      String(req.body.utr).trim()
    );
    res.json({
      ok: true,
      payment: result.payment,
      user: result.user ? publicUser(result.user) : undefined,
      alreadyConfirmed: result.alreadyConfirmed || false,
    });
  })
);

/** GET /api/payments/history */
router.get(
  '/history',
  authenticate,
  asyncHandler(async (req, res) => {
    res.json({ payments: await paymentManager.history(req.user) });
  })
);

/** GET /api/payments/status/:paymentId */
router.get(
  '/status/:paymentId',
  authenticate,
  asyncHandler(async (req, res) => {
    const payment = await paymentManager.statusOf(String(req.params.paymentId));
    if (!payment || payment.user_id !== req.user.id) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    return res.json({ payment });
  })
);

module.exports = router;
