const { query } = require('../config/database');

const FIELDS = `id, user_id, plan_type, amount, payment_id, payment_status,
  upi_transaction_id, payment_method, created_at, expiry_date, confirmed_at`;

const Payment = {
  async create({ userId, planType, amount, paymentId }) {
    const res = await query(
      `INSERT INTO payments (user_id, plan_type, amount, payment_id, payment_status, payment_method)
       VALUES ($1, $2, $3, $4, 'pending', 'upi') RETURNING ${FIELDS}`,
      [userId, planType, amount, paymentId]
    );
    return res.rows[0];
  },

  async findByPaymentId(paymentId) {
    const res = await query(`SELECT ${FIELDS} FROM payments WHERE payment_id = $1`, [paymentId]);
    return res.rows[0] || null;
  },

  async findByIdAndUser(id, userId) {
    const res = await query(`SELECT ${FIELDS} FROM payments WHERE id = $1 AND user_id = $2`, [id, userId]);
    return res.rows[0] || null;
  },

  async confirm(id, utr, expiryDate) {
    const res = await query(
      `UPDATE payments SET payment_status = 'confirmed', upi_transaction_id = $2,
         expiry_date = $3, confirmed_at = CURRENT_TIMESTAMP
        WHERE id = $1 RETURNING ${FIELDS}`,
      [id, utr, expiryDate]
    );
    return res.rows[0] || null;
  },

  async reject(id) {
    const res = await query(
      `UPDATE payments SET payment_status = 'rejected' WHERE id = $1 RETURNING ${FIELDS}`,
      [id]
    );
    return res.rows[0] || null;
  },

  async findByUser(userId) {
    const res = await query(`SELECT ${FIELDS} FROM payments WHERE user_id = $1 ORDER BY created_at DESC`, [userId]);
    return res.rows;
  },

  async allWithUsers(limit = 100) {
    const res = await query(
      `SELECT p.*, u.email AS user_email, u.display_name AS user_name
         FROM payments p JOIN users u ON u.id = p.user_id
         ORDER BY p.created_at DESC LIMIT $1`,
      [limit]
    );
    return res.rows;
  },

  async rejectById(id) {
    const res = await query(
      `UPDATE payments SET payment_status = 'rejected' WHERE id = $1 RETURNING ${FIELDS}`,
      [id]
    );
    return res.rows[0] || null;
  },

  async totalRevenue() {
    const res = await query(
      "SELECT COALESCE(SUM(amount), 0)::int AS total FROM payments WHERE payment_status = 'confirmed'"
    );
    return res.rows[0].total;
  },
};

module.exports = Payment;
