const { query } = require('../config/database');

const FIELDS = `id, user_id, name, bot_token, status, pid, env_vars, code, storage_path,
  last_started, last_restart, restart_count, uptime_seconds, created_at, expiry_time,
  total_requests, error_count`;

const Bot = {
  async create({ userId, name, botToken, code, storagePath }) {
    const res = await query(
      `INSERT INTO bots (user_id, name, bot_token, code, storage_path)
       VALUES ($1, $2, $3, $4, $5) RETURNING ${FIELDS}`,
      [userId, name, botToken, code || '', storagePath]
    );
    return res.rows[0];
  },

  async findById(id) {
    const res = await query(`SELECT ${FIELDS} FROM bots WHERE id = $1`, [id]);
    return res.rows[0] || null;
  },

  async findByIdAndUser(id, userId) {
    const res = await query(`SELECT ${FIELDS} FROM bots WHERE id = $1 AND user_id = $2`, [id, userId]);
    return res.rows[0] || null;
  },

  async findByUser(userId) {
    const res = await query(`SELECT ${FIELDS} FROM bots WHERE user_id = $1 ORDER BY created_at DESC`, [userId]);
    return res.rows;
  },

  async countByUser(userId) {
    const res = await query('SELECT COUNT(*)::int AS n FROM bots WHERE user_id = $1', [userId]);
    return res.rows[0].n;
  },

  async update(id, fields) {
    const res = await query(
      `UPDATE bots SET name = COALESCE($2, name), bot_token = COALESCE($3, bot_token),
         env_vars = COALESCE($4, env_vars)
       WHERE id = $1 RETURNING ${FIELDS}`,
      [id, fields.name, fields.botToken, fields.envVars ? JSON.stringify(fields.envVars) : null]
    );
    return res.rows[0] || null;
  },

  async updateCode(id, code) {
    const res = await query('UPDATE bots SET code = $2 WHERE id = $1 RETURNING ' + FIELDS, [id, code]);
    return res.rows[0] || null;
  },

  async setStatus(id, status, pid = null) {
    const startedClause = status === 'running' ? ', last_started = CURRENT_TIMESTAMP' : '';
    const res = await query(
      `UPDATE bots SET status = $2, pid = $3 ${startedClause} WHERE id = $1 RETURNING ${FIELDS}`,
      [id, status, pid]
    );
    return res.rows[0] || null;
  },

  async incrementRestart(id) {
    await query(
      'UPDATE bots SET restart_count = restart_count + 1, last_restart = CURRENT_TIMESTAMP WHERE id = $1',
      [id]
    );
  },

  async incrementErrors(id) {
    await query('UPDATE bots SET error_count = error_count + 1 WHERE id = $1', [id]);
  },

  async runningFreeExpired() {
    const res = await query(
      `SELECT b.* FROM bots b JOIN users u ON u.id = b.user_id
        WHERE b.status = 'running' AND u.plan_type = 'free'
          AND b.last_started < CURRENT_TIMESTAMP - INTERVAL '24 hours'`
    );
    return res.rows;
  },

  async running() {
    const res = await query(`SELECT ${FIELDS} FROM bots WHERE status = 'running'`);
    return res.rows;
  },

  async remove(id) {
    await query('DELETE FROM bots WHERE id = $1', [id]);
  },

  async totalCount() {
    const res = await query('SELECT COUNT(*)::int AS n FROM bots');
    return res.rows[0].n;
  },

  async runningCount() {
    const res = await query("SELECT COUNT(*)::int AS n FROM bots WHERE status = 'running'");
    return res.rows[0].n;
  },
};

module.exports = Bot;
