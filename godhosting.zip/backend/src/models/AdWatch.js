const { query } = require('../config/database');

const AdWatch = {
  async create({ userId, botId, action, duration, ip, userAgent }) {
    const res = await query(
      `INSERT INTO ad_watches (user_id, bot_id, ad_type, ad_duration, ip_address, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, user_id, bot_id, ad_type, ad_duration, watch_start, completed, verified`,
      [userId, botId || null, action, duration, ip, userAgent]
    );
    return res.rows[0];
  },

  async complete(id, userId, verified) {
    const res = await query(
      `UPDATE ad_watches SET watch_end = CURRENT_TIMESTAMP, completed = TRUE, verified = $3
        WHERE id = $1 AND user_id = $2
        RETURNING id, user_id, ad_type, ad_duration, watch_start, watch_end, completed, verified`,
      [id, userId, verified]
    );
    return res.rows[0] || null;
  },

  async findById(id) {
    const res = await query('SELECT * FROM ad_watches WHERE id = $1', [id]);
    return res.rows[0] || null;
  },

  /** Verified completed watches for an action within the last N minutes. */
  async recentVerified(userId, action, minutes = 10) {
    const res = await query(
      `SELECT * FROM ad_watches
        WHERE user_id = $1 AND ad_type = $2 AND completed = TRUE AND verified = TRUE
          AND watch_end > CURRENT_TIMESTAMP - ($3 || ' minutes')::INTERVAL
        ORDER BY watch_end DESC`,
      [userId, action, String(minutes)]
    );
    return res.rows;
  },

  async countToday(userId) {
    const res = await query(
      `SELECT COUNT(*)::int AS n FROM ad_watches
        WHERE user_id = $1 AND completed = TRUE AND watch_start > CURRENT_DATE`,
      [userId]
    );
    return res.rows[0].n;
  },

  async totalCompleted() {
    const res = await query('SELECT COUNT(*)::int AS n FROM ad_watches WHERE completed = TRUE');
    return res.rows[0].n;
  },
};

module.exports = AdWatch;
