const { query } = require('../config/database');

const Referral = {
  async statsFor(referrerId) {
    const res = await query(
      `SELECT COUNT(*)::int AS total,
              COUNT(*) FILTER (WHERE status = 'pending')::int AS pending,
              COUNT(*) FILTER (WHERE status = 'completed')::int AS completed,
              COUNT(*) FILTER (WHERE status = 'failed')::int AS failed,
              COALESCE(SUM(earnings), 0)::float AS claimable
         FROM referrals WHERE referrer_id = $1`,
      [referrerId]
    );
    return res.rows[0];
  },

  async list(referrerId) {
    const res = await query(
      `SELECT r.id, r.status, r.earnings, r.created_at,
              COALESCE(r.continuous_days_logged, 0)::int AS streak_days,
              u.display_name AS referred_name, u.last_active AS referred_last_active,
              (u.last_active > CURRENT_TIMESTAMP - INTERVAL '48 hours') AS is_active_user
         FROM referrals r JOIN users u ON u.id = r.referred_id
        WHERE r.referrer_id = $1 ORDER BY r.created_at DESC`,
      [referrerId]
    );
    return res.rows;
  },

  /** Referrals due for their monthly ₹ credit whose referred user was active recently. */
  async dueCredits() {
    const res = await query(
      `SELECT r.* FROM referrals r JOIN users u ON u.id = r.referred_id
        WHERE r.status = 'active'
          AND (r.next_credit_at IS NULL OR r.next_credit_at <= CURRENT_TIMESTAMP)
          AND u.last_active > CURRENT_TIMESTAMP - INTERVAL '30 days'`
    );
    return res.rows;
  },

  async inactiveDue() {
    const res = await query(
      `SELECT r.id FROM referrals r JOIN users u ON u.id = r.referred_id
        WHERE r.status = 'active'
          AND (r.next_credit_at IS NULL OR r.next_credit_at <= CURRENT_TIMESTAMP)
          AND (u.last_active IS NULL OR u.last_active <= CURRENT_TIMESTAMP - INTERVAL '30 days')`
    );
    return res.rows;
  },

  async credit(id, amount) {
    await query(
      `UPDATE referrals SET earnings = earnings + $2,
         next_credit_at = CURRENT_TIMESTAMP + INTERVAL '30 days'
        WHERE id = $1`,
      [id, amount]
    );
  },

  async postpone(id, days) {
    await query(
      `UPDATE referrals SET next_credit_at = CURRENT_TIMESTAMP + ($2 || ' days')::INTERVAL WHERE id = $1`,
      [id, String(days)]
    );
  },

  /** Zero out claimable earnings (marks payout) and return the claimed amount. */
  async claimAll(referrerId) {
    const stats = await this.statsFor(referrerId);
    const amount = parseFloat(stats.claimable) || 0;
    if (amount > 0) {
      await query(
        `UPDATE referrals SET earnings = 0, last_payout = CURRENT_TIMESTAMP WHERE referrer_id = $1`,
        [referrerId]
      );
    }
    return amount;
  },
};

module.exports = Referral;
