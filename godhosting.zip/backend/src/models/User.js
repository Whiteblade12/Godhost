const { query, withTransaction } = require('../config/database');
const { randomCode } = require('../utils/helpers');
const { PLANS } = require('../config/constants');

const SELECT_FIELDS = `id, firebase_uid, email, display_name, plan_type, plan_expiry,
  storage_used, storage_limit, max_bots, referral_code, referred_by, ads_enabled,
  adblocker_detected, adblocker_detected_at, adblocker_warnings, created_at, last_active`;

async function ensureUniqueCode() {
  for (let i = 0; i < 5; i += 1) {
    const code = randomCode('GH', 6);
    const exists = await query('SELECT 1 FROM users WHERE referral_code = $1', [code]);
    if (exists.rowCount === 0) return code;
  }
  return randomCode('GH', 10);
}

const User = {
  async findByUid(firebaseUid) {
    const res = await query(`SELECT ${SELECT_FIELDS} FROM users WHERE firebase_uid = $1`, [firebaseUid]);
    return res.rows[0] || null;
  },

  async findById(id) {
    const res = await query(`SELECT ${SELECT_FIELDS} FROM users WHERE id = $1`, [id]);
    return res.rows[0] || null;
  },

  async findByEmail(email) {
    const res = await query(`SELECT ${SELECT_FIELDS} FROM users WHERE LOWER(email) = LOWER($1)`, [email]);
    return res.rows[0] || null;
  },

  async findByReferralCode(code) {
    const res = await query(`SELECT ${SELECT_FIELDS} FROM users WHERE referral_code = $1`, [code]);
    return res.rows[0] || null;
  },

  async createFromGoogle({ firebaseUid, email, displayName, referralCode }) {
    return withTransaction(async (client) => {
      const existing = await client.query('SELECT id FROM users WHERE firebase_uid = $1', [firebaseUid]);
      if (existing.rowCount > 0) {
        const full = await client.query(`SELECT ${SELECT_FIELDS} FROM users WHERE id = $1`, [
          existing.rows[0].id,
        ]);
        return { user: full.rows[0], created: false };
      }

      let referredBy = null;
      if (referralCode) {
        const ref = await client.query('SELECT id FROM users WHERE referral_code = $1', [referralCode]);
        if (ref.rowCount > 0) referredBy = ref.rows[0].id;
      }

      const free = PLANS.free;
      const code = await (async () => {
        for (let i = 0; i < 5; i += 1) {
          const c = randomCode('GH', 6);
          const dup = await client.query('SELECT 1 FROM users WHERE referral_code = $1', [c]);
          if (dup.rowCount === 0) return c;
        }
        return randomCode('GH', 10);
      })();

      const insert = await client.query(
        `INSERT INTO users (firebase_uid, email, display_name, plan_type, storage_limit, max_bots, referral_code, referred_by, last_active)
         VALUES ($1, $2, $3, 'free', $4, $5, $6, $7, CURRENT_TIMESTAMP)
         RETURNING ${SELECT_FIELDS}`,
        [firebaseUid, email, displayName || email.split('@')[0], free.storageLimit, free.maxBots, code, referredBy]
      );
      const user = insert.rows[0];

      if (referredBy) {
        // 7-Day Referral Validator: starts 'pending', completes after the
        // referred user logs in 7 consecutive days (₹3 bonus to referrer).
        await client.query(
          `INSERT INTO referrals (referrer_id, referred_id, status, continuous_days_logged, next_credit_at)
           VALUES ($1, $2, 'pending', 0, CURRENT_TIMESTAMP + INTERVAL '30 days')`,
          [referredBy, user.id]
        );
      }
      return { user, created: true };
    });
  },

  async update(id, { displayName }) {
    const res = await query(
      `UPDATE users SET display_name = COALESCE($2, display_name) WHERE id = $1 RETURNING ${SELECT_FIELDS}`,
      [id, displayName]
    );
    return res.rows[0] || null;
  },

  async applyPlan(id, planType, expiryDate) {
    const plan = PLANS[planType];
    const res = await query(
      `UPDATE users SET plan_type = $2, plan_expiry = $3, storage_limit = $4, max_bots = $5
       WHERE id = $1 RETURNING ${SELECT_FIELDS}`,
      [id, planType, expiryDate, plan.storageLimit, planType === 'diamond' ? 999 : plan.maxBots]
    );
    return res.rows[0] || null;
  },

  async setAdblocker(id, detected, methods = []) {
    const res = await query(
      `UPDATE users
         SET adblocker_detected = $2,
             adblocker_detected_at = CURRENT_TIMESTAMP,
             adblocker_warnings = CASE WHEN $2 = TRUE THEN adblocker_warnings + 1 ELSE adblocker_warnings END
       WHERE id = $1 RETURNING ${SELECT_FIELDS}`,
      [id, detected]
    );
    if (detected) {
      await query(
        `INSERT INTO activity_logs (user_id, action_type, details) VALUES ($1, 'adblocker_detected', $2)`,
        [id, JSON.stringify({ methods })]
      );
    }
    return res.rows[0] || null;
  },

  async touch(id) {
    await query('UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE id = $1', [id]);
  },

  async updateStorageUsed(id, bytes) {
    await query('UPDATE users SET storage_used = $2 WHERE id = $1', [id, Math.max(0, bytes)]);
  },

  async list(limit = 50, offset = 0) {
    const res = await query(
      `SELECT id, email, display_name, plan_type, plan_expiry, storage_used, max_bots,
              referral_code, adblocker_detected, adblocker_warnings, created_at, last_active
         FROM users ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    return res.rows;
  },

  async wallet(userId) {
    const res = await query(
      'SELECT COALESCE(wallet_balance, 0)::float AS balance, COALESCE(pending_ad_clicks, 0)::int AS pending FROM users WHERE id = $1',
      [userId]
    );
    return res.rows[0] || { balance: 0, pending: 0 };
  },

  async walletTransactions(userId, limit = 20) {
    const res = await query(
      `SELECT amount, transaction_type, created_at FROM wallet_transactions
        WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
      [userId, limit]
    );
    return res.rows;
  },

  async count() {
    const res = await query('SELECT COUNT(*)::int AS n FROM users');
    return res.rows[0].n;
  },
};

module.exports = User;
