const { query } = require('../config/database');

const ActivityLog = {
  async log(userId, actionType, { botId = null, ip = null, userAgent = null, details = {} } = {}) {
    await query(
      `INSERT INTO activity_logs (user_id, action_type, bot_id, ip_address, user_agent, details)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, actionType, botId, ip, userAgent, JSON.stringify(details || {})]
    );
  },

  async recent(userId, limit = 25) {
    const res = await query(
      `SELECT action_type, bot_id, details, created_at
         FROM activity_logs WHERE user_id = $1
         ORDER BY created_at DESC LIMIT $2`,
      [userId, limit]
    );
    return res.rows;
  },
};

module.exports = ActivityLog;
