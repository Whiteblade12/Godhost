/**
 * GodHosting API server.
 * Express + Socket.IO + PostgreSQL + Firebase Auth + Python bot runner.
 */
require('dotenv').config();
const http = require('http');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const cookieParser = require('cookie-parser');

const logger = require('./utils/logger');
const requestLogger = require('./middleware/logger');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const { apiLimiter } = require('./middleware/rateLimit');
const { ddosGuard } = require('./middleware/ddosGuard');
const shield = require('./middleware/shield');
const adminAuthRoutes = require('./routes/adminAuth');
const adRewardsRoutes = require('./routes/adRewards');
const { auditReferralMilestones } = require('./services/referralTally');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const botRoutes = require('./routes/bots');
const adRoutes = require('./routes/ads');
const paymentRoutes = require('./routes/payments');
const referralRoutes = require('./routes/referrals');
const adminRoutes = require('./routes/admin');

const socketService = require('./services/socket');
const botManager = require('./services/botManager');
const planLimits = require('./services/planLimits');
const referralManager = require('./services/referralManager'); // payout requests
const { getFirebaseAdmin } = require('./config/firebase');
const { CONTACT } = require('./config/constants');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

/* ---- DDoS guard: >200 req / 10 min from one IP → 3h ban (FIRST middleware) ---- */
app.use(ddosGuard);

/* ---- Global middleware ---- */
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: false, // API serves JSON + QR images; CSP handled by frontend
  })
);

const corsOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000')
  .split(',')
  .map((s) => s.trim());
app.use(
  cors({
    origin(origin, cb) {
      if (!origin || corsOrigins.includes('*') || corsOrigins.includes(origin)) return cb(null, true);
      return cb(null, false);
    },
    credentials: true,
  })
);
app.use(compression());
app.use(shield); // anti-hack signature + probe blocking + HSTS
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(requestLogger);

/* ---- Health & info ---- */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    name: 'GodHosting API',
    domain: CONTACT.domain,
    contact: CONTACT.email,
    telegram: CONTACT.telegram,
    time: new Date().toISOString(),
  });
});

/* ---- API routes ---- */
app.use('/api', apiLimiter);
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/bots', botRoutes);
app.use('/api/ads', adRoutes);
app.use('/api/ads', adRewardsRoutes); // watch-to-win rewards + S2S webhook
app.use('/api', paymentRoutes); // exposes /api/plans + /api/payments/*
app.use('/api/referrals', referralRoutes);
app.use('/api/admin/auth', adminAuthRoutes); // admin login (godhosting.online/admin/auth/)
app.use('/api/admin', adminRoutes);

/* ---- 404 + errors ---- */
app.use(notFound);
app.use(errorHandler);

/* ---- Boot ---- */
const PORT = parseInt(process.env.PORT || '5000', 10);
const server = http.createServer(app);
socketService.init(server);

/* ---- Slow-request / slowloris hardening ---- */
server.requestTimeout = 30 * 1000;
server.headersTimeout = 31 * 1000;
server.keepAliveTimeout = 65 * 1000;

async function start() {
  try {
    getFirebaseAdmin(); // initialise (or log warning) early
    await planLimits.initialize();

    server.listen(PORT, () => {
      logger.info(`GodHosting API listening on :${PORT} (${process.env.NODE_ENV || 'development'})`);
      logger.info(`Contact: ${CONTACT.email} | ${CONTACT.telegram}`);
    });

    // Free-plan 24h auto-stop + orphan recovery (every 60s)
    botManager.startScheduler();

    // Downgrade expired paid plans (every hour)
    setInterval(() => planLimits.downgradeExpired().catch(() => {}), 60 * 60 * 1000).unref();

    // 7-Day Referral Validator (hourly audit: streak +1 / ₹3 bonus / 48h fail)
    setInterval(() => auditReferralMilestones(), 60 * 60 * 1000).unref();
    auditReferralMilestones(); // run once at boot
  } catch (err) {
    logger.error('Failed to start server: ' + err.message);
    process.exit(1);
  }
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
function shutdown() {
  logger.info('Shutting down...');
  botManager.stopAll();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}

start();

module.exports = app;
