# ⚡ GodHosting — The Ultimate Telegram Bot Hosting Platform

> **Deploy Telegram Bots Instantly. For Free.**

**Domain:** [godhosting.online](https://godhosting.online) • **Email:** godhostings@gmail.com • **Telegram:** [t.me/TheGoat_father](https://t.me/TheGoat_father) • **UPI:** godhostings@upi

GodHosting is a complete, production-ready Telegram bot hosting platform. Users sign in with Google, create bots, write Python (`main.py` + `requirements.txt`) in a built-in code editor, deploy with one click, watch live logs over WebSockets, earn money through referrals, and upgrade via UPI.

---

## ✨ Features

- 🔐 **Google sign-in** (Firebase Auth) + JWT sessions
- 🤖 **Bot management** — create / edit / start / stop / restart / delete
- 🖥️ **Monaco code editor** for `main.py` and `requirements.txt` (auto `pip install` on start)
- 📜 **Live logs** streamed in real time with Socket.IO
- 📁 **File manager** — upload / download / delete (`main.py` + `requirements.txt` only)
- 📊 **4 subscription plans** — Free / Silver / Gold / Diamond (₹0 → ₹100)
- 📺 **5-second ad gating** on every action (server-verified watch sessions)
- 🚫 **Ad-blocker protection** — 6 independent detection methods; blocks all actions on Free/Silver/Gold. Diamond is ad-free and allows ad blockers
- ⏰ **24h auto-stop** for Free plan (3 ads / 15s to restart)
- 💳 **UPI payments** — QR code + deep link + UTR verification (GPay / PhonePe / Paytm)
- 🤝 **Referral program** — earn ₹1 / month per active referral, claimable via UPI
- 📱 **Mobile-first responsive** dark UI with gold gradients (Inter + JetBrains Mono)
- 🛡️ **Security** — Helmet, CORS, rate limiting, parameterized SQL, input validation, file type/size checks, per-bot process isolation

## 📊 Plans

| Feature | Free | Silver | Gold | Diamond |
|---|---|---|---|---|
| Price | ₹0 | ₹30/mo | ₹50/mo | ₹100/mo |
| Storage | 300 MB | 500 MB | 750 MB | 1 GB |
| Max bots | 1 | 5 | 10 | Unlimited |
| 24h auto-stop | ✅ | ❌ | ❌ | ❌ |
| 5-second ads | ✅ | ✅ | ✅ | ❌ None |
| Ad blocker | 🚫 Blocked | 🚫 Blocked | 🚫 Blocked | ✅ Allowed |
| Ads to restart | 3 (15s) | 1 (5s) | 1 (5s) | 0 |
| 24/7 support | ❌ | ❌ | ✅ | ✅ |

### 📺 Ad rules

| Action | Free | Silver | Gold | Diamond |
|---|---|---|---|---|
| Website opens | 1 × 5s | — | — | — |
| Deploy / Start / Logs scroll / File manager | 1 × 5s | 1 × 5s | 1 × 5s | None |
| Restart | 3 × 5s (15s) | 1 × 5s | 1 × 5s | None |

## 💰 Earning model

- **Watch-to-Win rewarded ads:** users watch **5 × 15-second** video ads → **₹0.25** wallet credit.
  The secure counter increments ONLY on server-verified playback or the ad network's
  **server-to-server webhook** (`POST /api/ads/webhook`, `{userId, adNetworkTxId, rewardVerified}`) —
  never on unverified client clicks. Duplicate transactions are ignored (idempotent).
- **7-Day Referral Validator:** referred user logs in **7 consecutive days** → referrer wallet **+₹3.00**
  (hourly audit, `referralTally.js`). A 48h absence fails the streak.
- Wallet payouts via UPI on request — each request pings the owner on Telegram.

## 📱 Telegram Admin Command Center

Set `TELEGRAM_ADMIN_BOT_TOKEN` + `TELEGRAM_ADMIN_CHAT_ID` (create a bot via @BotFather,
get your chat ID from @userinfobot) and receive instant Markdown alerts for:

- **Trigger A — Admin brute-force:** failed admin login → email, IP, attempts left before lockout
- **Trigger B — DDoS mitigation:** IP banned 3h (>200 req/10min) → full ISP + geolocation
- **Trigger C — Privilege probing:** a normal user hits an admin endpoint → user ID, email, IP
- **Payout requests:** wallet withdrawal requests with amount + user's UPI ID

**Ad-blocker protection (6 methods):** ad-element bait, ad image load test, fetch test (`/api/ads/test`), ad script load test, global variable fingerprint, CSS rule bait. Detections are reported to the backend, logged in the database, and **block every action** on ad-supported plans.

---

## 🗂️ Project structure

```
godhosting/
├── frontend/                    # React 18 + Tailwind CSS (CRA)
│   ├── public/                  # index.html (SEO), manifest, robots, logos, favicon
│   └── src/
│       ├── components/          # Landing, Login, Dashboard, BotEditor, FileManager,
│       │                        # AdModal, AdBlockerWarning, Plans, Payment, Navbar,
│       │                        # Footer, Referrals, Profile, LoadingSpinner
│       ├── pages/               # Home, DashboardPage, BotPage, PlansPage
│       ├── hooks/               # useAuth, useBots, useAdBlocker, usePlan
│       ├── context/             # AuthContext, PlanContext
│       ├── utils/               # api, auth (Firebase), adBlocker, validators, formatters
│       ├── styles/              # index.css (Tailwind), animations.css, themes.css
│       └── constants/           # plans, config
├── backend/                     # Node.js + Express + PostgreSQL + Socket.IO
│   ├── src/
│   │   ├── routes/              # auth, users, bots, ads, payments, referrals, admin
│   │   ├── models/              # User, Bot, AdWatch, Payment, Referral, ActivityLog
│   │   ├── services/            # botManager, planLimits, adManager, paymentManager,
│   │   │                        # referralManager, storageManager, socket
│   │   ├── middleware/          # auth, adBlocker, rateLimit, logger, errorHandler
│   │   ├── config/              # firebase, database, redis, constants
│   │   ├── utils/               # logger (Winston), helpers, validators
│   │   ├── scripts/             # init-db, seed
│   │   └── db/schema.sql        # PostgreSQL schema + indexes
│   ├── bots/                    # user bot files (runtime)
│   └── logs/                    # log files (runtime)
├── docker/                      # Dockerfile.frontend, Dockerfile.backend,
│                                # nginx-spa.conf, docker-compose.yml
├── .github/workflows/deploy.yml # CI/CD (build + Render deploy hooks)
├── .gitignore
└── README.md
```

---

## 🚀 Local development

### Prerequisites
- Node.js ≥ 18, PostgreSQL ≥ 13, Python 3 + pip3 (to run bots)

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env           # set DATABASE_URL, JWT_SECRET, (optional) FIREBASE_*
createdb godhosting            # or create via psql/pgAdmin
npm run init-db                # create schema + indexes
npm run seed                   # optional demo data
DEMO_MODE=true npm run dev     # http://localhost:5000
```

### 2. Frontend
```bash
cd frontend
npm install
cp .env.example .env           # set REACT_APP_API_URL=http://localhost:5000, REACT_APP_DEMO_MODE=true
npm start                      # http://localhost:3000
```

> **Without Firebase:** set `DEMO_MODE=true` (backend) and `REACT_APP_DEMO_MODE=true` (frontend) to log in with any email for local testing. Add Firebase keys + Google OAuth config for real Google sign-in.

### 3. Docker (one command)
```bash
cd docker
docker compose up --build
# Frontend: http://localhost:8080   API: http://localhost:5000
```

---

## 🔑 Environment variables

### Frontend (`frontend/.env`)
| Variable | Purpose |
|---|---|
| `REACT_APP_FIREBASE_API_KEY` / `AUTH_DOMAIN` / `PROJECT_ID` / `STORAGE_BUCKET` / `MESSAGING_SENDER_ID` / `APP_ID` | Firebase Google login |
| `REACT_APP_API_URL` | Backend URL (empty = same origin) |
| `REACT_APP_GOOGLE_CLIENT_ID` | Google OAuth client |
| `REACT_APP_ADSENSE_PUBLISHER_ID` / `SLOT_ID` | AdSense units |
| `REACT_APP_DEMO_MODE` | Enable demo login locally |

### Backend (`backend/.env`)
Full annotated template in [`backend/.env.example`](backend/.env.example): server, `DATABASE_URL`, Firebase Admin keys, `JWT_SECRET`, `REDIS_URL` (optional), storage paths, plan limits, ad settings (`AD_DURATION=5`), UPI (`UPI_ID=godhostings@upi`), **earning economy** (`REFERRAL_BONUS=3.00`, `REFERRAL_STREAK_DAYS=7`, `REWARD_ADS_NEEDED=5`, `REWARD_AD_DURATION=15`, `REWARD_AD_PAYOUT=0.25`, `AD_WEBHOOK_SECRET`), **admin command center** (`TELEGRAM_ADMIN_BOT_TOKEN`, `TELEGRAM_ADMIN_CHAT_ID`, `ADMIN_PASSWORD_HASH`, `ADMIN_JWT_SECRET`), rate limits, `CORS_ORIGIN`, `ADMIN_EMAILS`.

---

## 📡 API documentation

Base URL: `https://api.godhosting.online/api` — all authenticated routes use `Authorization: Bearer <JWT>`.

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/google` | Google login `{idToken, referralCode?}` → `{token, user}` |
| GET | `/api/auth/me` | Current user + plan |
| POST | `/api/auth/logout` | Logout |
| POST | `/api/auth/refresh` | Refresh JWT |

### Users
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/users/profile` | Profile + stats + activity |
| PUT | `/api/users/profile` | Update display name |
| GET | `/api/users/stats` | Usage stats |
| GET | `/api/users/plan` | Current plan details |

### Bots
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/bots` | List bots + plan limits |
| POST | `/api/bots` | Create `{name, botToken}` |
| GET | `/api/bots/:id` | Bot detail + files |
| PUT | `/api/bots/:id` | Update name/token/env |
| PUT | `/api/bots/:id/config` | Config alias |
| POST | `/api/bots/:id/code` | Save `main.py` / `requirements.txt` `{code, filename}` |
| POST | `/api/bots/:id/start` | Start (402 `ads_required` + `adWatchIds` flow) |
| POST | `/api/bots/:id/stop` | Stop |
| POST | `/api/bots/:id/restart` | Restart (free: 3 verified ads) |
| DELETE | `/api/bots/:id` | Delete bot + files |
| GET | `/api/bots/:id/logs?tail=200` | Recent logs |
| POST | `/api/bots/:id/upload` | Multipart upload (whitelisted files) |
| GET | `/api/bots/:id/files` | List files |
| GET | `/api/bots/:id/files/:name` | Download file |
| DELETE | `/api/bots/:id/files` | Delete `{filename}` |

### Ads
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/ads/check` | Are ads required for this user? |
| GET | `/api/ads/status?action=start` | Ads needed for an action |
| POST | `/api/ads/watch` | Begin watch session `{action, botId?}` → `{adWatchId, duration}` |
| POST | `/api/ads/complete` | Complete (server verifies elapsed ≥ duration) |
| POST | `/api/ads/adblocker` | Report detection `{detected, methods}` |
| ALL | `/api/ads/test` | Fetch-based ad-blocker probe (204) |

**Ad flow:** `GET /ads/status` → for each required ad: `POST /ads/watch` → wait 5s → `POST /ads/complete` → send collected `adWatchIds` with the action request. Server re-verifies watches are completed, verified, recent, and owned by the user.

### Payments (UPI)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/plans` | Public plan list |
| POST | `/api/payments/create` | Create order `{planType}` → `{payment, upiId, upiLink, qrUrl}` |
| GET | `/api/payments/qr/:paymentId` | PNG QR code |
| POST | `/api/payments/verify` | Submit UTR `{paymentId, utr}` → plan +30 days |
| GET | `/api/payments/history` | Payment history |
| GET | `/api/payments/status/:paymentId` | Status check |

### Referrals
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/referrals/stats` | Code, link, counts, claimable ₹ |
| POST | `/api/referrals/code` | Get code + link |
| GET | `/api/referrals/earnings` | Per-referral breakdown |
| POST | `/api/referrals/claim` | Claim balance (UPI payout) |

### Admin (`ADMIN_EMAILS`) — full visual Admin Panel at `/admin`
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/admin/users` | User list (search, plan, storage, ad-blocker flags) |
| GET | `/api/admin/stats` | Platform stats (users, bots, running, revenue) |
| POST | `/api/admin/plans` | Update plan price `{planType, price}` (live + persisted) |
| GET | `/api/admin/ad-revenue` | Ad revenue analytics |
| GET | `/api/admin/payments` | Review all UPI payments with UTRs |
| POST | `/api/admin/payments/:id/reject` | Reject/refund a payment |
| POST | `/api/admin/users/:id/plan` | Manually set a user's plan `{planType, days}` |

### Real-time (Socket.IO)
Connect with `{ auth: { token } }`, then `emit('join', botId)`. Events: `log {botId, t, stream, line}`, `status {botId, status}`, `joined`.

---

## ☁️ Deployment

### Option 1 — Render (recommended)
1. Push this repo to GitHub.
2. **PostgreSQL:** Render → New → PostgreSQL → name `godhosting-db` → copy the *Internal Database URL*.
3. **Backend:** New → Web Service → connect repo → Root Dir `backend` → Build `npm install` → Start `npm run init-db && npm start` → add env vars (`DATABASE_URL`, `JWT_SECRET`, `FIREBASE_*`, `CORS_ORIGIN=https://godhosting.online`).
4. **Frontend:** New → Static Site → Root Dir `frontend` → Build `npm install && npm run build` → Publish `frontend/build` → add `REACT_APP_*` vars.
5. **Domain:** at your registrar add a CNAME `godhosting.online` → your Render domain; add the domain in Render settings. Wait 5–30 min for DNS + SSL.
6. Optionally add the Render **deploy hooks** as GitHub secrets (`RENDER_BACKEND_DEPLOY_HOOK`, `RENDER_FRONTEND_DEPLOY_HOOK`) — the included workflow triggers them on push to `main`.

### Option 2 — Vercel + Railway
```bash
# Frontend → Vercel (framework: CRA, root: frontend)
vercel --prod
# Backend + PostgreSQL → Railway
railway up          # from backend/ ; add DATABASE_URL etc. in dashboard
# DNS: CNAME godhosting.online → cname.vercel-dns.com
```
Set `REACT_APP_API_URL` to the Railway backend URL and `CORS_ORIGIN` to `https://godhosting.online`.

### Option 3 — AWS EC2 single-machine monolith (recommended production setup)

Optimized to run the whole platform on one box (~$15.18/month):

1. **Compute:** AWS EC2 On-Demand **t3.small** (2 vCPU / 2 GB RAM), Ubuntu 22.04, 30 GB disk.
   On-Demand (never Spot) avoids random shutdowns.
2. **Monolith:** no managed services. Nginx reverse proxy on the box, PostgreSQL locally on
   `127.0.0.1:5432` — base DB cost $0. The revised storage quotas (300 MB → 1 GB per tier) keep
   user files at ~4-5 GB even with 1,000 users — well inside the 30 GB volume.
3. **Auto-recovery:** run the API under PM2 (`pm2 start ecosystem.config.js`) — unhandled errors
   reboot the process in milliseconds. User bot containers run with `--restart unless-stopped`.
4. **Business email (free):** Cloudflare **Email Routing** — route `admin@godhosting.online`
   to your Gmail. Satisfies AWS business validation at $0.
5. **$1,000 runway:** set your AWS root email to the custom domain address, apply to
   **AWS Activate Founders** with your live site (https://godhosting.online) → $1,000 credit,
   covering years of hosting.

```bash
# On the EC2 box:
sudo apt update && sudo apt install -y nodejs npm nginx python3 python3-pip postgresql
git clone <your-repo> godhosting && cd godhosting/backend
npm ci && npm run init-db && npm run admin:hash   # configure .env first
sudo npm i -g pm2 && pm2 start ecosystem.config.js && pm2 save && pm2 startup
cd ../frontend && npm ci && npm run build          # serve build/ via Nginx
sudo certbot --nginx -d godhosting.online          # SSL
```

### Docker
```bash
cd docker && docker compose up --build -d
# app on :8080, api on :5000, postgres :5432, redis :6379
```

---

## 🛠️ Admin Panel — `godhosting.online/admin/auth/`

The admin panel is on a **hidden URL** (no link anywhere in the site). Access requires **both**:

1. **Email** must be in `ADMIN_EMAILS` (default: `godhostings@gmail.com`)
2. **Password** — stored **only on the API server** as a **scrypt hash** in `backend/.env`
   (never in frontend code, so nobody can extract it). Generate it with:
   ```bash
   cd backend && npm run admin:hash    # paste output into .env as ADMIN_PASSWORD_HASH
   ```

Login issues a 12h admin JWT in an **HttpOnly + SameSite=Strict cookie** (JavaScript can't read it).
**Rate-limiting engine:** max **5 login attempts per IP in a rolling 1-hour window**; the 6th attempt is
hard-blocked at the middleware layer for **60 minutes** — brute-forcing is mathematically impossible.
Panel features: overview stats, plan distribution, user management + plan override + **wallet settlement**,
live plan price editor, UPI payment review/reject, and a **Security tab** with the DDoS guard's
banned-IP list in real time.

## 🔒 Security checklist (implemented)

✅ Firebase token verification → backend JWT sessions
✅ Helmet security headers • ✅ strict CORS (`CORS_ORIGIN`) • ✅ rate limiting (API / auth / actions)
✅ express-validator input validation on all mutations • ✅ parameterized SQL everywhere (pg)
✅ XSS-safe rendering (React escaping) • ✅ HTTPS enforced in production configs
✅ File uploads: whitelist (`main.py`, `requirements.txt`) + size limit (10 MB)
✅ Per-bot process isolation (own directory, env, `PYTHONPATH`) • ✅ multi-method ad-blocker detection with server-side action blocking
✅ No hardcoded secrets (`.env` + `.env.example` only)
✅ **Admin login: email match + scrypt-hashed password (API-side only) + HttpOnly cookie**
✅ **DDoS guard: >200 requests / 10 min → 3-hour IP ban** (server-side `ddosGuard.js` + Cloudflare WAF rule — see `cloudflare/README.md`)
✅ Anti-hack shield: SQLi/XSS/path-traversal/Log4Shell signature blocking + scanner-probe blocking (`.env`, `.git`, `wp-admin`…)
✅ HSTS + nosniff + Referrer-Policy headers • ✅ slowloris request timeouts • ✅ `x-powered-by` disabled
✅ Admin brute-force lockout (5 attempts / 15 min) • ✅ identical error responses (no account enumeration)

## 🗄️ Database
Full schema in [`backend/src/db/schema.sql`](backend/src/db/schema.sql): `users`, `bots`, `ad_watches`, `payments`, `referrals`, `activity_logs`, `plan_config` + 13 indexes. Run with `npm run init-db`.

## 🎨 Branding
Gold gradient `#f7971e → #ffd200` on dark navy `#1a1a2e` / `#16213e` / `#0f3460`. Fonts: Inter (UI) + JetBrains Mono (code). Logo: lightning bolt on dark rounded square.

---

## 📞 Contact & support
- **Website:** https://godhosting.online
- **Email:** godhostings@gmail.com
- **Telegram:** https://t.me/TheGoat_father
- **UPI:** godhostings@upi

**GodHosting — Where Bots Come to Life ⚡**
