# GodHosting Frontend

React 18 + Tailwind CSS single-page app for [godhosting.online](https://godhosting.online).

## Features
- Google sign-in (Firebase Auth)
- Bot dashboard with live status & one-click start/stop/restart
- Monaco code editor for `main.py` + `requirements.txt`
- Live logs terminal over Socket.IO
- File manager (upload / download / delete)
- 5-second ad modal with server-verified watch sessions
- Multi-method ad-blocker detection + warning overlay
- Plan comparison & UPI checkout (QR + deep link + UTR verification)
- Referral dashboard (₹1 / month / active referral)
- Fully responsive dark theme with gold gradients

## Quick start
```bash
npm install
cp .env.example .env     # add your Firebase keys + API URL
npm start                # dev server on :3000
npm run build            # production build in ./build
```

## Contact
- Domain: godhosting.online
- Email: godhostings@gmail.com
- Telegram: [t.me/TheGoat_father](https://t.me/TheGoat_father)
