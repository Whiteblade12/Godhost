import React, { useEffect, useState } from 'react';
import Landing from '../components/Landing';
import AdModal from '../components/AdModal';
import { useAuth } from '../hooks/useAuth';
import { usePlan } from '../hooks/usePlan';
import { OPEN_AD_SESSION_KEY } from '../constants/config';

/**
 * Home page. Free-plan users see the one-time 5s "website open" ad
 * (once per browser session), per the ad rules.
 */
export default function Home() {
  const { user, loading } = useAuth();
  const { plan } = usePlan();
  const [showOpenAd, setShowOpenAd] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!user) return;
    if (!plan.websiteOpenAd) return; // only Free plan
    if (sessionStorage.getItem(OPEN_AD_SESSION_KEY)) return;
    const t = setTimeout(() => setShowOpenAd(true), 600);
    return () => clearTimeout(t);
  }, [user, loading, plan]);

  return (
    <>
      <Landing />
      {showOpenAd && (
        <AdModal
          open={showOpenAd}
          action="website_open"
          count={1}
          duration={5}
          onComplete={() => {
            sessionStorage.setItem(OPEN_AD_SESSION_KEY, '1');
            setShowOpenAd(false);
          }}
          onClose={() => {
            sessionStorage.setItem(OPEN_AD_SESSION_KEY, '1');
            setShowOpenAd(false);
          }}
        />
      )}
    </>
  );
}
