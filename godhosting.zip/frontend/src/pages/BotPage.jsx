import React from 'react';
import BotEditor from '../components/BotEditor';

/** Bot editor route wrapper (/bots/:id). */
export default function BotPage() {
  return <BotEditor />;
}
