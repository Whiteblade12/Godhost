import React from 'react';
import Dashboard from '../components/Dashboard';

/** Dashboard route wrapper. */
export default function DashboardPage() {
  return <Dashboard />;
}
