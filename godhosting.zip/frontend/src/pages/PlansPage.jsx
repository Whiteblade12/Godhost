import React from 'react';
import Plans from '../components/Plans';

/** Plans route wrapper. */
export default function PlansPage() {
  return <Plans />;
}
