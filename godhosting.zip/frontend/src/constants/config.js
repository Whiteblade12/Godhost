/** Global app configuration. */

export const API_URL = process.env.REACT_APP_API_URL || '';
export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || API_URL || window.location.origin;

export const DEMO_MODE = process.env.REACT_APP_DEMO_MODE === 'true';

export const CONTACT = {
  domain: 'godhosting.online',
  email: 'godhostings@gmail.com',
  telegram: 'https://t.me/TheGoat_father',
  telegramHandle: '@TheGoat_father',
  upiId: 'godhostings@upi',
};

export const AD_DURATION_SECONDS = 5;

export const TOKEN_KEY = 'gh_token';
export const OPEN_AD_SESSION_KEY = 'gh_open_ad_seen';
