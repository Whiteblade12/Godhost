/** Plan definitions - mirrors backend/src/config/constants.js (revised quota matrix). */

export const PLANS = {
  free: {
    id: 'free',
    name: 'Free',
    price: 0,
    storageLabel: '300 MB',
    storageLimit: 314572800,
    maxBots: 1,
    maxBotsLabel: '1 bot',
    autoStopHours: 24,
    ads: true,
    adblockerAllowed: false,
    support247: false,
    websiteOpenAd: true,
    restartAds: 3,
    actionAds: 1,
    color: '#8892b0',
    tagline: 'Get started free, forever',
  },
  silver: {
    id: 'silver',
    name: 'Silver',
    price: 30,
    storageLabel: '500 MB',
    storageLimit: 524288000,
    maxBots: 5,
    maxBotsLabel: '5 bots',
    autoStopHours: 0,
    ads: true,
    adblockerAllowed: false,
    support247: false,
    websiteOpenAd: false,
    restartAds: 1,
    actionAds: 1,
    color: '#cbd5e1',
    tagline: 'More bots, no auto-stop',
  },
  gold: {
    id: 'gold',
    name: 'Gold',
    price: 50,
    storageLabel: '750 MB',
    storageLimit: 786432000,
    maxBots: 10,
    maxBotsLabel: '10 bots',
    autoStopHours: 0,
    ads: true,
    adblockerAllowed: false,
    support247: true,
    websiteOpenAd: false,
    restartAds: 1,
    actionAds: 1,
    color: '#f7971e',
    tagline: 'Best value for creators',
    popular: true,
  },
  diamond: {
    id: 'diamond',
    name: 'Diamond',
    price: 100,
    storageLabel: '1 GB',
    storageLimit: 1073741824,
    maxBots: 999,
    maxBotsLabel: 'Unlimited bots',
    autoStopHours: 0,
    ads: false,
    adblockerAllowed: true,
    support247: true,
    websiteOpenAd: false,
    restartAds: 0,
    actionAds: 0,
    color: '#a855f7',
    tagline: 'Unlimited power, zero ads',
  },
};

export const PLAN_ORDER = ['free', 'silver', 'gold', 'diamond'];
export const PLAN_LIST = PLAN_ORDER.map((id) => PLANS[id]);

/** Ads required for an action on a given plan. Mirrors backend AD_ACTIONS. */
export function adsForAction(planId, action) {
  const plan = PLANS[planId] || PLANS.free;
  if (!plan.ads) return { required: false, count: 0, duration: 5 };
  const rules = {
    website_open: { plans: ['free'], count: 1 },
    deploy: { plans: ['free', 'silver', 'gold'], count: 1 },
    start: { plans: ['free', 'silver', 'gold'], count: 1 },
    restart: { plans: ['free', 'silver', 'gold'], planBased: true },
    scroll_logs: { plans: ['free', 'silver', 'gold'], count: 1 },
    file_manager: { plans: ['free', 'silver', 'gold'], count: 1 },
  };
  const rule = rules[action];
  if (!rule || !rule.plans.includes(plan.id)) return { required: false, count: 0, duration: 5 };
  const count = rule.planBased ? plan.restartAds || 1 : rule.count;
  return { required: count > 0, count, duration: 5 };
}
