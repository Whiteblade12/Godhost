/** Axios API client with JWT interceptor. */
import axios from 'axios';
import { API_URL, TOKEN_KEY } from '../constants/config';

const api = axios.create({
  baseURL: `${API_URL}/api`,
  timeout: 20000,
  withCredentials: true, // send HttpOnly admin session cookie
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      localStorage.removeItem(TOKEN_KEY);
      if (!window.location.pathname.startsWith('/login')) {
        window.dispatchEvent(new CustomEvent('gh:unauthorized'));
      }
    }
    return Promise.reject(err);
  }
);

/* ---------------- Auth ---------------- */
export const authApi = {
  google: (payload) => api.post('/auth/google', payload),
  me: () => api.get('/auth/me'),
  logout: () => api.post('/auth/logout'),
  refresh: () => api.post('/auth/refresh'),
};

/* ---------------- Users ---------------- */
export const usersApi = {
  profile: () => api.get('/users/profile'),
  updateProfile: (data) => api.put('/users/profile', data),
  stats: () => api.get('/users/stats'),
  plan: () => api.get('/users/plan'),
  wallet: () => api.get('/users/wallet'),
};

/* ---------------- Bots ---------------- */
export const botsApi = {
  list: () => api.get('/bots'),
  create: (data) => api.post('/bots', data),
  get: (id) => api.get(`/bots/${id}`),
  update: (id, data) => api.put(`/bots/${id}`, data),
  updateConfig: (id, data) => api.put(`/bots/${id}/config`, data),
  saveCode: (id, code, filename = 'main.py') => api.post(`/bots/${id}/code`, { code, filename }),
  start: (id, adWatchIds = []) => api.post(`/bots/${id}/start`, { adWatchIds }),
  stop: (id) => api.post(`/bots/${id}/stop`),
  restart: (id, adWatchIds = []) => api.post(`/bots/${id}/restart`, { adWatchIds }),
  remove: (id) => api.delete(`/bots/${id}`),
  logs: (id, tail = 200) => api.get(`/bots/${id}/logs`, { params: { tail } }),
  upload: (id, file, onProgress) => {
    const form = new FormData();
    form.append('file', file, file.name);
    return api.post(`/bots/${id}/upload`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: onProgress,
    });
  },
  files: (id) => api.get(`/bots/${id}/files`),
  deleteFile: (id, filename) => api.delete(`/bots/${id}/files`, { data: { filename } }),
};

/* ---------------- Ads ---------------- */
export const adsApi = {
  check: () => api.get('/ads/check'),
  status: (action, botId) => api.get('/ads/status', { params: { action, botId } }),
  watch: (action, botId) => api.post('/ads/watch', { action, botId }),
  complete: (adWatchId) => api.post('/ads/complete', { adWatchId }),
  reportAdBlocker: (detected, methods) => api.post('/ads/adblocker', { detected, methods }),
  rewardWatch: () => api.post('/ads/reward/watch'),
  rewardComplete: (adWatchId) => api.post('/ads/reward/complete', { adWatchId }),
};

/* ---------------- Payments ---------------- */
export const paymentsApi = {
  plans: () => api.get('/plans'),
  create: (planType) => api.post('/payments/create', { planType }),
  verify: (paymentId, utr) => api.post('/payments/verify', { paymentId, utr }),
  history: () => api.get('/payments/history'),
  status: (paymentId) => api.get(`/payments/status/${paymentId}`),
  qrUrl: (paymentId) => `${API_URL}/api/payments/qr/${paymentId}`,
};

/* ---------------- Referrals ---------------- */
export const referralsApi = {
  stats: () => api.get('/referrals/stats'),
  code: () => api.post('/referrals/code'),
  earnings: () => api.get('/referrals/earnings'),
  claim: () => api.post('/referrals/claim'),
  payout: (upiId) => api.post('/referrals/payout', { upiId }),
};

export default api;
