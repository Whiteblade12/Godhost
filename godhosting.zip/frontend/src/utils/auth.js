/** Firebase initialization + Google sign-in helper. */
import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
};

export const firebaseEnabled = Boolean(
  firebaseConfig.apiKey &&
    firebaseConfig.apiKey !== 'your_api_key' &&
    firebaseConfig.projectId
);

let auth = null;
let provider = null;

if (firebaseEnabled) {
  const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  auth = getAuth(app);
  provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
}

/** Returns a Firebase ID token for the signed-in Google account. */
export async function signInWithGoogle() {
  if (!firebaseEnabled) {
    throw new Error(
      'Firebase is not configured. Set REACT_APP_FIREBASE_* variables, or enable DEMO_MODE.'
    );
  }
  const result = await signInWithPopup(auth, provider);
  return result.user.getIdToken();
}

export async function firebaseSignOut() {
  if (auth) {
    try {
      await fbSignOut(auth);
    } catch {
      /* ignore */
    }
  }
}

export { auth };
