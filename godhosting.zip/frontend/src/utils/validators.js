/** Client-side input validation helpers. */

export function isValidBotToken(token) {
  return /^\d{6,12}:[A-Za-z0-9_-]{30,50}$/.test(String(token || '').trim());
}

export function isValidBotName(name) {
  const n = String(name || '').trim();
  return n.length >= 2 && n.length <= 60;
}

export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ''));
}

export function isValidUtr(utr) {
  return /^[A-Za-z0-9]{8,16}$/.test(String(utr || '').trim());
}

export function isValidDisplayName(name) {
  const n = String(name || '').trim();
  return n.length >= 2 && n.length <= 60;
}

export function errorMessage(err, fallback = 'Something went wrong. Please try again.') {
  return (
    err?.response?.data?.message ||
    err?.response?.data?.error ||
    err?.message ||
    fallback
  );
}

export function isAdsRequiredError(err) {
  return err?.response?.status === 402 && err?.response?.data?.error === 'ads_required';
}

export function isAdBlockerError(err) {
  return (
    err?.response?.status === 403 &&
    (err?.response?.data?.error === 'adblocker_detected' ||
      err?.response?.data?.error === 'ad_check_required')
  );
}
