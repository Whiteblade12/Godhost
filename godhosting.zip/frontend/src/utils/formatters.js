/** Formatting utilities. */

export function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (n === 0) return '0 MB';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), units.length - 1);
  const value = n / 1024 ** i;
  return `${value >= 10 || i === 0 ? Math.round(value) : value.toFixed(1)} ${units[i]}`;
}

export function percentUsed(used, limit) {
  if (!limit) return 0;
  return Math.min(100, Math.round((Number(used || 0) / Number(limit)) * 100));
}

export function formatINR(amount) {
  return `₹${Number(amount || 0).toLocaleString('en-IN')}`;
}

export function formatUptime(seconds) {
  const s = Math.max(0, Number(seconds || 0));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m ${s % 60}s`;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h}h ${m}m`;
}

export function formatDate(date) {
  if (!date) return '—';
  return new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(date) {
  if (!date) return '—';
  return new Date(date).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function planBadgeStyle(planId) {
  const map = {
    free: { background: 'rgba(136,146,176,0.15)', color: '#8892b0' },
    silver: { background: 'rgba(203,213,225,0.15)', color: '#cbd5e1' },
    gold: { background: 'rgba(247,151,30,0.15)', color: '#f7971e' },
    platinum: { background: 'rgba(129,140,248,0.15)', color: '#818cf8' },
    diamond: { background: 'rgba(168,85,247,0.15)', color: '#a855f7' },
  };
  return map[planId] || map.free;
}

export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      return true;
    } catch {
      return false;
    }
  }
}
