/**
 * Multi-method ad-blocker detection.
 * Runs several independent tests; if ANY test detects blocking, the user is
 * flagged. Results are reported to the backend which blocks actions for
 * ad-supported plans (Free / Silver / Gold).
 */
import { adsApi } from './api';

/** METHOD 1: hidden ad element gets collapsed/hidden by blockers */
function testAdElement() {
  return new Promise((resolve) => {
    try {
      const el = document.createElement('div');
      el.className = 'adsbox ad-banner textad pub_300x250';
      el.innerHTML = '&nbsp;';
      el.style.cssText =
        'position:absolute;left:-9999px;top:-9999px;height:10px;width:10px;display:block;visibility:visible;';
      document.body.appendChild(el);
      window.setTimeout(() => {
        let blocked = false;
        try {
          const style = window.getComputedStyle(el);
          blocked =
            el.offsetHeight === 0 ||
            el.offsetParent === null ||
            style.display === 'none' ||
            style.visibility === 'hidden' ||
            style.getPropertyValue('height') === '0px';
        } catch {
          blocked = false;
        }
        el.remove();
        resolve(blocked);
      }, 250);
    } catch {
      resolve(false);
    }
  });
}

/** METHOD 2: known ad image fails to load when blocked */
function testImageLoad() {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      let done = false;
      const finish = (blocked) => {
        if (!done) {
          done = true;
          resolve(blocked);
        }
      };
      img.onload = () => finish(false);
      img.onerror = () => finish(true);
      img.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?img=1&r=${Date.now()}`;
      window.setTimeout(() => finish(false), 3500);
    } catch {
      resolve(false);
    }
  });
}

/** METHOD 3: fetch to our own ad endpoint (blockers also kill same-origin /ads paths via cosmetic rules on some setups) */
function testFetchRequest() {
  return new Promise((resolve) => {
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => {
        controller.abort();
        resolve(true);
      }, 4000);
      fetch(`${process.env.REACT_APP_API_URL || ''}/api/ads/test?r=${Date.now()}`, {
        method: 'HEAD',
        cache: 'no-store',
        signal: controller.signal,
      })
        .then(() => {
          window.clearTimeout(timer);
          resolve(false);
        })
        .catch(() => {
          window.clearTimeout(timer);
          resolve(true);
        });
    } catch {
      resolve(true);
    }
  });
}

/** METHOD 4: known ad script fails to load when blocked */
function testScriptLoad() {
  return new Promise((resolve) => {
    try {
      const script = document.createElement('script');
      let done = false;
      const finish = (blocked) => {
        if (!done) {
          done = true;
          try {
            script.remove();
          } catch {
            /* ignore */
          }
          resolve(blocked);
        }
      };
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?r=${Date.now()}`;
      script.async = true;
      script.onload = () => finish(false);
      script.onerror = () => finish(true);
      document.head.appendChild(script);
      window.setTimeout(() => finish(false), 4000);
    } catch {
      resolve(false);
    }
  });
}

/** METHOD 5: global variables commonly set by ad scripts / bait */
function testGlobalVariables() {
  return Promise.resolve().then(() => {
    try {
      // Some blockers expose themselves or strip ad globals; also check for
      // well-known blocker fingerprints on window.
      const suspicious = ['__adblock__', 'adblockDetected'];
      return suspicious.some((k) => window[k] === true);
    } catch {
      return false;
    }
  });
}

/** METHOD 6: CSS rule bait - ad-class rules get neutralized by blockers */
function testCssRule() {
  return new Promise((resolve) => {
    try {
      const style = document.createElement('style');
      style.textContent =
        '.gh-ad-bait { display: block !important; height: 12px !important; position: absolute !important; left: -9999px !important; }';
      document.head.appendChild(style);
      const el = document.createElement('div');
      el.className = 'gh-ad-bait';
      document.body.appendChild(el);
      window.setTimeout(() => {
        let blocked = false;
        try {
          const cs = window.getComputedStyle(el);
          blocked = cs.display === 'none' || el.offsetHeight === 0;
        } catch {
          blocked = false;
        }
        el.remove();
        style.remove();
        resolve(blocked);
      }, 200);
    } catch {
      resolve(false);
    }
  });
}

const METHODS = [
  { name: 'ad_element', fn: testAdElement },
  { name: 'image_load', fn: testImageLoad },
  { name: 'fetch_request', fn: testFetchRequest },
  { name: 'script_load', fn: testScriptLoad },
  { name: 'global_variables', fn: testGlobalVariables },
  { name: 'css_rule', fn: testCssRule },
];

/** Run all detection methods. Returns { detected, methods:[names that triggered] }. */
export async function detectAdBlocker() {
  const triggered = [];
  await Promise.all(
    METHODS.map(async ({ name, fn }) => {
      try {
        const blocked = await fn();
        if (blocked) triggered.push(name);
      } catch {
        /* individual method failure is not evidence of blocking */
      }
    })
  );
  return { detected: triggered.length > 0, methods: triggered };
}

/** Run detection and report the result to the backend (best effort). */
export async function detectAndReport() {
  const result = await detectAdBlocker();
  try {
    await adsApi.reportAdBlocker(result.detected, result.methods);
  } catch {
    /* reporting failure should never break the UI */
  }
  return result;
}

export default detectAdBlocker;
