import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { errorMessage } from '../utils/validators';
import { formatBytes, formatDate, formatINR, planBadgeStyle } from '../utils/formatters';
import LoadingSpinner from './LoadingSpinner';
import { CONTACT } from '../constants/config';
import { PLAN_LIST } from '../constants/plans';

/**
 * Admin Panel — visible only to accounts listed in ADMIN_EMAILS (backend enforced).
 * Overview stats, user management (+ manual plan override), plan price editor,
 * payment review (+ reject/refund) and ad revenue analytics.
 */
export default function Admin() {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [adRevenue, setAdRevenue] = useState(null);
  const [users, setUsers] = useState([]);
  const [payments, setPayments] = useState([]);
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState(null);
  const [security, setSecurity] = useState(null);

  /** Gate: no admin session → bounce to /admin/auth/ */
  useEffect(() => {
    api
      .get('/admin/auth/me')
      .then((res) => setAdmin(res.data.admin))
      .catch(() => navigate('/admin/auth', { replace: true }));
  }, [navigate]);

  const logout = async () => {
    try {
      await api.post('/admin/auth/logout');
    } catch {
      /* ignore */
    }
    navigate('/admin/auth', { replace: true });
  };

  const load = useCallback(async () => {
    try {
      const [s, ar, u, p] = await Promise.all([
        api.get('/admin/stats'),
        api.get('/admin/ad-revenue'),
        api.get('/admin/users', { params: { limit: 200 } }),
        api.get('/admin/payments', { params: { limit: 100 } }),
      ]);
      setStats(s.data);
      setAdRevenue(ar.data);
      setUsers(u.data.users || []);
      setPayments(p.data.payments || []);
      api.get('/admin/security').then((r) => setSecurity(r.data)).catch(() => {});
    } catch (err) {
      if (err?.response?.status === 401 || err?.response?.status === 403) {
        navigate('/admin/auth', { replace: true });
        return;
      }
      setNotice(errorMessage(err, 'Failed to load admin data.'));
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    load();
  }, [load]);

  const updatePrice = async (planType, price) => {
    setBusy(`price-${planType}`);
    setNotice(null);
    try {
      await api.post('/admin/plans', { planType, price });
      setNotice(`✅ ${planType} price updated to ${formatINR(price)}.`);
      load();
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setBusy(null);
    }
  };

  const overridePlan = async (userId, planType) => {
    setBusy(`plan-${userId}`);
    setNotice(null);
    try {
      await api.post(`/admin/users/${userId}/plan`, { planType, days: 30 });
      setNotice(`✅ User #${userId} set to ${planType} for 30 days.`);
      load();
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setBusy(null);
    }
  };

  const rejectPayment = async (id) => {
    if (!window.confirm('Reject this payment?')) return;
    setBusy(`pay-${id}`);
    try {
      await api.post(`/admin/payments/${id}/reject`);
      setNotice(`Payment #${id} rejected.`);
      load();
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setBusy(null);
    }
  };

  if (loading) return <LoadingSpinner label="Loading admin panel..." />;

  const filteredUsers = users.filter(
    (u) =>
      !search ||
      String(u.email || '').toLowerCase().includes(search.toLowerCase()) ||
      String(u.display_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const tabs = [
    ['overview', '📊 Overview'],
    ['users', `👥 Users (${users.length})`],
    ['plans', '💎 Plan prices'],
    ['payments', `💳 Payments (${payments.length})`],
    ['security', '🛡️ Security'],
  ];

  return (
    <div className="container-gh py-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-black">
            <span className="gold-text">Admin</span> Panel 🛠️
          </h1>
          <p className="text-brand-muted text-sm mt-1">
            Signed in as <span className="text-brand-gold font-semibold">{admin ? admin.email : '...'}</span> •
            godhosting.online/admin/auth/
          </p>
        </div>
        <button className="btn-danger" onClick={logout}>🔒 Log out</button>
      </div>

      {notice && (
        <div className="mb-5 p-3 rounded-lg bg-brand-deep/60 border border-brand-line text-sm gh-fade-in">{notice}</div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {tabs.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${
              tab === id ? 'bg-gold-gradient text-black' : 'bg-brand-card border border-brand-line text-brand-muted hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* ============ OVERVIEW ============ */}
      {tab === 'overview' && stats && (
        <div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              { label: 'Total users', value: stats.users, icon: '👥' },
              { label: 'Total bots', value: stats.bots, icon: '🤖' },
              { label: 'Bots running now', value: stats.runningBots, icon: '🟢' },
              { label: 'Revenue (UPI)', value: formatINR(stats.revenueINR), icon: '💰' },
              { label: 'Ads watched', value: stats.adsWatched, icon: '📺' },
            ].map((s) => (
              <div key={s.label} className="card p-5">
                <div className="text-2xl" aria-hidden="true">{s.icon}</div>
                <div className="text-2xl font-black gold-text mt-2">{s.value}</div>
                <div className="text-xs text-brand-muted mt-1">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div className="card p-6">
              <h3 className="font-bold mb-4">📺 Ad revenue analytics</h3>
              {adRevenue ? (
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-brand-muted">Completed ad views</span>
                    <span className="font-bold">{adRevenue.adsWatched.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-brand-muted">Estimated earnings</span>
                    <span className="font-black gold-text text-lg">{formatINR(adRevenue.estimatedINR)}</span>
                  </div>
                  <p className="text-[11px] text-brand-muted">{adRevenue.note}</p>
                </div>
              ) : (
                <p className="text-brand-muted text-sm">No data.</p>
              )}
            </div>
            <div className="card p-6">
              <h3 className="font-bold mb-4">💎 Plan distribution</h3>
              <div className="space-y-2 text-sm">
                {PLAN_LIST.map((p) => {
                  const n = users.filter((u) => u.plan_type === p.id).length;
                  const pct = users.length ? Math.round((n / users.length) * 100) : 0;
                  return (
                    <div key={p.id}>
                      <div className="flex justify-between mb-1">
                        <span style={{ color: p.color }} className="font-bold">{p.name}</span>
                        <span className="text-brand-muted">{n} users ({pct}%)</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-brand-deep overflow-hidden">
                        <div className="h-full" style={{ width: `${pct}%`, background: p.color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============ USERS ============ */}
      {tab === 'users' && (
        <div className="card p-6">
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <input
              className="input-gh flex-1"
              placeholder="🔍 Search by email or name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button className="btn-ghost !py-2" onClick={load}>↻ Refresh</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[860px]">
              <thead>
                <tr className="text-brand-muted text-left">
                  <th className="py-2 pr-4">User</th>
                  <th className="py-2 pr-4">Plan</th>
                  <th className="py-2 pr-4">Storage</th>
                  <th className="py-2 pr-4">Ad blocker</th>
                  <th className="py-2 pr-4">Joined</th>
                  <th className="py-2">Override plan</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="border-t border-brand-line">
                    <td className="py-3 pr-4">
                      <div className="font-semibold">{u.display_name || '—'}</div>
                      <div className="text-xs text-brand-muted">{u.email}</div>
                    </td>
                    <td className="py-3 pr-4">
                      <span className="badge" style={{ ...planBadgeStyle(u.plan_type), textTransform: 'none' }}>
                        {u.plan_type}
                      </span>
                    </td>
                    <td className="py-3 pr-4 text-brand-muted">{formatBytes(u.storage_used)}</td>
                    <td className="py-3 pr-4">
                      {u.adblocker_detected
                        ? <span className="text-bad font-semibold">🚫 Detected ({u.adblocker_warnings || 0}×)</span>
                        : <span className="text-ok">✅ Clean</span>}
                    </td>
                    <td className="py-3 pr-4 text-brand-muted">{formatDate(u.created_at)}</td>
                    <td className="py-3">
                      <select
                        className="input-gh !py-1.5 !px-2 text-xs w-32"
                        value={u.plan_type}
                        disabled={busy === `plan-${u.id}`}
                        onChange={(e) => overridePlan(u.id, e.target.value)}
                        aria-label={`Override plan for ${u.email}`}
                      >
                        {PLAN_LIST.map((p) => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
                {filteredUsers.length === 0 && (
                  <tr><td colSpan="6" className="py-8 text-center text-brand-muted">No users found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============ PLAN PRICES ============ */}
      {tab === 'plans' && (
        <div className="card p-6 max-w-2xl">
          <h3 className="font-bold mb-1">💎 Edit plan prices</h3>
          <p className="text-brand-muted text-xs mb-5">Changes apply instantly across the platform and persist in the database.</p>
          <div className="space-y-3">
            {(stats ? stats.plans : PLAN_LIST).map((p) => (
              <PlanPriceRow key={p.id} plan={p} busy={busy === `price-${p.id}`} onSave={updatePrice} />
            ))}
          </div>
        </div>
      )}

      {/* ============ SECURITY ============ */}
      {tab === 'security' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="card p-6">
            <h3 className="font-bold mb-4">🛡️ DDoS Guard</h3>
            {security ? (
              <>
                <div className="p-3 rounded-lg bg-brand-deep/40 border border-brand-line text-sm font-mono text-brand-gold mb-4">
                  {security.rule}
                </div>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-brand-muted">Tracked IPs</span>
                    <span className="font-bold">{security.trackedIps}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-brand-muted">Currently banned (3h)</span>
                    <span className="font-black text-bad">{security.blockedCount}</span>
                  </div>
                </div>
                {security.blockedIps.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-xs uppercase tracking-wide text-brand-muted font-bold mb-2">Banned IPs</h4>
                    <ul className="space-y-1 font-mono text-xs max-h-48 overflow-y-auto">
                      {security.blockedIps.map((b) => (
                        <li key={b.ip} className="flex justify-between gap-2 p-2 rounded bg-brand-dark border border-brand-line">
                          <span className="text-bad">{b.ip}</span>
                          <span className="text-brand-muted">{b.minutesLeft} min left</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            ) : (
              <p className="text-brand-muted text-sm">Loading security data...</p>
            )}
            <button className="btn-ghost !py-2 mt-5" onClick={load}>↻ Refresh</button>
          </div>

          <div className="card p-6">
            <h3 className="font-bold mb-4">🔐 Security layers active</h3>
            <ul className="space-y-2 text-sm text-brand-muted">
              <li>✅ Admin login: email match + scrypt-hashed password (API-side only)</li>
              <li>✅ HttpOnly + SameSite=Strict admin session cookie</li>
              <li>✅ 5 failed logins → 15 min IP lockout</li>
              <li>✅ &gt;200 requests / 10 min → 3 hour IP ban (server + Cloudflare)</li>
              <li>✅ Attack signature shield (SQLi, XSS, traversal, Log4Shell)</li>
              <li>✅ Scanner probe blocking (.env, .git, wp-admin, phpmyadmin…)</li>
              <li>✅ HSTS + nosniff + Referrer-Policy headers</li>
              <li>✅ Helmet, CORS allowlist, global rate limiting</li>
              <li>✅ Parameterized SQL everywhere (no injection)</li>
              <li>✅ Slowloris request timeouts</li>
            </ul>
            <p className="text-[11px] text-brand-muted mt-4">
              Cloudflare setup guide: <code className="text-brand-gold">cloudflare/README.md</code> in the repo.
            </p>
          </div>
        </div>
      )}

      {/* ============ PAYMENTS ============ */}
      {tab === 'payments' && (
        <div className="card p-6">
          <h3 className="font-bold mb-4">💳 Payment review</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[860px]">
              <thead>
                <tr className="text-brand-muted text-left">
                  <th className="py-2 pr-4">Order ID</th>
                  <th className="py-2 pr-4">User</th>
                  <th className="py-2 pr-4">Plan</th>
                  <th className="py-2 pr-4">Amount</th>
                  <th className="py-2 pr-4">UTR</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2 pr-4">Date</th>
                  <th className="py-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-t border-brand-line">
                    <td className="py-3 pr-4 font-mono text-xs">{p.payment_id}</td>
                    <td className="py-3 pr-4">
                      <div className="font-semibold">{p.user_name || '—'}</div>
                      <div className="text-xs text-brand-muted">{p.user_email}</div>
                    </td>
                    <td className="py-3 pr-4 capitalize">{p.plan_type}</td>
                    <td className="py-3 pr-4 font-bold">{formatINR(p.amount)}</td>
                    <td className="py-3 pr-4 font-mono text-xs">{p.upi_transaction_id || '—'}</td>
                    <td className="py-3 pr-4">
                      <span className={`badge ${p.payment_status === 'confirmed' ? 'bg-ok/15 text-ok' : p.payment_status === 'rejected' ? 'bg-bad/15 text-bad' : 'bg-warn/15 text-warn'}`}>
                        {p.payment_status}
                      </span>
                    </td>
                    <td className="py-3 pr-4 text-brand-muted">{formatDate(p.created_at)}</td>
                    <td className="py-3">
                      {p.payment_status === 'confirmed' && (
                        <button
                          className="text-bad text-xs font-bold hover:underline"
                          disabled={busy === `pay-${p.id}`}
                          onClick={() => rejectPayment(p.id)}
                        >
                          Reject
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {payments.length === 0 && (
                  <tr><td colSpan="8" className="py-8 text-center text-brand-muted">No payments yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function PlanPriceRow({ plan, busy, onSave }) {
  const [value, setValue] = useState(plan.price);
  const dirty = Number(value) !== plan.price;
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-brand-dark border border-brand-line">
      <span className="font-black w-24" style={{ color: plan.color }}>{plan.name}</span>
      <div className="flex items-center gap-2 flex-1">
        <span className="text-brand-muted">₹</span>
        <input
          type="number"
          min="0"
          className="input-gh !py-2 w-28"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          aria-label={`${plan.name} price`}
        />
        <span className="text-brand-muted text-xs">/month</span>
      </div>
      <button
        className="btn-gold !px-4 !py-2 text-sm"
        disabled={!dirty || busy}
        onClick={() => onSave(plan.id, Number(value))}
      >
        {busy ? '...' : 'Save'}
      </button>
    </div>
  );
}
