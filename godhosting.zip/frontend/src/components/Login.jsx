import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { errorMessage } from '../utils/validators';
import { DEMO_MODE, CONTACT } from '../constants/config';
import { Logo } from './Navbar';

/** Google sign-in page. */
export default function Login() {
  const { user, login, firebaseEnabled } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [demoEmail, setDemoEmail] = useState('');

  const next = (location.state && location.state.from) || '/dashboard';

  useEffect(() => {
    if (user) navigate(next, { replace: true });
  }, [user, navigate, next]);

  const params = new URLSearchParams(location.search || window.location.search);
  const ref = params.get('ref');

  const handleGoogle = async () => {
    setBusy(true);
    setError(null);
    try {
      await login();
      navigate(next, { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Google sign-in failed. Please try again.'));
    } finally {
      setBusy(false);
    }
  };

  const handleDemo = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login({ demoEmail, demoName: demoEmail.split('@')[0] });
      navigate(next, { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Demo login failed.'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12 bg-hero-glow">
      <div className="card w-full max-w-md p-8 gh-slide-up">
        <div className="flex justify-center mb-6">
          <Logo size="lg" />
        </div>
        <h1 className="text-2xl font-black text-center">Welcome back</h1>
        <p className="text-brand-muted text-center text-sm mt-2 mb-8">
          Sign in to deploy and manage your Telegram bots.
          {ref && (
            <>
              <br />
              <span className="text-brand-gold">Referral code {ref} will be applied 🎉</span>
            </>
          )}
        </p>

        <button onClick={handleGoogle} disabled={busy || !firebaseEnabled} className="btn-gold w-full mb-3">
          <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6 29.4 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/>
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
            <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
            <path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C36.9 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z"/>
          </svg>
          {busy ? 'Signing in...' : 'Sign in with Google'}
        </button>

        {!firebaseEnabled && (
          <p className="text-warn text-xs text-center mb-3">
            Firebase keys not configured — Google login is disabled.{' '}
            {DEMO_MODE ? 'Use demo login below.' : 'Enable DEMO_MODE or add REACT_APP_FIREBASE_* variables.'}
          </p>
        )}

        {DEMO_MODE && (
          <form onSubmit={handleDemo} className="mt-2">
            <div className="flex items-center gap-2 text-xs text-brand-muted my-4">
              <div className="flex-1 h-px bg-brand-line" /> DEMO MODE <div className="flex-1 h-px bg-brand-line" />
            </div>
            <input
              type="email"
              required
              className="input-gh mb-3"
              placeholder="demo@godhosting.online"
              value={demoEmail}
              onChange={(e) => setDemoEmail(e.target.value)}
            />
            <button type="submit" disabled={busy} className="btn-ghost w-full">
              Demo login
            </button>
          </form>
        )}

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-bad/10 border border-bad/40 text-bad text-sm text-center">
            {error}
          </div>
        )}

        <p className="text-center text-brand-muted text-xs mt-6 leading-relaxed">
          No password needed — just your Google account.
          <br />
          By continuing you agree to fair usage. Ads keep the free plan free.
          <br />
          <Link to="/plans" className="text-brand-gold hover:underline">Compare plans</Link>
          {' • '}
          <a href={CONTACT.telegram} target="_blank" rel="noopener noreferrer" className="text-brand-gold hover:underline">
            Need help?
          </a>
        </p>
      </div>
    </div>
  );
}
