import React, { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { usersApi } from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import { usePlan } from '../hooks/usePlan';
import { errorMessage, isValidDisplayName } from '../utils/validators';
import { formatBytes, formatDate, formatDateTime, planBadgeStyle } from '../utils/formatters';
import LoadingSpinner from './LoadingSpinner';
import { CONTACT } from '../constants/config';

/** User profile: plan, usage, display name, activity, ad status. */
export default function Profile() {
  const { user, logout, refreshUser } = useAuth();
  const { plan } = usePlan();
  const navigate = useNavigate();

  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState(null);
  const [walletBalance, setWalletBalance] = useState('₹0.00');

  const load = useCallback(async () => {
    try {
      const res = await usersApi.profile();
      setStats(res.data.stats);
      setName(res.data.user.displayName || '');
      usersApi.wallet().then((w) => setWalletBalance(`₹${Number(w.data.balance || 0).toFixed(2)}`)).catch(() => {});
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const saveName = async (e) => {
    e.preventDefault();
    if (!isValidDisplayName(name)) {
      setNotice('Display name must be 2-60 characters.');
      return;
    }
    setSaving(true);
    try {
      await usersApi.updateProfile({ displayName: name.trim() });
      await refreshUser();
      setNotice('✅ Profile updated.');
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const doLogout = async () => {
    await logout();
    navigate('/');
  };

  if (loading) return <LoadingSpinner label="Loading profile..." />;
  if (!user) return null;

  return (
    <div className="container-gh py-10 max-w-4xl">
      <h1 className="text-3xl font-black mb-8">
        Your <span className="gold-text">profile</span>
      </h1>

      {notice && (
        <div className="mb-6 p-3 rounded-lg bg-brand-deep/60 border border-brand-line text-sm">{notice}</div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Account */}
        <div className="card p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-gold-gradient text-black font-black text-2xl flex items-center justify-center">
              {(user.displayName || user.email || 'U')[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="font-bold text-lg truncate">{user.displayName || 'Developer'}</div>
              <div className="text-brand-muted text-sm truncate">{user.email}</div>
            </div>
          </div>

          <form onSubmit={saveName}>
            <label className="block text-sm font-semibold mb-2" htmlFor="disp-name">Display name</label>
            <div className="flex gap-3">
              <input
                id="disp-name"
                className="input-gh"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={60}
              />
              <button className="btn-gold !px-5 shrink-0" disabled={saving}>
                {saving ? '...' : 'Save'}
              </button>
            </div>
          </form>

          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-brand-muted">Member since</dt>
              <dd className="font-semibold">{formatDate(user.createdAt)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-brand-muted">Referral code</dt>
              <dd className="font-mono font-semibold text-brand-gold">{user.referralCode}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-brand-muted">Ad status</dt>
              <dd className="font-semibold">
                {plan.ads
                  ? user.adblockerDetected
                    ? '🚫 Ad blocker detected'
                    : '✅ Ads enabled'
                  : '✨ Ad-free (premium)'}
              </dd>
            </div>
          </dl>

          <button className="btn-danger w-full mt-8" onClick={doLogout}>
            Log out
          </button>
        </div>

        {/* Plan & usage */}
        <div className="card p-6">
          <h2 className="font-bold mb-4">Plan & usage</h2>
          <div className="flex items-center justify-between mb-5">
            <span className="badge text-sm" style={{ ...planBadgeStyle(plan.id), fontSize: 13 }}>
              {plan.name} plan
            </span>
            {plan.price === 0 ? (
              <Link to="/plans" className="text-brand-gold text-sm font-bold hover:underline">Upgrade →</Link>
            ) : (
              <span className="text-sm text-brand-muted">
                ₹{plan.price}/mo • renews {formatDate(user.planExpiry)}
              </span>
            )}
          </div>

          <div className="space-y-5">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-brand-muted">Bots</span>
                <span className="font-semibold">{stats ? stats.botCount : 0} / {user.maxBots}</span>
              </div>
              <div className="h-2 rounded-full bg-brand-deep overflow-hidden">
                <div className="h-full bg-gold-gradient" style={{ width: `${Math.min(100, ((stats ? stats.botCount : 0) / Math.max(1, user.maxBots)) * 100)}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-brand-muted">Storage</span>
                <span className="font-semibold">
                  {formatBytes(stats ? stats.storageUsed : 0)} / {plan.storageLabel}
                </span>
              </div>
              <div className="h-2 rounded-full bg-brand-deep overflow-hidden">
                <div className="h-full bg-gold-gradient" style={{ width: `${Math.min(100, ((stats ? stats.storageUsed : 0) / Math.max(1, user.storageLimit)) * 100)}%` }} />
              </div>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-brand-muted">Ads watched today</span>
              <span className="font-semibold">{stats ? stats.adsWatchedToday : 0}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-brand-muted">Referrals</span>
              <span className="font-semibold">
                {stats && stats.referrals ? `${stats.referrals.total} total` : '0'}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-brand-muted">💰 Wallet balance</span>
              <span className="font-black gold-text">{walletBalance}</span>
            </div>
          </div>

          <Link to="/referrals" className="btn-ghost w-full mt-8">View referral earnings →</Link>
        </div>
      </div>

      {/* Activity */}
      <div className="card p-6 mt-6">
        <h2 className="font-bold mb-4">Recent activity</h2>
        {stats && stats.activity && stats.activity.length > 0 ? (
          <ul className="space-y-2 text-sm">
            {stats.activity.map((a, i) => (
              <li key={i} className="flex items-center justify-between gap-3 py-2 border-b border-brand-line last:border-0">
                <span className="font-mono text-xs text-brand-gold">{a.action_type}</span>
                <span className="text-brand-muted text-xs">{formatDateTime(a.created_at)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-brand-muted text-sm">No activity yet.</p>
        )}
      </div>

      <p className="text-center text-xs text-brand-muted mt-8">
        Need help with your account? Email{' '}
        <a className="text-brand-gold hover:underline" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>{' '}
        or message{' '}
        <a className="text-brand-gold hover:underline" href={CONTACT.telegram} target="_blank" rel="noopener noreferrer">
          {CONTACT.telegramHandle}
        </a>
      </p>
    </div>
  );
}
