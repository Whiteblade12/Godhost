import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAdBlocker } from '../hooks/useAdBlocker';
import { usePlan } from '../hooks/usePlan';

/**
 * Full-screen blocker shown when an ad blocker is detected on an
 * ad-supported plan (Free / Silver / Gold). Premium users never see this —
 * ad blockers are allowed on Platinum & Diamond.
 */
export default function AdBlockerWarning() {
  const { detected, methods, recheck } = useAdBlocker();
  const { isPremium, plan } = usePlan();

  useEffect(() => {
    if (detected && !isPremium) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [detected, isPremium]);

  if (!detected || isPremium) return null;

  return (
    <div
      id="adblocker-warning"
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="abw-title"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(26, 26, 46, 0.98)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 999999,
        padding: 20,
        overflowY: 'auto',
      }}
    >
      <div
        className="gh-slide-up"
        style={{
          background: '#16213e',
          padding: '40px 32px',
          borderRadius: 16,
          maxWidth: 520,
          width: '100%',
          textAlign: 'center',
          border: '2px solid #f7971e',
        }}
      >
        <div style={{ fontSize: 72, marginBottom: 20 }} aria-hidden="true">🚫</div>
        <h1
          id="abw-title"
          style={{ color: 'white', fontSize: 28, fontWeight: 800, marginBottom: 12 }}
        >
          Ad Blocker Detected
        </h1>
        <p style={{ color: '#8892b0', marginBottom: 16, fontSize: 16, lineHeight: 1.6 }}>
          GodHosting is <span style={{ color: '#f7971e', fontWeight: 700 }}>completely free</span>{' '}
          because of ads. Please disable your ad blocker to continue using the{' '}
          <strong style={{ color: '#fff' }}>{plan.name}</strong> plan.
        </p>
        <p style={{ color: '#8892b0', fontSize: 14, marginBottom: 24 }}>
          Or upgrade to <span style={{ color: '#a855f7', fontWeight: 700 }}>Diamond (₹100/mo)</span>{' '}
          for an <span style={{ color: '#4ade80', fontWeight: 700 }}>ad-free experience</span> — ad
          blockers are allowed there!
        </p>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button
            onClick={() => recheck()}
            style={{
              background: 'linear-gradient(135deg, #f7971e, #ffd200)',
              color: 'black',
              border: 'none',
              padding: '14px 32px',
              borderRadius: 8,
              fontWeight: 700,
              cursor: 'pointer',
              minHeight: 44,
            }}
          >
            I've Disabled My Ad Blocker
          </button>
          <Link
            to="/plans"
            style={{
              background: 'transparent',
              color: '#f7971e',
              border: '2px solid #f7971e',
              padding: '12px 28px',
              borderRadius: 8,
              fontWeight: 700,
              textDecoration: 'none',
              display: 'inline-block',
            }}
          >
            View Plans →
          </Link>
        </div>

        {methods.length > 0 && (
          <p style={{ color: '#6b7a9e', fontSize: 11, marginTop: 14 }}>
            Triggered by: {methods.join(', ')}
          </p>
        )}
        <p style={{ color: '#6b7a9e', fontSize: 12, marginTop: 16 }}>
          GodHosting uses multiple detection methods. All ad blockers will be detected.
          <br />
          Need help? Contact godhostings@gmail.com or t.me/TheGoat_father
        </p>
      </div>
    </div>
  );
}
