import React, { useCallback, useEffect, useRef, useState } from 'react';
import { adsApi } from '../utils/api';
import { AD_DURATION_SECONDS, CONTACT } from '../constants/config';

const ACTION_LABELS = {
  website_open: 'opening the website',
  deploy: 'deploying your bot',
  start: 'starting your bot',
  restart: 'restarting your bot',
  scroll_logs: 'viewing live logs',
  file_manager: 'opening the file manager',
};

/**
 * 5-second ad modal.
 * - Runs `count` ads sequentially (e.g. Free restart = 3 ads = 15s).
 * - Each ad creates a server watch session and is completed server-side,
 *   where the elapsed time is verified. Collects verified adWatchIds and
 *   hands them to onComplete so the action can proceed.
 */
export default function AdModal({ open, action, botId, count = 1, duration = AD_DURATION_SECONDS, onComplete, onClose }) {
  const [phase, setPhase] = useState('idle'); // idle | loading | playing | done
  const [current, setCurrent] = useState(1);
  const [remaining, setRemaining] = useState(duration);
  const [error, setError] = useState(null);
  const idsRef = useRef([]);
  const timerRef = useRef(null);
  const cancelledRef = useRef(false);

  const cleanup = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const playOne = useCallback(
    (index) => {
      setPhase('loading');
      setError(null);
      adsApi
        .watch(action, botId || undefined)
        .then((res) => {
          if (cancelledRef.current) return;
          const { adWatchId, duration: dur } = res.data;
          const total = dur || duration;
          setRemaining(total);
          setPhase('playing');

          const startedAt = Date.now();
          timerRef.current = setInterval(() => {
            const elapsed = (Date.now() - startedAt) / 1000;
            const left = Math.max(0, total - elapsed);
            setRemaining(left);
            if (left <= 0) {
              cleanup();
              adsApi
                .complete(adWatchId)
                .then((cres) => {
                  if (cancelledRef.current) return;
                  if (cres.data.verified) idsRef.current.push(adWatchId);
                  if (index < count) {
                    setCurrent(index + 1);
                    playOne(index + 1);
                  } else {
                    setPhase('done');
                    setTimeout(() => {
                      if (!cancelledRef.current) onComplete(idsRef.current);
                    }, 300);
                  }
                })
                .catch((err) => {
                  if (cancelledRef.current) return;
                  setError(err?.response?.data?.error || 'Ad verification failed. Please try again.');
                  setPhase('idle');
                });
            }
          }, 100);
        })
        .catch((err) => {
          if (cancelledRef.current) return;
          setError(
            err?.response?.data?.message ||
              'Could not start the ad. Check your connection and try again.'
          );
          setPhase('idle');
        });
    },
    [action, botId, count, duration, onComplete, cleanup]
  );

  useEffect(() => {
    if (open) {
      cancelledRef.current = false;
      idsRef.current = [];
      setCurrent(1);
      setPhase('idle');
      setError(null);
      const t = setTimeout(() => playOne(1), 250);
      return () => {
        clearTimeout(t);
        cleanup();
      };
    }
    return undefined;
  }, [open, playOne, cleanup]);

  const cancel = () => {
    cancelledRef.current = true;
    cleanup();
    onClose && onClose();
  };

  if (!open) return null;

  const label = ACTION_LABELS[action] || 'continuing';
  const progress = phase === 'playing' ? ((duration - remaining) / duration) * 100 : 0;

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm gh-fade-in"
      role="dialog"
      aria-modal="true"
      aria-label="Advertisement"
    >
      <div className="card w-full max-w-md p-6 sm:p-8 text-center">
        <div className="flex items-center justify-between mb-4">
          <span className="badge bg-brand-gold/15 text-brand-gold">Advertisement</span>
          {count > 1 && (
            <span className="text-sm text-brand-muted font-semibold">
              Ad {Math.min(current, count)} of {count}
            </span>
          )}
        </div>

        {phase === 'loading' && (
          <div className="py-10">
            <div className="w-12 h-12 mx-auto rounded-full border-4 border-brand-line border-t-brand-gold animate-spin" />
            <p className="text-brand-muted mt-4 text-sm">Loading ad...</p>
          </div>
        )}

        {phase === 'playing' && (
          <div>
            {/* Simulated ad slot - replace with AdSense/AdMob unit in production */}
            <div
              className="rounded-xl border border-dashed border-brand-line bg-brand-deep/40 flex flex-col items-center justify-center py-14 mb-6"
              style={{ minHeight: 220 }}
            >
              <div className="text-5xl mb-3" aria-hidden="true">📺</div>
              <p className="font-bold text-lg text-white">Your ad here</p>
              <p className="text-brand-muted text-sm mt-1">
                Advertise on GodHosting — reach thousands of bot developers.
              </p>
              <a
                href={`mailto:${CONTACT.email}?subject=Advertise on GodHosting`}
                className="text-brand-gold text-xs mt-3 underline"
              >
                {CONTACT.email}
              </a>
            </div>

            <p className="text-sm text-brand-muted mb-3">
              Please wait {Math.ceil(remaining)}s while we finish {label}...
            </p>
            <div className="h-3 rounded-full bg-brand-deep overflow-hidden">
              <div
                className="h-full bg-gold-gradient transition-[width] duration-100"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {phase === 'done' && (
          <div className="py-10">
            <div className="text-5xl mb-3">✅</div>
            <p className="font-bold">Ad complete — continuing...</p>
          </div>
        )}

        {phase === 'idle' && (
          <div className="py-8">
            {error ? (
              <>
                <p className="text-bad text-sm mb-4">{error}</p>
                <div className="flex gap-3 justify-center">
                  <button className="btn-gold !py-2" onClick={() => playOne(current)}>
                    Retry
                  </button>
                  <button className="btn-ghost !py-2" onClick={cancel}>
                    Cancel
                  </button>
                </div>
              </>
            ) : (
              <p className="text-brand-muted text-sm">Get ready...</p>
            )}
          </div>
        )}

        {phase !== 'done' && (
          <p className="text-[11px] text-brand-muted/70 mt-6">
            GodHosting stays free thanks to 5-second ads. Upgrade to Diamond (₹100/mo) to remove ads.
          </p>
        )}
      </div>
    </div>
  );
}
