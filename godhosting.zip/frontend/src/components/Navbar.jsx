import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { usePlan } from '../hooks/usePlan';
import { planBadgeStyle } from '../utils/formatters';

export function Logo({ size = 'md' }) {
  const dim = size === 'lg' ? 40 : 30;
  const text = size === 'lg' ? 'text-2xl' : 'text-xl';
  return (
    <span className="inline-flex items-center gap-2">
      <svg width={dim} height={dim} viewBox="0 0 64 64" aria-hidden="true">
        <defs>
          <linearGradient id="ghlogo" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#f7971e" />
            <stop offset="1" stopColor="#ffd200" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="14" fill="#0f3460" />
        <path d="M36 8 L18 36 h11 L26 56 L46 26 H34 Z" fill="url(#ghlogo)" />
      </svg>
      <span className={`font-black ${text} tracking-tight`}>
        God<span className="gold-text">Hosting</span>
      </span>
    </span>
  );
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const { plan } = usePlan();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);

  const linkClass = ({ isActive }) =>
    `px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
      isActive ? 'text-brand-gold bg-brand-deep/60' : 'text-brand-muted hover:text-white'
    }`;

  const doLogout = async () => {
    setMenu(false);
    setOpen(false);
    await logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 bg-brand-dark/90 backdrop-blur border-b border-brand-line">
      <nav className="container-gh flex items-center justify-between h-16" aria-label="Main navigation">
        <Link to="/" onClick={() => setOpen(false)} aria-label="GodHosting home">
          <Logo />
        </Link>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-1">
          <NavLink to="/" className={linkClass} end>
            Home
          </NavLink>
          <NavLink to="/plans" className={linkClass}>
            Plans
          </NavLink>
          {user && (
            <>
              <NavLink to="/dashboard" className={linkClass}>
                Dashboard
              </NavLink>
              <NavLink to="/referrals" className={linkClass}>
                Referrals
              </NavLink>
            </>
          )}
        </div>

        {/* Desktop auth area */}
        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setMenu((m) => !m)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-brand-card border border-brand-line hover:border-brand-gold transition-colors"
                aria-haspopup="menu"
                aria-expanded={menu}
              >
                <span
                  className="badge"
                  style={{ ...planBadgeStyle(plan.id), textTransform: 'none' }}
                >
                  {plan.name}
                </span>
                <span className="w-7 h-7 rounded-full bg-gold-gradient text-black font-black flex items-center justify-center text-sm">
                  {(user.displayName || user.email || 'U')[0].toUpperCase()}
                </span>
              </button>
              {menu && (
                <div className="absolute right-0 mt-2 w-48 card p-2 gh-fade-in" role="menu">
                  <div className="px-3 py-2 text-xs text-brand-muted truncate">{user.email}</div>
                  <Link
                    to="/profile"
                    onClick={() => setMenu(false)}
                    className="block px-3 py-2 rounded-lg hover:bg-brand-deep text-sm"
                    role="menuitem"
                  >
                    Profile
                  </Link>
                  <Link
                    to="/dashboard"
                    onClick={() => setMenu(false)}
                    className="block px-3 py-2 rounded-lg hover:bg-brand-deep text-sm"
                    role="menuitem"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={doLogout}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-brand-deep text-sm text-bad"
                    role="menuitem"
                  >
                    Log out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className="btn-gold !px-5 !py-2 text-sm">
              Sign in with Google
            </Link>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden p-2 rounded-lg text-brand-muted hover:text-white"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? (
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
            )}
          </svg>
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-brand-line bg-brand-dark gh-fade-in">
          <div className="container-gh py-3 flex flex-col gap-1">
            <NavLink to="/" className={linkClass} end onClick={() => setOpen(false)}>
              Home
            </NavLink>
            <NavLink to="/plans" className={linkClass} onClick={() => setOpen(false)}>
              Plans
            </NavLink>
            {user ? (
              <>
                <NavLink to="/dashboard" className={linkClass} onClick={() => setOpen(false)}>
                  Dashboard
                </NavLink>
                <NavLink to="/referrals" className={linkClass} onClick={() => setOpen(false)}>
                  Referrals
                </NavLink>
                <NavLink to="/profile" className={linkClass} onClick={() => setOpen(false)}>
                  Profile
                </NavLink>
                <button onClick={doLogout} className="text-left px-3 py-2 text-bad font-semibold">
                  Log out
                </button>
              </>
            ) : (
              <Link to="/login" className="btn-gold mt-2" onClick={() => setOpen(false)}>
                Sign in with Google
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
