import React, { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { paymentsApi } from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import { PLANS } from '../constants/plans';
import { errorMessage, isValidUtr } from '../utils/validators';
import { copyToClipboard, formatDate, formatINR } from '../utils/formatters';
import { CONTACT } from '../constants/config';
import LoadingSpinner from './LoadingSpinner';

/** UPI checkout for a plan: QR + deep link + UTR verification. */
export default function Payment() {
  const { planId } = useParams();
  const { refreshUser } = useAuth();
  const plan = PLANS[planId];

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [utr, setUtr] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [success, setSuccess] = useState(null);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState([]);

  const createOrder = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await paymentsApi.create(planId);
      setOrder(res.data);
    } catch (err) {
      setError(errorMessage(err, 'Could not create payment.'));
    } finally {
      setLoading(false);
    }
  }, [planId]);

  const loadHistory = useCallback(() => {
    paymentsApi
      .history()
      .then((res) => setHistory(res.data.payments || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!plan || plan.price === 0) return;
    createOrder();
    loadHistory();
  }, [plan, createOrder, loadHistory]);

  if (!plan) {
    return (
      <div className="container-gh py-20 text-center">
        <p className="text-brand-muted">Unknown plan.</p>
        <Link to="/plans" className="btn-gold mt-4">View plans</Link>
      </div>
    );
  }

  if (plan.price === 0) {
    return (
      <div className="container-gh py-20 text-center">
        <div className="text-6xl mb-4">🆓</div>
        <h1 className="text-2xl font-black">The Free plan needs no payment</h1>
        <p className="text-brand-muted mt-2">Just sign in and start hosting.</p>
        <Link to="/dashboard" className="btn-gold mt-6">Go to Dashboard →</Link>
      </div>
    );
  }

  const copyUpi = async () => {
    await copyToClipboard(order ? order.upiId : CONTACT.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const verify = async (e) => {
    e.preventDefault();
    if (!isValidUtr(utr)) {
      setError('Enter the 8-16 character UPI transaction ID (UTR) from your payment app.');
      return;
    }
    setVerifying(true);
    setError(null);
    try {
      const res = await paymentsApi.verify(order.payment.paymentId, utr.trim());
      setSuccess(res.data);
      await refreshUser();
      loadHistory();
    } catch (err) {
      setError(errorMessage(err, 'Verification failed. Double-check your UTR.'));
    } finally {
      setVerifying(false);
    }
  };

  if (success) {
    return (
      <div className="container-gh py-20 text-center max-w-lg">
        <div className="card p-10 gh-slide-up">
          <div className="text-6xl mb-4">🎉</div>
          <h1 className="text-2xl font-black gold-text">Payment Confirmed!</h1>
          <p className="text-brand-muted mt-3">
            Your <strong className="text-white">{plan.name}</strong> plan is now active until{' '}
            <strong className="text-white">
              {success.payment && success.payment.expiry_date
                ? formatDate(success.payment.expiry_date)
                : '+30 days'}
            </strong>
            . Enjoy {plan.ads ? 'faster hosting with fewer limits' : 'a 100% ad-free experience'}!
          </p>
          <Link to="/dashboard" className="btn-gold mt-8">Go to Dashboard →</Link>
        </div>
      </div>
    );
  }

  if (loading) return <LoadingSpinner label="Creating your UPI order..." />;

  return (
    <div className="container-gh py-12 max-w-4xl">
      <Link to="/plans" className="text-brand-muted text-sm hover:text-brand-gold">← Back to plans</Link>
      <h1 className="text-3xl font-black mt-2 mb-8">
        Checkout: <span style={{ color: plan.color }}>{plan.name}</span> — {formatINR(plan.price)}/mo
      </h1>

      {error && (
        <div className="mb-6 p-3 rounded-lg bg-bad/10 border border-bad/40 text-bad text-sm">{error}</div>
      )}

      {order && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* QR + UPI */}
          <div className="card p-6 text-center">
            <h2 className="font-bold mb-4">1. Scan & Pay {formatINR(order.payment.amount)}</h2>
            <div className="bg-white rounded-xl p-4 inline-block">
              <img
                src={paymentsApi.qrUrl(order.payment.paymentId)}
                alt={`UPI QR code for ${formatINR(order.payment.amount)} to ${order.upiId}`}
                width="240"
                height="240"
              />
            </div>
            <p className="text-brand-muted text-xs mt-3">Works with GPay, PhonePe, Paytm & all UPI apps</p>

            <div className="mt-5 p-3 rounded-lg bg-brand-dark border border-brand-line flex items-center justify-between gap-2">
              <div className="text-left min-w-0">
                <div className="text-[11px] text-brand-muted uppercase tracking-wide">UPI ID</div>
                <div className="font-mono font-bold truncate">{order.upiId}</div>
              </div>
              <button className="btn-ghost !px-3 !py-2 text-xs shrink-0" onClick={copyUpi}>
                {copied ? '✓ Copied' : 'Copy'}
              </button>
            </div>

            <a href={order.upiLink} className="btn-gold w-full mt-4">
              📱 Pay with UPI app
            </a>
            <p className="text-[11px] text-brand-muted mt-2">Order ID: {order.payment.paymentId}</p>
          </div>

          {/* UTR verify */}
          <div className="card p-6">
            <h2 className="font-bold mb-2">2. Enter your UPI Transaction ID</h2>
            <p className="text-brand-muted text-sm mb-5">
              After paying, copy the <strong>UTR / transaction reference</strong> from your UPI app
              and paste it below. Your plan activates instantly.
            </p>
            <form onSubmit={verify}>
              <input
                className="input-gh font-mono mb-2"
                placeholder="e.g. 409215382811"
                value={utr}
                onChange={(e) => setUtr(e.target.value)}
                aria-label="UPI transaction ID (UTR)"
              />
              <p className="text-[11px] text-brand-muted mb-4">
                GPay: transaction details → UPI transaction ID. PhonePe: transaction → UTR.
              </p>
              <button className="btn-gold w-full" disabled={verifying}>
                {verifying ? 'Verifying payment...' : "✅ I've Paid — Activate Plan"}
              </button>
            </form>

            <div className="mt-6 p-4 rounded-lg bg-brand-deep/40 border border-brand-line text-xs text-brand-muted leading-relaxed">
              <strong className="text-white">Payment not reflecting?</strong>
              <br />
              Email {CONTACT.email} with your UTR and order ID ({order.payment.paymentId}), or
              message {CONTACT.telegramHandle} on Telegram. We resolve payment issues within hours.
            </div>
          </div>
        </div>
      )}

      {/* History */}
      <div className="card p-6 mt-8">
        <h2 className="font-bold mb-4">Payment history</h2>
        {history.length === 0 ? (
          <p className="text-brand-muted text-sm">No payments yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[520px]">
              <thead>
                <tr className="text-brand-muted text-left">
                  <th className="py-2 pr-4">Order</th>
                  <th className="py-2 pr-4">Plan</th>
                  <th className="py-2 pr-4">Amount</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2">Date</th>
                </tr>
              </thead>
              <tbody>
                {history.map((p) => (
                  <tr key={p.id} className="border-t border-brand-line">
                    <td className="py-2 pr-4 font-mono text-xs">{p.payment_id}</td>
                    <td className="py-2 pr-4 capitalize">{p.plan_type}</td>
                    <td className="py-2 pr-4">{formatINR(p.amount)}</td>
                    <td className="py-2 pr-4">
                      <span
                        className={`badge ${
                          p.payment_status === 'confirmed'
                            ? 'bg-ok/15 text-ok'
                            : p.payment_status === 'rejected'
                            ? 'bg-bad/15 text-bad'
                            : 'bg-warn/15 text-warn'
                        }`}
                      >
                        {p.payment_status}
                      </span>
                    </td>
                    <td className="py-2 text-brand-muted">{formatDate(p.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
