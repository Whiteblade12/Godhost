import React, { useCallback, useEffect, useState } from 'react';
import { referralsApi, usersApi } from '../utils/api';
import { errorMessage } from '../utils/validators';
import { copyToClipboard, formatDateTime, formatINR } from '../utils/formatters';
import LoadingSpinner from './LoadingSpinner';
import EarnAds from './EarnAds';
import { CONTACT } from '../constants/config';

/**
 * Earn page: 7-day referral streaks (₹3 bonus), wallet balance,
 * watch-to-win rewarded ads (₹0.25 per 5 ads), UPI payout requests.
 */
export default function Referrals() {
  const [stats, setStats] = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [wallet, setWallet] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState(null);
  const [copied, setCopied] = useState(null);
  const [busy, setBusy] = useState(false);
  const [showEarn, setShowEarn] = useState(false);
  const [upiId, setUpiId] = useState('');

  const load = useCallback(async () => {
    try {
      const [er, w] = await Promise.all([referralsApi.earnings(), usersApi.wallet()]);
      setStats(er.data.stats);
      setReferrals(er.data.referrals || []);
      setWallet(w.data);
    } catch (err) {
      setNotice(errorMessage(err, 'Could not load data.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const copy = async (key, text) => {
    await copyToClipboard(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  const requestPayout = async () => {
    setBusy(true);
    setNotice(null);
    try {
      const res = await referralsApi.payout(upiId.trim());
      setNotice(`💰 ${res.note}`);
      load();
    } catch (err) {
      setNotice(errorMessage(err, 'Payout request failed.'));
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading your earnings..." />;
  if (!stats) {
    return (
      <div className="container-gh py-16 text-center">
        {notice && <p className="text-bad text-sm mb-4">{notice}</p>}
        <button className="btn-gold" onClick={load}>Retry</button>
      </div>
    );
  }

  const balance = wallet ? Number(wallet.balance) : 0;

  return (
    <div className="container-gh py-10 max-w-4xl">
      <h1 className="text-3xl font-black">
        Earn with <span className="gold-text">GodHosting</span> 💰
      </h1>
      <p className="text-brand-muted text-sm mt-2">
        Two ways to earn: <strong className="text-white">7-day referral streaks (₹{stats.bonusPerCompletion || 3})</strong>{' '}
        and <strong className="text-white">watch-to-win ads (₹0.25 per 5 ads)</strong>. Everything lands in your wallet, paid out via UPI.
      </p>

      {/* Wallet card */}
      <div className="card p-6 mt-8 bg-gold-gradient !border-0 text-black">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold uppercase tracking-wide opacity-70">Wallet balance</div>
            <div className="text-4xl font-black mt-1">{formatINR(balance)}</div>
            {wallet && (
              <div className="text-xs font-semibold opacity-75 mt-1">
                Rewarded ads progress: {wallet.pendingAdClicks || 0}/{wallet.adsToNextReward !== undefined ? 5 : 5} — next ₹0.25 in {wallet.adsToNextReward || 0} ads
              </div>
            )}
          </div>
          <div className="flex gap-3">
            <button
              className="bg-black text-white font-bold px-6 py-3 rounded-lg hover:bg-black/85 transition-colors"
              onClick={() => setShowEarn(true)}
            >
              📺 Watch ads & earn
            </button>
          </div>
        </div>
        {/* Payout */}
        <div className="mt-5 flex flex-col sm:flex-row gap-3">
          <input
            className="flex-1 bg-black/85 text-white rounded-lg px-4 py-3 text-sm placeholder-white/50 font-mono"
            placeholder="Your UPI ID for payout (e.g. name@upi)"
            value={upiId}
            onChange={(e) => setUpiId(e.target.value)}
          />
          <button
            className="bg-black text-white font-bold px-6 py-3 rounded-lg hover:bg-black/85 transition-colors disabled:opacity-50"
            onClick={requestPayout}
            disabled={busy || balance <= 0}
          >
            {busy ? 'Requesting...' : `💸 Withdraw ${formatINR(balance)}`}
          </button>
        </div>
        <p className="text-[11px] font-semibold opacity-70 mt-3">
          Payouts sent via UPI within 48h • support: {CONTACT.telegramHandle}
        </p>
      </div>

      {/* Referral link */}
      <div className="card p-6 mt-6">
        <div className="text-sm font-bold uppercase tracking-wide text-brand-muted">Your referral link</div>
        <div className="mt-3 flex flex-col sm:flex-row gap-3">
          <div className="flex-1 bg-brand-dark border border-brand-line font-mono text-sm rounded-lg px-4 py-3 truncate">
            {stats.link}
          </div>
          <button className="btn-gold !px-6 shrink-0" onClick={() => copy('link', stats.link)}>
            {copied === 'link' ? '✓ Copied!' : 'Copy link'}
          </button>
        </div>
        <p className="text-xs text-brand-muted mt-3">
          Your friend must log in <strong className="text-white">{stats.streakDaysRequired || 7} days in a row</strong> — then ₹
          {stats.bonusPerCompletion || 3} is credited here automatically. A 48h absence fails the streak.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {[
          { label: 'Total referrals', value: stats.totalReferrals },
          { label: 'Streaks in progress', value: stats.pending },
          { label: 'Completed (paid)', value: stats.completed },
          { label: 'Wallet', value: formatINR(balance) },
        ].map((s) => (
          <div key={s.label} className="card p-5 text-center">
            <div className="text-2xl font-black gold-text">{s.value}</div>
            <div className="text-xs text-brand-muted mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {notice && (
        <div className="mt-6 p-3 rounded-lg bg-brand-deep/60 border border-brand-line text-sm gh-fade-in">{notice}</div>
      )}

      {/* Referrals list with streak progress */}
      <div className="card p-6 mt-6">
        <h2 className="font-bold mb-4">Your referrals</h2>
        {referrals.length === 0 ? (
          <p className="text-brand-muted text-sm">
            No referrals yet. Share your link above — one share starts a ₹{stats.bonusPerCompletion || 3} streak!
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[560px]">
              <thead>
                <tr className="text-brand-muted text-left">
                  <th className="py-2 pr-4">User</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2 pr-4">Streak</th>
                  <th className="py-2">Joined</th>
                </tr>
              </thead>
              <tbody>
                {referrals.map((r) => (
                  <tr key={r.id} className="border-t border-brand-line">
                    <td className="py-3 pr-4 font-semibold">{r.referred_name || 'User'}</td>
                    <td className="py-3 pr-4">
                      <span
                        className={`badge ${
                          r.status === 'completed'
                            ? 'bg-ok/15 text-ok'
                            : r.status === 'failed'
                            ? 'bg-bad/15 text-bad'
                            : 'bg-warn/15 text-warn'
                        }`}
                      >
                        {r.status === 'completed' ? '✅ ₹3 earned' : r.status === 'failed' ? '❌ failed' : '⏳ in progress'}
                      </span>
                    </td>
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 rounded-full bg-brand-deep overflow-hidden">
                          <div
                            className="h-full bg-gold-gradient"
                            style={{ width: `${Math.min(100, ((r.streak_days || 0) / (stats.streakDaysRequired || 7)) * 100)}%` }}
                          />
                        </div>
                        <span className="text-xs text-brand-muted">
                          {r.streak_days || 0}/{stats.streakDaysRequired || 7} days
                        </span>
                      </div>
                    </td>
                    <td className="py-3 text-brand-muted">{formatDateTime(r.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Wallet transactions */}
      {wallet && wallet.transactions && wallet.transactions.length > 0 && (
        <div className="card p-6 mt-6">
          <h2 className="font-bold mb-4">Wallet transactions</h2>
          <ul className="space-y-2 text-sm">
            {wallet.transactions.map((t, i) => (
              <li key={i} className="flex items-center justify-between gap-3 py-2 border-b border-brand-line last:border-0">
                <span className="font-mono text-xs text-brand-muted">
                  {t.transaction_type === 'referral_bonus' ? '🤝 Referral bonus' : t.transaction_type === 'watch_reward' ? '📺 Watch reward' : t.transaction_type === 'payout_sent' ? '💸 Payout sent' : t.transaction_type}
                </span>
                <span className={`font-bold ${Number(t.amount) >= 0 ? 'text-ok' : 'text-bad'}`}>
                  {Number(t.amount) >= 0 ? '+' : ''}₹{Number(t.amount).toFixed(2)}
                </span>
                <span className="text-xs text-brand-muted">{formatDateTime(t.created_at)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {showEarn && (
        <EarnAds open={showEarn} onClose={() => { setShowEarn(false); load(); }} onWalletChange={setWallet} />
      )}
    </div>
  );
}
