import React from 'react';
import { Link } from 'react-router-dom';
import { PLAN_LIST } from '../constants/plans';
import { CONTACT } from '../constants/config';
import { useAuth } from '../hooks/useAuth';

const FEATURES = [
  {
    icon: '⚡',
    title: 'Instant Deployment',
    text: 'Paste your bot token, write main.py, hit Deploy. Your Telegram bot is live in seconds — no servers to configure.',
  },
  {
    icon: '🖥️',
    title: 'Built-in Code Editor',
    text: 'A full Monaco editor for main.py and requirements.txt. Dependencies are installed automatically on every start.',
  },
  {
    icon: '📜',
    title: 'Live Logs',
    text: 'Watch stdout/stderr stream in real time over WebSockets. Debug your bot without leaving the browser.',
  },
  {
    icon: '📁',
    title: 'File Manager',
    text: 'Upload, download and manage main.py and requirements.txt with per-plan storage from 250 MB up to 3 GB.',
  },
  {
    icon: '🤝',
    title: 'Earn Real Money',
    text: 'Referral lands a 7-day login streak? You earn ₹3 instantly to your wallet. Plus watch rewarded video ads — every 5 ads pays ₹0.25. Withdraw via UPI.',
  },
  {
    icon: '💳',
    title: 'Simple UPI Payments',
    text: 'Upgrade with GPay, PhonePe or any UPI app. Scan the QR, pay, enter your UTR — your plan activates instantly.',
  },
];

const STEPS = [
  { n: '01', title: 'Sign in with Google', text: 'One click. No passwords, no credit card for the free plan.' },
  { n: '02', title: 'Create your bot', text: 'Add your Telegram bot token from @BotFather and write your Python code.' },
  { n: '03', title: 'Deploy & go live', text: 'Hit Start. We run your bot 24/7 (paid plans) with live logs and one-click restarts.' },
];

const FAQS = [
  {
    q: 'Is GodHosting really free?',
    a: 'Yes! The Free plan hosts 1 bot with 250 MB storage forever, supported by short 5-second ads. Free bots auto-stop after 24 hours and need 3 ads (15s) to restart. Upgrade any time to remove limits.',
  },
  {
    q: 'Why do I see ads? Can I block them?',
    a: 'Ads are what keep hosting free for everyone. Ad blockers are detected (6 methods!) and will block actions on Free, Silver and Gold plans. Want zero ads? Diamond (₹100/mo) is 100% ad-free — ad blockers are even allowed there.',
  },
  {
    q: 'Which files does my bot support?',
    a: 'Your bot runs from main.py, with dependencies declared in requirements.txt (auto-installed with pip). Your bot token is injected as the BOT_TOKEN environment variable.',
  },
  {
    q: 'How do payments work?',
    a: 'We accept UPI only (godhostings@upi). Pick a plan, pay with GPay/PhonePe/any UPI app using the QR or deep link, then submit your UPI transaction ID (UTR) to activate instantly.',
  },
  {
    q: 'How do referrals and earning work?',
    a: 'Share your unique link. When your referred user logs in 7 consecutive days, ₹3 is credited to your wallet automatically (a 48h absence fails the streak). You can also watch 5 rewarded video ads to earn ₹0.25 — credited only after server verification. Withdraw any time via UPI.',
  },
];

function PlanTable() {
  const rows = [
    { label: 'Price', get: (p) => (p.price === 0 ? '₹0 forever' : `₹${p.price}/mo`) },
    { label: 'Max bots', get: (p) => p.maxBotsLabel },
    { label: 'Storage', get: (p) => p.storageLabel },
    { label: '24h auto-stop', get: (p) => (p.autoStopHours ? '✅ Yes' : '❌ No') },
    { label: '5-second ads', get: (p) => (p.ads ? '✅ Yes' : '❌ None — ad-free') },
    { label: 'Ad blocker', get: (p) => (p.adblockerAllowed ? '✅ Allowed' : '🚫 Blocked') },
    { label: 'Ads to restart', get: (p) => (p.restartAds === 0 ? '0 (instant)' : `${p.restartAds} ad${p.restartAds > 1 ? 's' : ''}`) },
    { label: '24/7 support', get: (p) => (p.support247 ? '✅ Yes' : '❌ No') },
    { label: 'Referral earnings', get: () => '₹1/mo per user' },
  ];
  return (
    <div className="overflow-x-auto -mx-4 px-4">
      <table className="w-full min-w-[720px] text-sm">
        <thead>
          <tr>
            <th className="text-left py-3 px-3 text-brand-muted font-semibold">Feature</th>
            {PLAN_LIST.map((p) => (
              <th key={p.id} className="py-3 px-3 text-center">
                <span className="font-black text-base" style={{ color: p.color }}>
                  {p.name}
                </span>
                {p.popular && (
                  <span className="block text-[10px] text-brand-gold uppercase tracking-wide">Most popular</span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={row.label} className={i % 2 ? 'bg-brand-card/60' : ''}>
              <td className="py-3 px-3 font-semibold text-white/90">{row.label}</td>
              {PLAN_LIST.map((p) => (
                <td key={p.id} className="py-3 px-3 text-center text-brand-muted">
                  {row.get(p)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Landing() {
  const { user } = useAuth();

  return (
    <div>
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden bg-hero-glow">
        <div className="container-gh py-20 sm:py-28 text-center">
          <span className="badge bg-brand-gold/15 text-brand-gold mb-6 inline-flex">
            ⚡ The Ultimate Telegram Bot Hosting Platform
          </span>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black leading-tight gh-slide-up">
            Deploy Telegram Bots
            <br />
            <span className="gold-text">Instantly. For Free.</span>
          </h1>
          <p className="max-w-2xl mx-auto mt-6 text-brand-muted text-lg leading-relaxed">
            Write Python, paste your bot token, hit deploy. GodHosting runs your bot with live logs,
            a built-in editor, file management and plans from{' '}
            <span className="text-white font-bold">₹0 to ₹150/month</span>. Where bots come to life.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={user ? '/dashboard' : '/login'} className="btn-gold text-lg !px-10 gh-pulse-gold">
              {user ? 'Go to Dashboard →' : 'Start Hosting Free →'}
            </Link>
            <Link to="/plans" className="btn-ghost text-lg !px-10">
              View Plans
            </Link>
          </div>
          <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              ['₹0', 'Free plan, forever'],
              ['5s', 'Quick ad breaks'],
              ['24/7', 'Uptime on paid plans'],
              ['₹3', 'Per 7-day referral streak'],
            ].map(([v, l]) => (
              <div key={l} className="card p-4">
                <div className="text-2xl font-black gold-text">{v}</div>
                <div className="text-xs text-brand-muted mt-1">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= FEATURES ================= */}
      <section className="container-gh py-20">
        <h2 className="section-title">
          Everything your bot needs, <span className="gold-text">nothing it doesn't</span>
        </h2>
        <p className="text-center text-brand-muted mt-4 max-w-xl mx-auto">
          A complete hosting platform built for Telegram bot developers.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {FEATURES.map((f) => (
            <div key={f.title} className="card p-6 hover:border-brand-gold/60 transition-colors">
              <div className="text-4xl mb-4" aria-hidden="true">{f.icon}</div>
              <h3 className="font-bold text-lg mb-2">{f.title}</h3>
              <p className="text-brand-muted text-sm leading-relaxed">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ================= HOW IT WORKS ================= */}
      <section className="bg-brand-card/50 border-y border-brand-line">
        <div className="container-gh py-20">
          <h2 className="section-title">
            Live in <span className="gold-text">3 steps</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {STEPS.map((s) => (
              <div key={s.n} className="text-center">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gold-gradient text-black font-black text-xl flex items-center justify-center shadow-gold">
                  {s.n}
                </div>
                <h3 className="font-bold text-lg mt-5">{s.title}</h3>
                <p className="text-brand-muted text-sm mt-2 leading-relaxed">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= PLAN COMPARISON ================= */}
      <section className="container-gh py-20" id="plans">
        <h2 className="section-title">
          Simple, honest <span className="gold-text">pricing</span>
        </h2>
        <p className="text-center text-brand-muted mt-4 max-w-xl mx-auto">
          Start free. Upgrade when you grow. Cancel anytime. All paid plans via UPI.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-12">
          {PLAN_LIST.map((p) => (
            <div
              key={p.id}
              className={`card p-5 flex flex-col ${p.popular ? 'border-brand-gold shadow-gold' : ''}`}
            >
              <div className="font-black text-lg" style={{ color: p.color }}>
                {p.name}
              </div>
              <div className="mt-2 text-3xl font-black">
                {p.price === 0 ? '₹0' : `₹${p.price}`}
                <span className="text-sm font-medium text-brand-muted">{p.price === 0 ? '' : '/mo'}</span>
              </div>
              <p className="text-xs text-brand-muted mt-1">{p.tagline}</p>
              <ul className="mt-4 space-y-2 text-xs text-brand-muted flex-1">
                {p.features &&
                  p.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2">
                      <span className="text-ok mt-0.5">✓</span>
                      <span>{feat}</span>
                    </li>
                  ))}
                {!p.features && (
                  <>
                    <li className="flex items-start gap-2"><span className="text-ok">✓</span>{p.maxBotsLabel}</li>
                    <li className="flex items-start gap-2"><span className="text-ok">✓</span>{p.storageLabel} storage</li>
                    <li className="flex items-start gap-2"><span className="text-ok">✓</span>{p.ads ? '5-second ads' : 'ZERO ads'}</li>
                  </>
                )}
              </ul>
              <Link
                to={p.price === 0 ? (user ? '/dashboard' : '/login') : `/pay/${p.id}`}
                className={`${p.popular ? 'btn-gold' : 'btn-ghost'} mt-5 !px-4 !py-2 text-sm w-full`}
              >
                {p.price === 0 ? 'Start Free' : `Get ${p.name}`}
              </Link>
            </div>
          ))}
        </div>

        <div className="card mt-10 p-6">
          <h3 className="font-bold text-lg mb-4">Full comparison</h3>
          <PlanTable />
        </div>
      </section>

      {/* ================= REFERRAL BANNER ================= */}
      <section className="container-gh pb-20">
        <div className="card p-8 sm:p-12 bg-gold-gradient !border-0 text-center relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl sm:text-4xl font-black text-black">
              Earn ₹1 every month, per friend 🤝
            </h2>
            <p className="text-black/80 mt-3 max-w-xl mx-auto font-medium">
              Share your referral link. Every active user who signs up earns you ₹1/month —
              automatically credited and claimable via UPI.
            </p>
            <Link
              to={user ? '/referrals' : '/login'}
              className="mt-6 inline-flex items-center justify-center px-8 py-3 rounded-lg bg-black text-white font-bold hover:bg-black/85 transition-colors"
            >
              {user ? 'Get your referral link →' : 'Sign in to start earning →'}
            </Link>
          </div>
        </div>
      </section>

      {/* ================= FAQ ================= */}
      <section className="container-gh pb-20 max-w-3xl">
        <h2 className="section-title">
          Frequently asked <span className="gold-text">questions</span>
        </h2>
        <div className="mt-10 space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="card p-5 group">
              <summary className="font-bold cursor-pointer list-none flex items-center justify-between gap-4">
                {f.q}
                <span className="text-brand-gold group-open:rotate-45 transition-transform text-xl">+</span>
              </summary>
              <p className="text-brand-muted text-sm leading-relaxed mt-3">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* ================= FINAL CTA ================= */}
      <section className="border-t border-brand-line bg-brand-card/50">
        <div className="container-gh py-16 text-center">
          <h2 className="text-3xl sm:text-4xl font-black">
            Ready to bring your bot <span className="gold-text">to life?</span>
          </h2>
          <p className="text-brand-muted mt-3">
            Join GodHosting today. Free forever plan. No credit card.
          </p>
          <Link to={user ? '/dashboard' : '/login'} className="btn-gold mt-8 text-lg !px-10">
            Deploy your first bot →
          </Link>
          <p className="text-xs text-brand-muted mt-8">
            Questions? Email{' '}
            <a className="text-brand-gold hover:underline" href={`mailto:${CONTACT.email}`}>
              {CONTACT.email}
            </a>{' '}
            or message{' '}
            <a className="text-brand-gold hover:underline" href={CONTACT.telegram} target="_blank" rel="noopener noreferrer">
              {CONTACT.telegramHandle}
            </a>{' '}
            on Telegram • {CONTACT.domain}
          </p>
        </div>
      </section>
    </div>
  );
}
