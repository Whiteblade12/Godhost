import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PLAN_LIST } from '../constants/plans';
import { paymentsApi } from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import { formatINR } from '../utils/formatters';
import { CONTACT } from '../constants/config';

const COMPARISON_ROWS = [
  { label: 'Monthly price', get: (p) => (p.price === 0 ? 'FREE' : formatINR(p.price)) },
  { label: 'Max bots', get: (p) => p.maxBotsLabel },
  { label: 'Storage', get: (p) => p.storageLabel },
  { label: 'Files supported', get: () => 'main.py + requirements.txt' },
  { label: 'Bot auto-stops after 24h', get: (p) => (p.autoStopHours ? '✅ Yes' : '❌ No') },
  { label: '5-second ads on actions', get: (p) => (p.ads ? '✅ Yes' : '❌ No ads ever') },
  { label: 'Website open ad', get: (p) => (p.websiteOpenAd ? '✅ Yes (Free only)' : '❌ No') },
  { label: 'Ads to restart', get: (p) => (p.restartAds === 0 ? '0 — instant' : `${p.restartAds} × 5s`) },
  { label: 'Ad blocker', get: (p) => (p.adblockerAllowed ? '✅ Allowed' : '🚫 Blocked') },
  { label: '24/7 priority support', get: (p) => (p.support247 ? '✅ Yes' : '❌ No') },
  { label: 'Referral earnings', get: () => '₹1 / month / active user' },
];

/** Subscription plan cards + full comparison table. */
export default function Plans() {
  const { user } = useAuth();
  const [serverPlans, setServerPlans] = useState(null);

  useEffect(() => {
    paymentsApi
      .plans()
      .then((res) => setServerPlans(res.data.plans))
      .catch(() => {});
  }, []);

  const plans = serverPlans && serverPlans.length ? serverPlans : PLAN_LIST;

  return (
    <div className="container-gh py-14">
      <div className="text-center max-w-2xl mx-auto">
        <h1 className="text-4xl sm:text-5xl font-black">
          Pick your <span className="gold-text">power level</span>
        </h1>
        <p className="text-brand-muted mt-4">
          Every plan includes the code editor, live logs, file manager and the ₹1/mo referral program.
          Pay easily with UPI — GPay, PhonePe, Paytm & more.
        </p>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-12">
        {plans.map((p) => {
          const isCurrent = user && user.planType === p.id;
          return (
            <div
              key={p.id}
              className={`card p-5 flex flex-col relative ${p.popular ? 'border-brand-gold shadow-gold' : ''}`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 badge bg-gold-gradient text-black">
                  ⭐ Most popular
                </span>
              )}
              <div className="font-black text-lg" style={{ color: p.color }}>{p.name}</div>
              <p className="text-xs text-brand-muted">{p.tagline}</p>
              <div className="mt-3 text-3xl font-black">
                {p.price === 0 ? '₹0' : `₹${p.price}`}
                {p.price > 0 && <span className="text-sm text-brand-muted font-medium">/mo</span>}
              </div>
              <ul className="mt-4 space-y-2 text-xs text-brand-muted flex-1">
                <li className="flex gap-2"><span className="text-ok">✓</span>{p.maxBotsLabel}</li>
                <li className="flex gap-2"><span className="text-ok">✓</span>{p.storageLabel} storage</li>
                <li className="flex gap-2">
                  <span className={p.ads ? 'text-warn' : 'text-ok'}>{p.ads ? '•' : '✓'}</span>
                  {p.ads ? `5s ads • ${p.restartAds} ad(s) to restart` : 'ZERO ads • ad blocker OK'}
                </li>
                <li className="flex gap-2"><span className={p.autoStopHours ? 'text-warn' : 'text-ok'}>{p.autoStopHours ? '•' : '✓'}</span>
                  {p.autoStopHours ? '24h auto-stop' : 'Always-on 24/7'}
                </li>
                <li className="flex gap-2"><span className={p.support247 ? 'text-ok' : 'text-brand-muted'}>{p.support247 ? '✓' : '•'}</span>
                  {p.support247 ? '24/7 support' : 'Community support'}
                </li>
                <li className="flex gap-2"><span className="text-ok">✓</span>Earn ₹1/mo per referral</li>
              </ul>
              {isCurrent ? (
                <span className="mt-5 w-full text-center px-4 py-2 rounded-lg bg-ok/15 text-ok font-bold text-sm">
                  ✓ Current plan
                </span>
              ) : p.price === 0 ? (
                <Link to={user ? '/dashboard' : '/login'} className="btn-ghost mt-5 !px-4 !py-2 text-sm w-full">
                  Start Free
                </Link>
              ) : (
                <Link
                  to={user ? `/pay/${p.id}` : `/login?next=/pay/${p.id}`}
                  className={`${p.popular ? 'btn-gold' : 'btn-ghost'} mt-5 !px-4 !py-2 text-sm w-full`}
                >
                  Get {p.name} →
                </Link>
              )}
            </div>
          );
        })}
      </div>

      {/* Comparison table */}
      <div className="card mt-12 p-6 overflow-x-auto">
        <h2 className="font-bold text-lg mb-4">Detailed comparison</h2>
        <table className="w-full min-w-[760px] text-sm">
          <thead>
            <tr>
              <th className="text-left py-3 px-3 text-brand-muted font-semibold">Feature</th>
              {plans.map((p) => (
                <th key={p.id} className="py-3 px-3 text-center font-black" style={{ color: p.color }}>
                  {p.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {COMPARISON_ROWS.map((row, i) => (
              <tr key={row.label} className={i % 2 ? 'bg-brand-card/60' : ''}>
                <td className="py-3 px-3 font-semibold text-white/90">{row.label}</td>
                {plans.map((p) => (
                  <td key={p.id} className="py-3 px-3 text-center text-brand-muted">{row.get(p)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-center text-brand-muted text-sm mt-8">
        All prices in INR, billed monthly via UPI ({CONTACT.upiId}). Questions?{' '}
        <a href={CONTACT.telegram} target="_blank" rel="noopener noreferrer" className="text-brand-gold hover:underline">
          {CONTACT.telegramHandle}
        </a>
      </p>
    </div>
  );
}
