import React from 'react';

/** Gold branded spinner. */
export default function LoadingSpinner({ size = 40, label = 'Loading...' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10" role="status" aria-live="polite">
      <div
        className="rounded-full border-4 border-brand-line border-t-brand-gold animate-spin"
        style={{ width: size, height: size }}
      />
      <span className="text-brand-muted text-sm">{label}</span>
    </div>
  );
}
