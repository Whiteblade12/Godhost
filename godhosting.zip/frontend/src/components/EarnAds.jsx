import React, { useCallback, useEffect, useRef, useState } from 'react';
import { adsApi, usersApi } from '../utils/api';
import { errorMessage } from '../utils/validators';
import { CONTACT } from '../constants/config';

/**
 * Watch-to-Win rewarded video ads.
 * Watch 5 x 15-second ads -> ₹0.25 credited to wallet (server-verified;
 * the counter only increments after full verified playback or the ad
 * network's S2S webhook — never on unverified clicks).
 */
export default function EarnAds({ open, onClose, onWalletChange }) {
  const [phase, setPhase] = useState('idle'); // idle | playing | done
  const [current, setCurrent] = useState(1);
  const [remaining, setRemaining] = useState(15);
  const [result, setResult] = useState(null);
  const [wallet, setWallet] = useState(null);
  const [error, setError] = useState(null);
  const timerRef = useRef(null);
  const cancelledRef = useRef(false);
  const TOTAL = 5;

  const cleanup = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  }, []);

  const refreshWallet = useCallback(() => {
    usersApi
      .wallet()
      .then((res) => {
        setWallet(res.data);
        if (onWalletChange) onWalletChange(res.data);
      })
      .catch(() => {});
  }, [onWalletChange]);

  const playOne = useCallback(
    (index) => {
      setPhase('playing');
      setError(null);
      adsApi
        .rewardWatch()
        .then((res) => {
          if (cancelledRef.current) return;
          const { adWatchId, duration } = res.data;
          const startedAt = Date.now();
          setRemaining(duration);
          timerRef.current = setInterval(() => {
            const elapsed = (Date.now() - startedAt) / 1000;
            const left = Math.max(0, duration - elapsed);
            setRemaining(left);
            if (left <= 0) {
              cleanup();
              adsApi
                .rewardComplete(adWatchId)
                .then((cres) => {
                  if (cancelledRef.current) return;
                  setResult(cres.data);
                  setWallet((w) =>
                    w ? { ...w, balance: cres.data.walletBalance, pendingAdClicks: cres.data.pendingAdClicks } : w
                  );
                  if (index < TOTAL) {
                    setCurrent(index + 1);
                    setTimeout(() => playOne(index + 1), 500);
                  } else {
                    setPhase('done');
                    refreshWallet();
                  }
                })
                .catch((err) => {
                  if (cancelledRef.current) return;
                  setError(errorMessage(err, 'Ad verification failed.'));
                  setPhase('idle');
                });
            }
          }, 100);
        })
        .catch((err) => {
          if (cancelledRef.current) return;
          setError(errorMessage(err, 'Could not load rewarded ad.'));
          setPhase('idle');
        });
    },
    [cleanup, refreshWallet]
  );

  useEffect(() => {
    if (open) {
      cancelledRef.current = false;
      setCurrent(1);
      setPhase('idle');
      setResult(null);
      setError(null);
      refreshWallet();
      const t = setTimeout(() => playOne(1), 400);
      return () => {
        clearTimeout(t);
        cleanup();
      };
    }
    return undefined;
  }, [open, playOne, cleanup, refreshWallet]);

  const close = () => {
    cancelledRef.current = true;
    cleanup();
    onClose && onClose();
  };

  if (!open) return null;

  const progress = phase === 'playing' ? ((15 - remaining) / 15) * 100 : 0;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm gh-fade-in">
      <div className="card w-full max-w-md p-6 sm:p-8 text-center">
        <div className="flex items-center justify-between mb-2">
          <span className="badge bg-ok/15 text-ok">💰 Rewarded Ad</span>
          <span className="text-sm text-brand-muted font-semibold">
            Ad {Math.min(current, TOTAL)} of {TOTAL}
          </span>
        </div>

        {/* Progress dots for the 5-ad cycle */}
        <div className="flex justify-center gap-2 my-4" aria-hidden="true">
          {Array.from({ length: TOTAL }).map((_, i) => (
            <span
              key={i}
              className={`w-3 h-3 rounded-full ${
                i < current - 1 || (phase === 'done' && i < TOTAL)
                  ? 'bg-ok'
                  : i === current - 1 && phase === 'playing'
                  ? 'bg-brand-gold animate-pulse'
                  : 'bg-brand-deep'
              }`}
            />
          ))}
        </div>

        {phase === 'playing' && (
          <>
            <div className="rounded-xl border border-dashed border-brand-line bg-brand-deep/40 flex flex-col items-center justify-center py-12 mb-5">
              <div className="text-5xl mb-3">🎬</div>
              <p className="font-bold">Rewarded video ad</p>
              <p className="text-brand-muted text-xs mt-1">Watch all 5 to earn ₹0.25</p>
            </div>
            <p className="text-sm text-brand-muted mb-3">⏳ {Math.ceil(remaining)}s remaining...</p>
            <div className="h-3 rounded-full bg-brand-deep overflow-hidden">
              <div className="h-full bg-gold-gradient transition-[width] duration-100" style={{ width: `${progress}%` }} />
            </div>
          </>
        )}

        {phase === 'done' && (
          <div className="py-6">
            <div className="text-5xl mb-3">🎉</div>
            <p className="font-black text-xl gold-text">Cycle complete!</p>
            {result && result.credited !== undefined && (
              <p className="text-brand-muted text-sm mt-2">
                {result.paidOut ? `₹${result.paidOut} added to your wallet!` : `Progress: ${result.progress} to next ₹0.25`}
              </p>
            )}
            {wallet && (
              <p className="mt-3 text-sm">
                Wallet balance: <strong className="gold-text">₹{Number(wallet.balance).toFixed(2)}</strong>
              </p>
            )}
            <button className="btn-gold mt-6" onClick={close}>Done</button>
          </div>
        )}

        {phase === 'idle' && (
          <div className="py-6">
            {error ? (
              <>
                <p className="text-bad text-sm mb-4">{error}</p>
                <button className="btn-gold !py-2" onClick={() => playOne(current)}>Retry</button>
              </>
            ) : (
              <p className="text-brand-muted text-sm">Loading rewarded ad...</p>
            )}
          </div>
        )}

        {phase !== 'done' && (
          <p className="text-[11px] text-brand-muted/70 mt-6">
            Credits are verified server-side — no forced clicks, ever. Payouts via UPI ({CONTACT.upiId}).
          </p>
        )}
      </div>
    </div>
  );
}
