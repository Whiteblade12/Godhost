import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { io } from 'socket.io-client';
import { useAuth } from '../hooks/useAuth';
import { usePlan } from '../hooks/usePlan';
import { botsApi } from '../utils/api';
import { SOCKET_URL, TOKEN_KEY, API_URL } from '../constants/config';
import { errorMessage, isValidBotName, isValidBotToken } from '../utils/validators';
import { formatUptime } from '../utils/formatters';
import AdModal from './AdModal';
import FileManager from './FileManager';
import LoadingSpinner from './LoadingSpinner';

const DEFAULT_CODE = `# GodHosting - main.py
# Your bot token is available as the BOT_TOKEN environment variable.
import os

TOKEN = os.environ.get("BOT_TOKEN", "")

print("Bot starting...")
`;

export default function BotEditor() {
  const { id } = useParams();
  const { token } = useAuth();
  const { adsForAction } = usePlan();

  const [bot, setBot] = useState(null);
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('main.py'); // main.py | requirements.txt
  const [code, setCode] = useState('');
  const [reqContent, setReqContent] = useState('');
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState('stopped');
  const [uptime, setUptime] = useState(0);
  const [logs, setLogs] = useState([]);
  const [notice, setNotice] = useState(null);
  const [ad, setAd] = useState(null);
  const [busyAction, setBusyAction] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [scrollUnlocked, setScrollUnlocked] = useState(false);
  const [settingsForm, setSettingsForm] = useState({ name: '', botToken: '' });

  const socketRef = useRef(null);
  const logBoxRef = useRef(null);
  const autoScrollRef = useRef(true);

  /* ---------------- Load bot ---------------- */
  const loadBot = useCallback(async () => {
    try {
      const res = await botsApi.get(id);
      const b = res.data.bot;
      setBot(b);
      setFiles(res.data.files || []);
      setStatus(b.running ? 'running' : 'stopped');
      setUptime(b.uptimeSeconds || 0);
      setSettingsForm({ name: b.name, botToken: '' });
      // Load file contents
      setCode(b.code || DEFAULT_CODE);
      try {
        const reqRes = await botsApi.files(id);
        const hasReq = (reqRes.data.files || []).some((f) => f.name === 'requirements.txt');
        if (hasReq) {
          const resp = await fetch(`${API_URL}/api/bots/${id}/files/requirements.txt`, {
            headers: { Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}` },
          });
          if (resp.ok) setReqContent(await resp.text());
        }
      } catch {
        /* requirements.txt optional */
      }
    } catch (err) {
      setNotice(errorMessage(err, 'Could not load bot.'));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadBot();
  }, [loadBot]);

  /* ---------------- Live logs socket ---------------- */
  useEffect(() => {
    if (!token) return undefined;
    const socket = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;
    socket.on('connect', () => socket.emit('join', Number(id)));
    socket.on('log', (entry) => {
      if (entry.botId !== Number(id)) return;
      setLogs((prev) => {
        const next = [...prev, entry];
        return next.length > 500 ? next.slice(-500) : next;
      });
    });
    socket.on('status', (s) => {
      if (s.botId !== Number(id)) return;
      setStatus(s.status);
    });
    return () => {
      socket.emit('leave', Number(id));
      socket.disconnect();
      socketRef.current = null;
    };
  }, [id, token]);

  /* ---------------- Load historical logs ---------------- */
  useEffect(() => {
    botsApi
      .logs(id, 200)
      .then((res) => setLogs(res.data.logs || []))
      .catch(() => {});
  }, [id]);

  /* ---------------- Auto-scroll logs ---------------- */
  useEffect(() => {
    if (autoScrollRef.current && logBoxRef.current) {
      logBoxRef.current.scrollTop = logBoxRef.current.scrollHeight;
    }
  }, [logs]);

  /* ---------------- Ad gating helper ---------------- */
  const withAds = (action, fn) => {
    const need = adsForAction(action);
    if (need.required) {
      setAd({ action, count: need.count, duration: need.duration, fn });
    } else {
      fn([]);
    }
  };

  const onAdsComplete = async (adWatchIds) => {
    const pending = ad;
    setAd(null);
    if (pending && pending.fn) {
      try {
        await pending.fn(adWatchIds);
      } catch (err) {
        setNotice(errorMessage(err));
      }
    }
  };

  /* ---------------- Actions ---------------- */
  const saveCode = async () => {
    setSaving(true);
    setNotice(null);
    try {
      const filename = tab === 'requirements.txt' ? 'requirements.txt' : 'main.py';
      const content = tab === 'requirements.txt' ? reqContent : code;
      await botsApi.saveCode(id, content, filename);
      setDirty(false);
      setNotice(`💾 ${filename} saved.`);
      if (filename === 'main.py') loadBot();
    } catch (err) {
      setNotice(errorMessage(err, 'Save failed.'));
    } finally {
      setSaving(false);
    }
  };

  const doStart = () =>
    withAds('start', async (adIds) => {
      setBusyAction('start');
      try {
        await botsApi.start(id, adIds);
        setStatus('running');
        setNotice('▶ Bot starting...');
      } finally {
        setBusyAction(null);
      }
    });

  const doStop = async () => {
    setBusyAction('stop');
    try {
      await botsApi.stop(id);
      setStatus('stopped');
      setNotice('⏹ Bot stopped.');
    } catch (err) {
      setNotice(errorMessage(err));
    } finally {
      setBusyAction(null);
    }
  };

  const doRestart = () =>
    withAds('restart', async (adIds) => {
      setBusyAction('restart');
      try {
        await botsApi.restart(id, adIds);
        setStatus('running');
        setNotice('🔄 Bot restarting...');
      } finally {
        setBusyAction(null);
      }
    });

  /** Deploy = save + start, with the deploy ad gate. */
  const doDeploy = () =>
    withAds('deploy', async (adIds) => {
      setBusyAction('deploy');
      try {
        await botsApi.saveCode(id, code, 'main.py');
        if (reqContent.trim()) await botsApi.saveCode(id, reqContent, 'requirements.txt');
        setDirty(false);
        await botsApi.start(id, adIds);
        setStatus('running');
        setNotice('🚀 Deployed! Your bot is starting...');
      } finally {
        setBusyAction(null);
      }
    });

  const saveSettings = async (e) => {
    e.preventDefault();
    if (!isValidBotName(settingsForm.name)) {
      setNotice('Bot name must be 2-60 characters.');
      return;
    }
    const payload = { name: settingsForm.name.trim() };
    if (settingsForm.botToken) {
      if (!isValidBotToken(settingsForm.botToken)) {
        setNotice('Invalid bot token format.');
        return;
      }
      payload.botToken = settingsForm.botToken.trim();
    }
    try {
      await botsApi.update(id, payload);
      setShowSettings(false);
      setNotice('⚙️ Settings saved.');
      loadBot();
    } catch (err) {
      setNotice(errorMessage(err));
    }
  };

  /* ---------------- Log scroll ad gate ---------------- */
  const handleLogWheel = (e) => {
    const need = adsForAction('scroll_logs');
    if (!need.required || scrollUnlocked) {
      autoScrollRef.current = false;
      return;
    }
    e.preventDefault();
    setAd({
      action: 'scroll_logs',
      count: need.count,
      duration: need.duration,
      fn: async () => {
        setScrollUnlocked(true);
        autoScrollRef.current = false;
        setNotice('📜 Log scrolling unlocked for this session.');
      },
    });
  };

  const running = status === 'running';

  if (loading) return <LoadingSpinner label="Loading bot..." />;
  if (!bot) {
    return (
      <div className="container-gh py-20 text-center">
        <p className="text-brand-muted">Bot not found.</p>
        <Link to="/dashboard" className="btn-gold mt-4">← Back to dashboard</Link>
      </div>
    );
  }

  return (
    <div className="container-gh py-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
        <div>
          <Link to="/dashboard" className="text-brand-muted text-sm hover:text-brand-gold">← Dashboard</Link>
          <h1 className="text-2xl sm:text-3xl font-black mt-1 flex items-center gap-3 flex-wrap">
            {bot.name}
            <span className={`badge ${running ? 'bg-ok/15 text-ok' : 'bg-brand-muted/15 text-brand-muted'}`}>
              <span className={`w-2 h-2 rounded-full ${running ? 'bg-ok animate-pulse' : 'bg-brand-muted'}`} />
              {running ? `Running ${uptime ? `• ${formatUptime(uptime)}` : ''}` : 'Stopped'}
            </span>
          </h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn-gold !py-2" onClick={doDeploy} disabled={!!busyAction}>
            {busyAction === 'deploy' ? 'Deploying...' : '🚀 Deploy'}
          </button>
          {!running ? (
            <button className="btn-ghost !py-2" onClick={doStart} disabled={!!busyAction}>
              {busyAction === 'start' ? 'Starting...' : '▶ Start'}
            </button>
          ) : (
            <button className="btn-ghost !py-2" onClick={doStop} disabled={!!busyAction}>
              ⏹ Stop
            </button>
          )}
          <button className="btn-ghost !py-2" onClick={doRestart} disabled={!!busyAction || !running}>
            🔄 Restart
          </button>
          <button className="btn-ghost !py-2" onClick={() => setShowSettings(true)}>
            ⚙️
          </button>
        </div>
      </div>

      {notice && (
        <div className="mb-4 p-3 rounded-lg bg-brand-deep/60 border border-brand-line text-sm gh-fade-in">
          {notice}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* ------- Code editor ------- */}
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-brand-line px-4 py-2">
            <div className="flex gap-1">
              {['main.py', 'requirements.txt'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-4 py-2 rounded-t-lg text-sm font-mono font-semibold transition-colors ${
                    tab === t ? 'bg-brand-dark text-brand-gold' : 'text-brand-muted hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
            <button className="btn-gold !px-4 !py-1.5 text-sm" onClick={saveCode} disabled={saving}>
              {saving ? 'Saving...' : dirty ? '💾 Save*' : '💾 Save'}
            </button>
          </div>
          {tab === 'main.py' ? (
            <Editor
              height="440px"
              theme="vs-dark"
              language="python"
              value={code}
              onChange={(v) => {
                setCode(v || '');
                setDirty(true);
              }}
              options={{
                fontSize: 13,
                fontFamily: '"JetBrains Mono", "Fira Code", monospace',
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                automaticLayout: true,
                wordWrap: 'on',
              }}
            />
          ) : (
            <Editor
              height="440px"
              theme="vs-dark"
              language="plaintext"
              value={reqContent}
              onChange={(v) => {
                setReqContent(v || '');
                setDirty(true);
              }}
              options={{
                fontSize: 13,
                fontFamily: '"JetBrains Mono", monospace',
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                automaticLayout: true,
                wordWrap: 'on',
              }}
            />
          )}
          <div className="px-4 py-2 text-xs text-brand-muted border-t border-brand-line">
            {tab === 'requirements.txt'
              ? 'One package per line, e.g. python-telegram-bot==21.3 — installed automatically on start.'
              : 'Your bot token is injected as the BOT_TOKEN environment variable.'}
          </div>
        </div>

        {/* ------- Live logs ------- */}
        <div className="card overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-brand-line px-4 py-3">
            <h3 className="font-bold text-sm flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${running ? 'bg-ok animate-pulse' : 'bg-brand-muted'}`} />
              Live Logs
            </h3>
            <div className="flex gap-2">
              <button
                className="text-xs text-brand-muted hover:text-brand-gold font-semibold"
                onClick={() => {
                  autoScrollRef.current = true;
                  if (logBoxRef.current) logBoxRef.current.scrollTop = logBoxRef.current.scrollHeight;
                }}
              >
                ↓ Follow
              </button>
              <button className="text-xs text-brand-muted hover:text-brand-gold font-semibold" onClick={() => setLogs([])}>
                Clear
              </button>
            </div>
          </div>
          <div
            ref={logBoxRef}
            onWheel={handleLogWheel}
            onTouchMove={handleLogWheel}
            className="flex-1 bg-[#0d1220] font-mono text-xs p-4 overflow-y-auto"
            style={{ height: 440 }}
            aria-label="Bot logs"
          >
            {logs.length === 0 ? (
              <p className="text-brand-muted/60">
                No logs yet. {running ? 'Waiting for output...' : 'Start your bot to see live logs.'}
              </p>
            ) : (
              logs.map((l, i) => (
                <div key={i} className="whitespace-pre-wrap break-words leading-5">
                  <span className="text-brand-muted/50">{(l.t || '').slice(11, 19)} </span>
                  <span
                    className={
                      l.stream === 'stderr'
                        ? 'text-bad'
                        : l.stream === 'system'
                        ? 'text-brand-gold'
                        : 'text-ok/90'
                    }
                  >
                    {l.line}
                  </span>
                </div>
              ))
            )}
          </div>
          <div className="px-4 py-2 text-[11px] text-brand-muted border-t border-brand-line">
            Streaming via WebSocket {scrollUnlocked ? '• scrolling unlocked' : ''}
          </div>
        </div>
      </div>

      {/* ------- File manager ------- */}
      <div className="mt-6">
        <FileManager botId={id} adsForAction={adsForAction} onRequireAd={(cfg) => setAd(cfg)} onChanged={loadBot} files={files} />
      </div>

      {/* ------- Settings modal ------- */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 gh-fade-in">
          <form className="card w-full max-w-md p-6 sm:p-8" onSubmit={saveSettings}>
            <h2 className="text-xl font-black mb-6">Bot settings</h2>
            <label className="block text-sm font-semibold mb-2" htmlFor="set-name">Bot name</label>
            <input
              id="set-name"
              className="input-gh mb-4"
              value={settingsForm.name}
              onChange={(e) => setSettingsForm((f) => ({ ...f, name: e.target.value }))}
            />
            <label className="block text-sm font-semibold mb-2" htmlFor="set-token">
              New bot token <span className="text-brand-muted font-normal">(leave blank to keep current)</span>
            </label>
            <input
              id="set-token"
              className="input-gh font-mono text-sm mb-6"
              placeholder="123456789:AAH..."
              value={settingsForm.botToken}
              onChange={(e) => setSettingsForm((f) => ({ ...f, botToken: e.target.value }))}
            />
            <div className="flex gap-3">
              <button type="submit" className="btn-gold flex-1">Save settings</button>
              <button type="button" className="btn-ghost" onClick={() => setShowSettings(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* ------- Ad modal ------- */}
      {ad && (
        <AdModal
          open={!!ad}
          action={ad.action}
          botId={Number(id)}
          count={ad.count}
          duration={ad.duration}
          onComplete={onAdsComplete}
          onClose={() => setAd(null)}
        />
      )}
    </div>
  );
}
