import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from './Navbar';
import { CONTACT } from '../constants/config';
import { PLAN_LIST } from '../constants/plans';

export default function Footer() {
  return (
    <footer className="border-t border-brand-line bg-brand-card mt-16">
      <div className="container-gh py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <Logo />
          <p className="text-brand-muted text-sm mt-4 leading-relaxed">
            The ultimate Telegram bot hosting platform. Deploy Python bots instantly — for free.
            Where bots come to life. ⚡
          </p>
        </div>

        <div>
          <h3 className="font-bold text-sm uppercase tracking-wider text-brand-muted mb-4">Plans</h3>
          <ul className="space-y-2 text-sm">
            {PLAN_LIST.map((p) => (
              <li key={p.id}>
                <Link to="/plans" className="text-white/80 hover:text-brand-gold transition-colors">
                  {p.name} — {p.price === 0 ? 'Free' : `₹${p.price}/mo`}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-bold text-sm uppercase tracking-wider text-brand-muted mb-4">Platform</h3>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="text-white/80 hover:text-brand-gold">Home</Link></li>
            <li><Link to="/dashboard" className="text-white/80 hover:text-brand-gold">Dashboard</Link></li>
            <li><Link to="/referrals" className="text-white/80 hover:text-brand-gold">Earn ₹1/mo per referral</Link></li>
            <li><Link to="/login" className="text-white/80 hover:text-brand-gold">Sign in</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-bold text-sm uppercase tracking-wider text-brand-muted mb-4">Contact</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <a href={`https://${CONTACT.domain}`} className="text-white/80 hover:text-brand-gold">
                {CONTACT.domain}
              </a>
            </li>
            <li>
              <a href={`mailto:${CONTACT.email}`} className="text-white/80 hover:text-brand-gold">
                {CONTACT.email}
              </a>
            </li>
            <li>
              <a
                href={CONTACT.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/80 hover:text-brand-gold"
              >
                Telegram: {CONTACT.telegramHandle}
              </a>
            </li>
            <li>
              <span className="text-white/80">UPI: {CONTACT.upiId}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-brand-line">
        <div className="container-gh py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-brand-muted">
          <span>© {new Date().getFullYear()} GodHosting • godhosting.online — All rights reserved.</span>
          <span>
            Support: <a className="hover:text-brand-gold" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>{' '}
            • <a className="hover:text-brand-gold" href={CONTACT.telegram} target="_blank" rel="noopener noreferrer">{CONTACT.telegramHandle}</a>
          </span>
        </div>
      </div>
    </footer>
  );
}
