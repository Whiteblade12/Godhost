import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { Logo } from './Navbar';
import { CONTACT } from '../constants/config';

/**
 * Hidden admin login — reachable only at godhosting.online/admin/auth/
 * (not linked anywhere in the UI). Requires the admin Gmail (ADMIN_EMAILS)
 * AND the password stored on the API server (scrypt hash in backend .env).
 */
export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  // Already logged in? Straight to the panel.
  useEffect(() => {
    api
      .get('/admin/auth/me')
      .then(() => navigate('/admin', { replace: true }))
      .catch(() => {});
  }, [navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post('/admin/auth/login', { email: email.trim(), password });
      navigate('/admin', { replace: true });
    } catch (err) {
      setError(
        err?.response?.data?.error || 'Login failed. Check your credentials and try again.'
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="card w-full max-w-md p-8 gh-slide-up">
        <div className="flex justify-center mb-6">
          <Logo size="lg" />
        </div>
        <h1 className="text-2xl font-black text-center">
          🛠️ Admin <span className="gold-text">Access</span>
        </h1>
        <p className="text-brand-muted text-center text-sm mt-2 mb-8">
          Restricted area. Authorized administrators only.
          <br />
          <span className="text-xs">godhosting.online/admin/auth/</span>
        </p>

        <form onSubmit={submit}>
          <label className="block text-sm font-semibold mb-2" htmlFor="admin-email">
            Admin email
          </label>
          <input
            id="admin-email"
            type="email"
            required
            autoComplete="username"
            className="input-gh mb-4"
            placeholder="godhostings@gmail.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <label className="block text-sm font-semibold mb-2" htmlFor="admin-pass">
            Password
          </label>
          <div className="relative mb-4">
            <input
              id="admin-pass"
              type={show ? 'text' : 'password'}
              required
              autoComplete="current-password"
              className="input-gh pr-16"
              placeholder="••••••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-brand-muted hover:text-brand-gold font-bold"
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              {show ? 'HIDE' : 'SHOW'}
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-bad/10 border border-bad/40 text-bad text-sm text-center">
              {error}
            </div>
          )}

          <button type="submit" disabled={busy} className="btn-gold w-full">
            {busy ? 'Verifying...' : '🔐 Unlock Admin Panel'}
          </button>
        </form>

        <div className="mt-6 p-4 rounded-lg bg-brand-deep/40 border border-brand-line text-[11px] text-brand-muted leading-relaxed">
          <strong className="text-white">Security:</strong> the password is stored only on the API
          server as a scrypt hash — it never exists in frontend code. 5 failed attempts lock this IP
          for 15 minutes. More than 200 requests in 10 minutes bans your IP for 3 hours (server +
          Cloudflare).
          <br />
          Locked out? Contact {CONTACT.email}
        </div>
      </div>
    </div>
  );
}
