import React, { useRef, useState } from 'react';
import { botsApi } from '../utils/api';
import { API_URL, TOKEN_KEY } from '../constants/config';
import { errorMessage } from '../utils/validators';
import { formatBytes } from '../utils/formatters';

const ALLOWED = ['main.py', 'requirements.txt'];

/**
 * Bot file manager: upload / download / delete for main.py and requirements.txt.
 * Opening the manager is gated by a 5s ad on ad-supported plans.
 */
export default function FileManager({ botId, adsForAction, onRequireAd, onChanged, files = [] }) {
  const [unlocked, setUnlocked] = useState(false);
  const [busy, setBusy] = useState(null);
  const [notice, setNotice] = useState(null);
  const inputRef = useRef(null);

  const need = adsForAction('file_manager');

  const ensureUnlocked = (fn) => {
    if (unlocked || !need.required) {
      fn();
      return;
    }
    onRequireAd({
      action: 'file_manager',
      count: need.count,
      duration: need.duration,
      fn: async () => {
        setUnlocked(true);
        setNotice('📁 File manager unlocked for this session.');
        fn();
      },
    });
  };

  const onUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (!ALLOWED.includes(file.name)) {
      setNotice(`Only ${ALLOWED.join(' and ')} files are supported.`);
      return;
    }
    ensureUnlocked(async () => {
      setBusy('upload');
      setNotice(null);
      try {
        await botsApi.upload(botId, file);
        setNotice(`⬆️ ${file.name} uploaded (${formatBytes(file.size)}).`);
        onChanged && onChanged();
      } catch (err) {
        setNotice(errorMessage(err, 'Upload failed.'));
      } finally {
        setBusy(null);
      }
    });
  };

  const onDelete = (filename) => {
    ensureUnlocked(async () => {
      setBusy(`del-${filename}`);
      setNotice(null);
      try {
        await botsApi.deleteFile(botId, filename);
        setNotice(`🗑️ ${filename} deleted.`);
        onChanged && onChanged();
      } catch (err) {
        setNotice(errorMessage(err, 'Delete failed.'));
      } finally {
        setBusy(null);
      }
    });
  };

  const downloadUrl = (name) => `${API_URL}/api/bots/${botId}/files/${name}`;

  return (
    <div className="card p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <h3 className="font-bold text-lg">📁 File Manager</h3>
        <input
          ref={inputRef}
          type="file"
          accept=".py,.txt"
          className="hidden"
          onChange={onUpload}
        />
        <button
          className="btn-ghost !px-4 !py-2 text-sm"
          onClick={() => ensureUnlocked(() => inputRef.current && inputRef.current.click())}
          disabled={busy === 'upload'}
        >
          {busy === 'upload' ? 'Uploading...' : '⬆ Upload main.py / requirements.txt'}
        </button>
      </div>

      {notice && <p className="text-sm text-brand-muted mb-3">{notice}</p>}

      {!unlocked && need.required && (
        <p className="text-xs text-warn mb-3">
          🔒 On your plan, opening the file manager plays one 5-second ad.
        </p>
      )}

      <ul className="divide-y divide-brand-line">
        {files.length === 0 && (
          <li className="py-4 text-brand-muted text-sm">No files yet — save your code or upload main.py.</li>
        )}
        {files.map((f) => (
          <li key={f.name} className="py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <span aria-hidden="true">{f.name.endsWith('.py') ? '🐍' : '📄'}</span>
              <span className="font-mono text-sm truncate">{f.name}</span>
              <span className="text-xs text-brand-muted shrink-0">{formatBytes(f.size)}</span>
            </div>
            <div className="flex gap-2 shrink-0">
              <a
                href={downloadUrl(f.name)}
                download={f.name}
                onClick={(e) => {
                  if (need.required && !unlocked) {
                    e.preventDefault();
                    ensureUnlocked(() => {
                      window.open(downloadUrl(f.name), '_blank');
                    });
                  }
                }}
                className="text-sm text-brand-gold font-semibold hover:underline"
                data-token-note="Auth header not sent on plain links; use the editor for private downloads"
              >
                Download
              </a>
              <button
                className="text-sm text-bad font-semibold hover:underline"
                onClick={() => onDelete(f.name)}
                disabled={busy === `del-${f.name}`}
              >
                {busy === `del-${f.name}` ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </li>
        ))}
      </ul>
      <p className="text-[11px] text-brand-muted mt-4">
        GodHosting bots support <strong>main.py</strong> and <strong>requirements.txt</strong> only.
        Downloads open via the secure file endpoint.
      </p>
    </div>
  );
}
