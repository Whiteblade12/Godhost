import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { usePlan } from '../hooks/usePlan';
import { useBots } from '../hooks/useBots';
import AdModal from './AdModal';
import LoadingSpinner from './LoadingSpinner';
import { errorMessage, isValidBotName, isValidBotToken } from '../utils/validators';
import { formatBytes, formatUptime, percentUsed, planBadgeStyle } from '../utils/formatters';

function CreateBotModal({ open, onClose, onCreated }) {
  const [name, setName] = useState('');
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  if (!open) return null;

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!isValidBotName(name)) return setError('Bot name must be 2-60 characters.');
    if (!isValidBotToken(token)) {
      return setError('Invalid bot token. Copy it from @BotFather (format: 123456789:AAH...)');
    }
    setBusy(true);
    try {
      const bot = await onCreated(name.trim(), token.trim());
      setName('');
      setToken('');
      onClose();
      return bot;
    } catch (err) {
      return setError(errorMessage(err, 'Could not create bot.'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm gh-fade-in">
      <div className="card w-full max-w-md p-6 sm:p-8">
        <h2 className="text-xl font-black mb-1">Create a new bot</h2>
        <p className="text-brand-muted text-sm mb-6">
          Get your bot token from{' '}
          <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" className="text-brand-gold underline">
            @BotFather
          </a>{' '}
          on Telegram.
        </p>
        <form onSubmit={submit}>
          <label className="block text-sm font-semibold mb-2" htmlFor="bot-name">
            Bot name
          </label>
          <input
            id="bot-name"
            className="input-gh mb-4"
            placeholder="My Awesome Bot"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={60}
          />
          <label className="block text-sm font-semibold mb-2" htmlFor="bot-token">
            Bot token
          </label>
          <input
            id="bot-token"
            className="input-gh font-mono text-sm mb-4"
            placeholder="123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            value={token}
            onChange={(e) => setToken(e.target.value)}
          />
          {error && <p className="text-bad text-sm mb-4">{error}</p>}
          <div className="flex gap-3">
            <button type="submit" disabled={busy} className="btn-gold flex-1">
              {busy ? 'Creating...' : 'Create bot'}
            </button>
            <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function BotCard({ bot, onAction }) {
  const running = bot.status === 'running';
  return (
    <div className="card p-5 flex flex-col gap-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <Link to={`/bots/${bot.id}`} className="font-bold text-lg hover:text-brand-gold transition-colors truncate block">
            {bot.name}
          </Link>
          <p className="text-xs text-brand-muted mt-1">
            #{bot.id} • restarts: {bot.restartCount || 0}
            {running && bot.uptimeSeconds ? ` • up ${formatUptime(bot.uptimeSeconds)}` : ''}
          </p>
        </div>
        <span
          className={`badge shrink-0 ${running ? 'bg-ok/15 text-ok' : 'bg-brand-muted/15 text-brand-muted'}`}
        >
          <span className={`w-2 h-2 rounded-full ${running ? 'bg-ok animate-pulse' : 'bg-brand-muted'}`} />
          {running ? 'Running' : 'Stopped'}
        </span>
      </div>

      <div className="flex flex-wrap gap-2 mt-auto">
        <Link to={`/bots/${bot.id}`} className="btn-ghost !px-4 !py-2 text-sm flex-1 min-w-[90px]">
          ✏️ Editor
        </Link>
        {running ? (
          <button className="btn-ghost !px-4 !py-2 text-sm flex-1 min-w-[90px]" onClick={() => onAction('stop', bot)}>
            ⏹ Stop
          </button>
        ) : (
          <button className="btn-gold !px-4 !py-2 text-sm flex-1 min-w-[90px]" onClick={() => onAction('start', bot)}>
            ▶ Start
          </button>
        )}
        <button
          className="btn-ghost !px-4 !py-2 text-sm flex-1 min-w-[90px]"
          onClick={() => onAction('restart', bot)}
          disabled={!running}
          style={!running ? { opacity: 0.5, cursor: 'not-allowed' } : undefined}
        >
          🔄 Restart
        </button>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user, refreshUser } = useAuth();
  const { plan, adsForAction, autoStopHours } = usePlan();
  const { bots, limits, loading, error, refresh, createBot, deleteBot, startBot, stopBot, restartBot } = useBots();
  const navigate = useNavigate();

  const [showCreate, setShowCreate] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [ad, setAd] = useState(null); // { action, bot }
  const [notice, setNotice] = useState(null);

  const storageUsed = user ? Number(user.storageUsed || 0) : 0;
  const storageLimit = user ? Number(user.storageLimit || 0) : 0;
  const usedPct = percentUsed(storageUsed, storageLimit);

  /** Run an action, gating with the ad modal when the plan requires it. */
  const onAction = async (action, bot) => {
    setNotice(null);
    try {
      if (action === 'stop') {
        await stopBot(bot.id);
        return;
      }
      const need = adsForAction(action);
      if (need.required) {
        setAd({ action, bot, count: need.count, duration: need.duration });
        return;
      }
      await runAction(action, bot, []);
    } catch (err) {
      setNotice(errorMessage(err));
    }
  };

  const runAction = async (action, bot, adWatchIds) => {
    if (action === 'start') await startBot(bot.id, adWatchIds);
    else if (action === 'restart') await restartBot(bot.id, adWatchIds);
  };

  const onAdsComplete = async (adWatchIds) => {
    const { action, bot } = ad;
    setAd(null);
    try {
      await runAction(action, bot, adWatchIds);
      setNotice(`✅ ${action === 'start' ? 'Bot started' : 'Bot restarted'} successfully.`);
    } catch (err) {
      setNotice(errorMessage(err));
    }
    refreshUser();
  };

  const handleDelete = async (bot) => {
    try {
      await deleteBot(bot.id);
      setConfirmDelete(null);
      setNotice(`Bot "${bot.name}" deleted.`);
    } catch (err) {
      setNotice(errorMessage(err));
    }
  };

  if (loading) return <LoadingSpinner label="Loading your bots..." />;

  const canCreate = limits ? limits.canCreate : bots.length < (user ? user.maxBots : 1);

  return (
    <div className="container-gh py-10">
      {/* Header row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black">
            Welcome, <span className="gold-text">{(user && user.displayName) || 'Developer'}</span> 👋
          </h1>
          <p className="text-brand-muted text-sm mt-1">Manage and deploy your Telegram bots.</p>
        </div>
        <button
          className="btn-gold"
          onClick={() => (canCreate ? setShowCreate(true) : navigate('/plans'))}
        >
          {canCreate ? '+ New Bot' : '⬆ Upgrade for more bots'}
        </button>
      </div>

      {/* Plan summary */}
      <div className="card p-6 mb-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <div className="text-xs uppercase tracking-wide text-brand-muted font-bold">Current plan</div>
          <div className="mt-2 flex items-center gap-3">
            <span className="badge text-sm" style={{ ...planBadgeStyle(plan.id), fontSize: 13 }}>
              {plan.name}
            </span>
            {plan.price === 0 ? (
              <Link to="/plans" className="text-brand-gold text-sm font-bold hover:underline">
                Upgrade →
              </Link>
            ) : (
              <span className="text-sm text-brand-muted">
                ₹{plan.price}/mo • expires {user && user.planExpiry ? new Date(user.planExpiry).toLocaleDateString('en-IN') : '—'}
              </span>
            )}
          </div>
          <p className="text-xs text-brand-muted mt-3 leading-relaxed">
            {plan.ads
              ? `5-second ads on actions. ${autoStopHours ? 'Free bots auto-stop after 24h.' : 'No 24h auto-stop.'}`
              : 'Zero ads. Ad blocker allowed. Thank you for supporting GodHosting! ⚡'}
          </p>
        </div>

        <div>
          <div className="text-xs uppercase tracking-wide text-brand-muted font-bold">Bots</div>
          <div className="mt-2 text-2xl font-black">
            {bots.length}
            <span className="text-brand-muted text-base font-semibold"> / {user ? user.maxBots : 1}</span>
          </div>
          <div className="h-2 rounded-full bg-brand-deep mt-3 overflow-hidden">
            <div
              className="h-full bg-gold-gradient"
              style={{ width: `${percentUsed(bots.length, user ? user.maxBots : 1)}%` }}
            />
          </div>
        </div>

        <div>
          <div className="text-xs uppercase tracking-wide text-brand-muted font-bold">Storage</div>
          <div className="mt-2 text-2xl font-black">
            {formatBytes(storageUsed)}
            <span className="text-brand-muted text-base font-semibold"> / {plan.storageLabel}</span>
          </div>
          <div className="h-2 rounded-full bg-brand-deep mt-3 overflow-hidden">
            <div className={`h-full ${usedPct > 90 ? 'bg-bad' : 'bg-gold-gradient'}`} style={{ width: `${usedPct}%` }} />
          </div>
        </div>
      </div>

      {autoStopHours > 0 && (
        <div className="mb-8 p-4 rounded-xl bg-warn/10 border border-warn/40 text-sm text-warn flex items-start gap-3">
          <span aria-hidden="true">⏰</span>
          <p>
            <strong>Free plan:</strong> bots auto-stop after 24 hours. Restarting needs 3 ads (15s).
            Upgrade to Silver or above for always-on hosting.
          </p>
        </div>
      )}

      {notice && (
        <div className="mb-6 p-3 rounded-lg bg-brand-deep/60 border border-brand-line text-sm">{notice}</div>
      )}
      {error && <div className="mb-6 p-3 rounded-lg bg-bad/10 border border-bad/40 text-bad text-sm">{error}</div>}

      {/* Bots grid */}
      {bots.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-6xl mb-4" aria-hidden="true">🤖</div>
          <h2 className="text-xl font-bold">No bots yet</h2>
          <p className="text-brand-muted text-sm mt-2 mb-6 max-w-md mx-auto">
            Create your first Telegram bot in under a minute. You'll need a bot token from @BotFather.
          </p>
          <button className="btn-gold" onClick={() => (canCreate ? setShowCreate(true) : navigate('/plans'))}>
            + Create your first bot
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {bots.map((bot) => (
            <BotCard key={bot.id} bot={bot} onAction={onAction} />
          ))}
        </div>
      )}

      {/* Delete confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 gh-fade-in">
          <div className="card p-6 max-w-sm w-full text-center">
            <div className="text-4xl mb-3">🗑️</div>
            <h3 className="font-bold text-lg">Delete "{confirmDelete.name}"?</h3>
            <p className="text-brand-muted text-sm mt-2">
              This permanently removes the bot, its code and all files. This cannot be undone.
            </p>
            <div className="flex gap-3 mt-6">
              <button className="btn-danger flex-1" onClick={() => handleDelete(confirmDelete)}>
                Delete forever
              </button>
              <button className="btn-ghost flex-1" onClick={() => setConfirmDelete(null)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manage/delete hint list */}
      {bots.length > 0 && (
        <div className="mt-8 card p-5">
          <h3 className="font-bold mb-3">Manage bots</h3>
          <ul className="divide-y divide-brand-line">
            {bots.map((bot) => (
              <li key={bot.id} className="py-3 flex items-center justify-between gap-3">
                <Link to={`/bots/${bot.id}`} className="font-semibold hover:text-brand-gold truncate">
                  {bot.name} <span className="text-brand-muted text-xs">#{bot.id}</span>
                </Link>
                <button className="text-bad text-sm font-semibold hover:underline" onClick={() => setConfirmDelete(bot)}>
                  Delete
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <CreateBotModal open={showCreate} onClose={() => setShowCreate(false)} onCreated={createBot} />

      {ad && (
        <AdModal
          open={!!ad}
          action={ad.action}
          botId={ad.bot.id}
          count={ad.count}
          duration={ad.duration}
          onComplete={onAdsComplete}
          onClose={() => setAd(null)}
        />
      )}
    </div>
  );
}
