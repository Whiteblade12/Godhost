/** Plan state derived from the authenticated user + ad-rule helpers. */
import React, { createContext, useContext, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { PLANS, adsForAction } from '../constants/plans';

export const PlanContext = createContext(null);

export function PlanProvider({ children }) {
  const { user } = useAuth();

  const value = useMemo(() => {
    const plan = PLANS[(user && user.planType) || 'free'] || PLANS.free;
    return {
      plan,
      isPremium: !plan.ads, // Platinum / Diamond
      isAdFree: !plan.ads,
      adblockerAllowed: plan.adblockerAllowed,
      /** Ads needed for an action under the current plan. */
      adsForAction: (action) => adsForAction(plan.id, action),
      autoStopHours: plan.autoStopHours,
    };
  }, [user]);

  return <PlanContext.Provider value={value}>{children}</PlanContext.Provider>;
}

export default PlanContext;
