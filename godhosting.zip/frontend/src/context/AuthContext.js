/** Global authentication state: Firebase Google login + backend JWT session. */
import React, { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import { authApi } from '../utils/api';
import { signInWithGoogle, firebaseSignOut, firebaseEnabled } from '../utils/auth';
import { TOKEN_KEY } from '../constants/config';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem(TOKEN_KEY));
  const [loading, setLoading] = useState(true);

  const loadMe = useCallback(async () => {
    const stored = localStorage.getItem(TOKEN_KEY);
    if (!stored) {
      setLoading(false);
      return null;
    }
    try {
      const res = await authApi.me();
      setUser(res.data.user);
      setToken(stored);
      return res.data.user;
    } catch {
      localStorage.removeItem(TOKEN_KEY);
      setUser(null);
      setToken(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMe();
  }, [loadMe]);

  // Global 401 handling
  useEffect(() => {
    const handler = () => {
      setUser(null);
      setToken(null);
    };
    window.addEventListener('gh:unauthorized', handler);
    return () => window.removeEventListener('gh:unauthorized', handler);
  }, []);

  /**
   * Login flow:
   * 1. Google popup -> Firebase ID token (or demo email in DEMO_MODE)
   * 2. Exchange for backend JWT + create/load account (referral code from ?ref=)
   */
  const login = useCallback(async ({ demoEmail, demoName } = {}) => {
    const params = new URLSearchParams(window.location.search);
    const referralCode = params.get('ref') || localStorage.getItem('gh_ref') || null;
    if (referralCode) localStorage.setItem('gh_ref', referralCode);

    let payload = { referralCode };
    if (demoEmail) {
      payload = { ...payload, demoEmail, demoName };
    } else {
      const idToken = await signInWithGoogle();
      payload = { ...payload, idToken };
    }

    const res = await authApi.google(payload);
    localStorage.setItem(TOKEN_KEY, res.data.token);
    localStorage.removeItem('gh_ref');
    setToken(res.data.token);
    setUser(res.data.user);
    return res.data.user;
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch {
      /* ignore */
    }
    await firebaseSignOut();
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setToken(null);
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const res = await authApi.me();
      setUser(res.data.user);
      return res.data.user;
    } catch {
      return null;
    }
  }, []);

  const value = useMemo(
    () => ({ user, token, loading, login, logout, refreshUser, firebaseEnabled }),
    [user, token, loading, login, logout, refreshUser]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export default AuthContext;
