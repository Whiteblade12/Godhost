import { useContext } from 'react';
import { PlanContext } from '../context/PlanContext';
import { PLANS } from '../constants/plans';

/** Access plan helpers. Safe to use when logged out (defaults to free). */
export function usePlan() {
  const ctx = useContext(PlanContext);
  if (ctx) return ctx;
  return {
    plan: PLANS.free,
    isPremium: false,
    isAdFree: false,
    adblockerAllowed: false,
    adsForAction: () => ({ required: false, count: 0, duration: 5 }),
    autoStopHours: 24,
  };
}

export default usePlan;
