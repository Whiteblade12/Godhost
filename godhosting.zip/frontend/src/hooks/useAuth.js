import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

/** Access the auth context. Throws outside <AuthProvider>. */
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export default useAuth;
