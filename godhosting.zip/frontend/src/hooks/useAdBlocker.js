import { useCallback, useEffect, useRef, useState } from 'react';
import { detectAndReport } from '../utils/adBlocker';
import { useAuth } from './useAuth';
import { usePlan } from './usePlan';

/**
 * Continuously detects ad blockers for ad-supported plans and reports results
 * to the backend. Returns { detected, methods, recheck }.
 * Premium users (Platinum/Diamond) are never checked - ad blockers allowed.
 */
export function useAdBlocker() {
  const { user } = useAuth();
  const { isPremium } = usePlan();
  const [detected, setDetected] = useState(false);
  const [methods, setMethods] = useState([]);
  const timer = useRef(null);

  const recheck = useCallback(async () => {
    if (isPremium) {
      setDetected(false);
      setMethods([]);
      return { detected: false, methods: [] };
    }
    const result = await detectAndReport();
    setDetected(result.detected);
    setMethods(result.methods);
    return result;
  }, [isPremium]);

  useEffect(() => {
    if (isPremium) {
      setDetected(false);
      return undefined;
    }
    // Initial check shortly after mount, then every 30s
    const boot = window.setTimeout(recheck, 1200);
    timer.current = window.setInterval(recheck, 30000);
    const onVisible = () => {
      if (document.visibilityState === 'visible') recheck();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.clearTimeout(boot);
      window.clearInterval(timer.current);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [recheck, isPremium, user]);

  return { detected, methods, recheck };
}

export default useAdBlocker;
