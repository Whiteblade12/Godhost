import { useCallback, useEffect, useState } from 'react';
import { botsApi } from '../utils/api';
import { errorMessage } from '../utils/validators';

/** Bot list state + CRUD actions. */
export function useBots() {
  const [bots, setBots] = useState([]);
  const [limits, setLimits] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      setError(null);
      const res = await botsApi.list();
      setBots(res.data.bots || []);
      setLimits(res.data.limits || null);
    } catch (err) {
      setError(errorMessage(err, 'Failed to load bots'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const createBot = useCallback(
    async (name, botToken) => {
      const res = await botsApi.create({ name, botToken });
      await refresh();
      return res.data.bot;
    },
    [refresh]
  );

  const deleteBot = useCallback(
    async (id) => {
      await botsApi.remove(id);
      await refresh();
    },
    [refresh]
  );

  const startBot = useCallback(
    async (id, adWatchIds = []) => {
      const res = await botsApi.start(id, adWatchIds);
      await refresh();
      return res.data;
    },
    [refresh]
  );

  const stopBot = useCallback(
    async (id) => {
      await botsApi.stop(id);
      await refresh();
    },
    [refresh]
  );

  const restartBot = useCallback(
    async (id, adWatchIds = []) => {
      const res = await botsApi.restart(id, adWatchIds);
      await refresh();
      return res.data;
    },
    [refresh]
  );

  return {
    bots,
    limits,
    loading,
    error,
    refresh,
    createBot,
    deleteBot,
    startBot,
    stopBot,
    restartBot,
  };
}

export default useBots;
