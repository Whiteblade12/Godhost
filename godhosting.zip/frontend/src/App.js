import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { PlanProvider } from './context/PlanContext';
import { useAuth } from './hooks/useAuth';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AdBlockerWarning from './components/AdBlockerWarning';
import Home from './pages/Home';
import Login from './components/Login';
import DashboardPage from './pages/DashboardPage';
import BotPage from './pages/BotPage';
import PlansPage from './pages/PlansPage';
import Payment from './components/Payment';
import Referrals from './components/Referrals';
import Profile from './components/Profile';
import Admin from './components/Admin';
import AdminLogin from './components/AdminLogin';

function ScrollToTop() {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Protected({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-10 h-10 rounded-full border-4 border-brand-line border-t-brand-gold animate-spin" />
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  return children;
}

function NotFound() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
      <div className="text-7xl font-black bg-gold-gradient bg-clip-text text-transparent">404</div>
      <p className="text-brand-muted mt-4">This page took the bot offline.</p>
      <a href="/" className="btn-gold mt-6">Back to GodHosting</a>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <PlanProvider>
          <ScrollToTop />
          <div className="min-h-screen flex flex-col bg-brand-dark text-white font-sans">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/plans" element={<PlansPage />} />
                <Route
                  path="/dashboard"
                  element={
                    <Protected>
                      <DashboardPage />
                    </Protected>
                  }
                />
                <Route
                  path="/bots/:id"
                  element={
                    <Protected>
                      <BotPage />
                    </Protected>
                  }
                />
                <Route
                  path="/pay/:planId"
                  element={
                    <Protected>
                      <Payment />
                    </Protected>
                  }
                />
                <Route
                  path="/referrals"
                  element={
                    <Protected>
                      <Referrals />
                    </Protected>
                  }
                />
                <Route
                  path="/profile"
                  element={
                    <Protected>
                      <Profile />
                    </Protected>
                  }
                />
                {/* Admin: hidden URL only — godhosting.online/admin/auth/ */}
                <Route path="/admin/auth" element={<AdminLogin />} />
                <Route path="/admin/auth/" element={<AdminLogin />} />
                <Route path="/admin" element={<Admin />} />
                <Route path="/admin/" element={<Admin />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
            <AdBlockerWarning />
          </div>
        </PlanProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
