/** GodHosting Tailwind theme - dark navy + gold gradients. */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      colors: {
        brand: {
          gold: '#f7971e',
          gold2: '#ffd200',
          dark: '#1a1a2e',
          card: '#16213e',
          deep: '#0f3460',
          muted: '#8892b0',
          line: '#233054',
        },
        ok: '#4ade80',
        bad: '#f87171',
        warn: '#fbbf24',
        info: '#60a5fa',
        platinum: '#818cf8',
        diamond: '#a855f7',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Fira Code"', 'monospace'],
      },
      boxShadow: {
        gold: '0 0 24px rgba(247, 151, 30, 0.35)',
        card: '0 8px 32px rgba(0, 0, 0, 0.35)',
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #f7971e 0%, #ffd200 100%)',
        'hero-glow': 'radial-gradient(ellipse at top, rgba(247,151,30,0.18), transparent 60%)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'pulse-gold': 'pulseGold 2s infinite',
        shimmer: 'shimmer 1.6s infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(247,151,30,0.5)' },
          '50%': { boxShadow: '0 0 0 12px rgba(247,151,30,0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-400px 0' },
          '100%': { backgroundPosition: '400px 0' },
        },
      },
    },
  },
  plugins: [],
};
