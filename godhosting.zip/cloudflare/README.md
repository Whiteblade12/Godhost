# ☁️ Cloudflare Setup — DDoS & Hacking Protection for GodHosting

The backend already bans IPs for **3 hours after >200 requests in 10 minutes**
(`backend/src/middleware/ddosGuard.js`). Put Cloudflare in front so attacks are
stopped at the edge, before they ever reach your server.

## 1. Add your domain
1. Create a free account at [cloudflare.com](https://cloudflare.com) → **Add site** → `godhosting.online`
2. At your domain registrar, replace the nameservers with the two Cloudflare gives you
3. DNS records (make sure the proxy status is **🟠 Proxied / orange cloud**):

| Type | Name | Content | Proxy |
|---|---|---|---|
| A | `@` | *(your server IP)* | 🟠 Proxied |
| CNAME | `api` | *(your Render/backend domain)* | 🟠 Proxied |
| CNAME | `www` | `godhosting.online` | 🟠 Proxied |

## 2. The exact DDoS rule (>200 req / 10 min → 3h block)
**Security → WAF → Rate limiting rules → Create rule**

- **Rule name:** `Ban flooders for 3 hours`
- **Expression (edit it in the editor):**
  ```
  (http.request.uri contains "/api")
  ```
  *(or leave empty to count ALL requests on the domain)*
- **Rate:** more than **200** requests per **10 minutes**, per **IP**
- **Action:** **Block**
- **Duration:** **3 hours** (180 minutes)

✅ That's the exact policy: any IP generating more than 200 requests in 10
minutes gets blocked by Cloudflare for 3 hours.

## 3. Turn on the free anti-hack layers
| Setting | Where | Value |
|---|---|---|
| Security level | Security → Settings | **High** (or *I'm Under Attack* during an attack) |
| Bot Fight Mode | Security → Bots | **On** |
| Cloudflare Managed Ruleset | Security → WAF → Managed rules | **Deploy** (free) — blocks SQLi/XSS/LFI/known CVEs |
| Leaked Credential Detection | Security → Settings | **On** |
| Browser Integrity Check | Security → Settings | **On** |
| SSL/TLS mode | SSL/TLS | **Full (strict)** |
| Always Use HTTPS | SSL/TLS → Edge certificates | **On** |
| HTTP/2 & HTTP/3 | Network | **On** |

## 4. Extra protection for the admin panel
Create a **WAF custom rule** (Security → WAF → Custom rules):

- **Rule name:** `Admin login shield`
- **Expression:**
  ```
  (http.request.uri.path contains "/api/admin/auth/login") and (cf.threat_score gt 0)
  ```
- **Action:** Managed Challenge

Combined with the backend's 5-attempts/15-minutes lockout, brute-forcing
`godhosting.online/admin/auth/` becomes practically impossible.

## 5. Automate it (optional)
`apply-rules.sh` in this folder creates the rate-limit rule via the
Cloudflare API. You need an **API Token** (Zone → Security → Edit) and your
**Zone ID** (right sidebar of the domain overview page):

```bash
export CF_API_TOKEN=xxxx
export CF_ZONE_ID=xxxx
bash apply-rules.sh
```
