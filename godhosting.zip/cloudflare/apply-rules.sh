#!/usr/bin/env bash
# Creates the ">200 requests / 10 min → block 3 hours" rate-limit rule
# on Cloudflare via API v4. Needs CF_API_TOKEN and CF_ZONE_ID.
set -euo pipefail

: "${CF_API_TOKEN:?Set CF_API_TOKEN (Zone:Security:Edit permission)}"
: "${CF_ZONE_ID:?Set CF_ZONE_ID (domain overview sidebar)}"

API="https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/rate_limits"

echo "Creating rate-limit rule: >200 req / 10 min per IP -> 3h block..."
curl -sS -X POST "$API" \
  -H "Authorization: Bearer ${CF_API_TOKEN}" \
  -H "Content-Type: application/json" \
  --data '{
    "description": "GodHosting DDoS guard: >200 requests / 10 min -> 3 hour ban",
    "match": {
      "request": {
        "methods": ["GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS"],
        "schemes": ["HTTP","HTTPS"],
        "url": "godhosting.online/*"
      }
    },
    "threshold": 200,
    "period": 600,
    "action": {
      "mode": "ban",
      "timeout": 10800
    },
    "correlate": { "by": "ip" },
    "enabled": true
  }' | python3 -c "import json,sys; d=json.load(sys.stdin); print('SUCCESS — rule id:', d['result']['id']) if d.get('success') else (print('FAILED:', json.dumps(d.get('errors'), indent=2)), sys.exit(1))"

echo "Done. Verify in Cloudflare dashboard → Security → WAF → Rate limiting rules."
